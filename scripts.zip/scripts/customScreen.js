/*
 * This function is for manage the custom screen game play.
 * Emulator is used for making the custom screen.
 */       
        var ReelsOne;
        var ReelsTwo;
        var ReelsThree;
        var ReelsFour;
        var ReelsFive;
        var GamebaseImg;
        var Reels1Join;
        var Reels2Join;
        var Reels3Join;
        var Reels4Join;
        var Reels5Join;
        var ReelcheckBoxArray = [];
        var Reelcheck1 = false;
        var Reelcheck2 = false;
        var Reelcheck3 = false;
        var Reelcheck4 = false;
        var Reelcheck5 = false;
        
        ReelcheckBoxArray[0]=Reelcheck1;
        ReelcheckBoxArray[1]=Reelcheck2;
        ReelcheckBoxArray[2]=Reelcheck3;
        ReelcheckBoxArray[3]=Reelcheck4;
        ReelcheckBoxArray[4]=Reelcheck5;
        
        function showCustomScreen() {
            var spinToken = $("#spinToken").val();
            $.ajax({
                type: 'GET',
                url: "fetchGameReels?spinToken="+spinToken,
                datatype: "json",
                contentType: this.contentType, // content type sent to server
                // data: initialData,
                success: function (response) {
                    if(response.responseStr){
                        var self = this;
                        var  respStr = response.responseStr.split(";");
                        this.ReelImagesDataFound = true;
                        for(var i =0;i<respStr.length;i++ ) {
                        var  reelStr = respStr[i].split(":");
                          switch(reelStr[0]) {
                              case "reel1":
                                  ReelsOne = reelStr[1].toString().split(",");
                                  break;
                              case "reel2":
                                  ReelsTwo = reelStr[1].toString().split(",");
                                  break;
                              case "reel3":
                                  ReelsThree = reelStr[1].toString().split(",");
                                  break;
                              case "reel4":
                                  ReelsFour = reelStr[1].toString().split(",");
                                  break;
                              case "reel5":
                                  ReelsFive = reelStr[1].toString().split(",");
                                  break;
                              case "gameImagePath":
                                  GamebaseImg=reelStr[1];
                                  break;
                              default:
                                  console.log("Spin Response Task Pending for ????? " + reelStr[0]);
                                  break; 
                            }
                         }
                        setGameReels();
                     }
                },
                // When json call fails
                error: function (errorMsg) { debugger; alert(errorMsg); }
            });
        }
        
        function setGameReels(){
        	 $("#tblReel1").empty();
             $('#tblReel1').append("<tr><td><img  src=" + GamebaseImg + ReelsOne[0].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel1').append("<tr><td><img  src=" + GamebaseImg + ReelsOne[1].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel1').append("<tr><td><img  src=" + GamebaseImg + ReelsOne[2].replace(/ /g, '%20') + " /></td></tr>");

             $("#tblReel2").empty();
             $('#tblReel2').append("<tr><td><img  src=" + GamebaseImg + ReelsTwo[0].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel2').append("<tr><td><img  src=" + GamebaseImg + ReelsTwo[1].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel2').append("<tr><td><img  src=" + GamebaseImg + ReelsTwo[2].replace(/ /g, '%20') + " /></td></tr>");

             $("#tblReel3").empty();
             $('#tblReel3').append("<tr><td><img  src=" + GamebaseImg + ReelsThree[0].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel3').append("<tr><td><img  src=" + GamebaseImg + ReelsThree[1].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel3').append("<tr><td><img  src=" + GamebaseImg + ReelsThree[2].replace(/ /g, '%20') + " /></td></tr>");

             $("#tblReel4").empty();
             $('#tblReel4').append("<tr><td><img src=" + GamebaseImg + ReelsFour[0].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel4').append("<tr><td><img src=" + GamebaseImg + ReelsFour[1].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel4').append("<tr><td><img src=" + GamebaseImg + ReelsFour[2].replace(/ /g, '%20') + " /></td></tr>");

             $("#tblReel5").empty();
             $('#tblReel5').append("<tr><td><img  src=" + GamebaseImg + ReelsFive[0].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel5').append("<tr><td><img  src=" + GamebaseImg + ReelsFive[1].replace(/ /g, '%20') + " /></td></tr>");
             $('#tblReel5').append("<tr><td><img  src=" + GamebaseImg + ReelsFive[2].replace(/ /g, '%20') + " /></td></tr>");
             
             for(var i=1;i<=5;i++){
             	var reelRadio = ReelcheckBoxArray[i-1];
             	if (reelRadio === true) {
                     $('#checkreel'+i).prop('checked', true);
                     var savedReels = $('#reelScreenID'+i).val();
                     if(savedReels !== undefined && savedReels !==""){
                     	var ImgArray = savedReels.split(",");
                     	switchReelsImages(ImgArray,"tblReel"+i);
                     }
                      
                 } else { $('#checkreel'+i).prop('checked', false); }
             }
        }
        
        function ReelUp(ReelUpId) {
           
            switch (ReelUpId.id) {
                case "ReelOneUp":
                	shiftUpReelIcon(ReelsOne);
                    switchReelsImages(ReelsOne,"tblReel1");
                    break;
                case "ReelTwoUp":
                	shiftUpReelIcon(ReelsTwo);
                    switchReelsImages(ReelsTwo,"tblReel2");
                    break;
                case "ReelThreeUp":
                	shiftUpReelIcon(ReelsThree);
                    switchReelsImages(ReelsThree,"tblReel3");
                    break;
                case "ReelFourUp":
                	shiftUpReelIcon(ReelsFour);
                    switchReelsImages(ReelsFour,"tblReel4");
                    break;
                case "ReelFiveUp":
                	shiftUpReelIcon(ReelsFive);
                    switchReelsImages(ReelsFive,"tblReel5");
                    break;
                    
                  default:
                  break;
            }
        }
        
        function ReelDown(ReelDownId) {
          
            switch (ReelDownId.id) {
                case "ReelOneDown":
                	shiftDownReelIcon(ReelsOne);
                    switchReelsImages(ReelsOne,"tblReel1");
                    break;
                case "ReelTwoDown":
                	shiftDownReelIcon(ReelsTwo);
                    switchReelsImages(ReelsTwo,"tblReel2");
                    break;
                case "ReelThreeDown":
                	shiftDownReelIcon(ReelsThree);
                    switchReelsImages(ReelsThree,"tblReel3");
                    break;
                case "ReelFourDown":
                	shiftDownReelIcon(ReelsFour);
                    switchReelsImages(ReelsFour,"tblReel4");
                    break;
                case "ReelFiveDown":
                	shiftDownReelIcon(ReelsFive);
                    switchReelsImages(ReelsFive,"tblReel5");
                    break;
                default:
                	break;
            }
        }
        
        function shiftUpReelIcon(reelArray){
        	 var bottomItem = reelArray.splice(reelArray.length - 1, 1);
        	 reelArray.splice(0, 0, bottomItem[0]);
        }
        
        function shiftDownReelIcon(reelArray){
        	var topItem = reelArray.splice(0, 1);
        	reelArray.splice(reelArray.length, 0, topItem[0]);
        }
        
       function switchReelsImages(reelsArray,tableId){
	         var i=0;
	         $('#'+tableId+' tr td').each(function() {
	         var img = $(this).find("img").attr("src",(GamebaseImg + reelsArray[i].replace(/ /g, '%20')));
	             i++;
	          });
        }
        
        $(document).ready(function () { 
            $("#SaveReels").click(function () {
                Reelcheck1 = $('#checkreel1').prop('checked');
                Reelcheck2 = $('#checkreel2').prop('checked');
                Reelcheck3 = $('#checkreel3').prop('checked');
                Reelcheck4 = $('#checkreel4').prop('checked');
                Reelcheck5 = $('#checkreel5').prop('checked');
                
                ReelcheckBoxArray[0]=Reelcheck1;
                ReelcheckBoxArray[1]=Reelcheck2;
                ReelcheckBoxArray[2]=Reelcheck3;
                ReelcheckBoxArray[3]=Reelcheck4;
                ReelcheckBoxArray[4]=Reelcheck5;
                
                if ( Reelcheck1 === true) {
                    Reels1Join = '';
                    for (i = 0; i < 3; i++) {
                        Reels1Join += ReelsOne[i]+",";
                    }
                }else{ Reels1Join = ''; }
    
                if (Reelcheck2 === true) {
                    Reels2Join = '';
                    for (i = 0; i < 3; i++) {
                        Reels2Join += ReelsTwo[i]+",";
                    }
                }else{ Reels2Join = '';}
                
                if (Reelcheck3 === true) {
                    Reels3Join = '';
                    for (i = 0; i < 3; i++) {
                        Reels3Join += ReelsThree[i]+",";
                    }
                }else { Reels3Join = ''; }
    
                if (Reelcheck4 === true) {
                    Reels4Join = '';
                    for (i = 0; i < 3; i++) {
                        Reels4Join += ReelsFour[i]+",";
                    }
                } else { Reels4Join = '';}
    
                if (Reelcheck5 === true) {
                    Reels5Join =''
                    for (i = 0; i < 3; i++) {
                        Reels5Join += ReelsFive[i]+",";
                    }
                } else {Reels5Join = '';}
                
                $("#reelScreenID1").val(Reels1Join);
                $("#reelScreenID2").val(Reels2Join);
                $("#reelScreenID3").val(Reels3Join);
                $("#reelScreenID4").val(Reels4Join);
                $("#reelScreenID5").val(Reels5Join);
                $( "#msg" ).fadeIn(1);
                $("#msg").html("Reels Saved");
                
                $( "#msg" ).fadeOut(3000);
          });
        }); 
        
        $(document).ready(function() {
            $("#reelScreenID1").val("");
            $("#reelScreenID2").val("");
            $("#reelScreenID3").val("");
            $("#reelScreenID4").val("");
            $("#reelScreenID5").val("");
            
            $('#checkreel1').prop('checked', false);
            $('#checkreel2').prop('checked', false);
            $('#checkreel3').prop('checked', false);
            $('#checkreel4').prop('checked', false);
            $('#checkreel5').prop('checked', false);
            
             $("#showpop").click(function () {
                 
             var isCustomScreenHide =  $("#gameCustomScreenEmu").hasClass("display-none");
             if(isCustomScreenHide){
                 $("#gameCustomScreenEmu").removeClass("display-none");
                 $("#msg").html("");
                
                 if(ReelsOne===undefined || ReelsOne===null || ReelsOne===""){
             		showCustomScreen();
             	 }
                 
                 $( "#showpop:first" ).text("Hide Emulator");
             }else{
                $("#gameCustomScreenEmu").addClass("display-none");
                $("#showpop:first" ).text("Show Emulator");
                $("#msg").html("");
                
             }
            });
        });
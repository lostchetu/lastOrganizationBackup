/*This function loads all model object, string splitter object,chances and scores */
function BonusMain(spinServiceObj, totalScores, symbolValues, chances,
            coinValue, dataModelObj, stringSplitObj) {
     "use strict";
     var self = this;
     this.dataModelObj = dataModelObj;
     this.stringSplit = stringSplitObj;
     this.spinService = spinServiceObj;
    if(this.dataModelObj.bonusGameVisible === false) {
      this.dataModelObj.bonusGameVisible = true;
      this.chanceAllowed = chances;
      this.totalScores = totalScores;
      this.symbolValue = symbolValues;
      
      this.coinValue = coinValue;
      this.valueArr = this.totalScores;
      $('.bonus-canvas-back').show();
      if ($('.bonus-canvas-container')) {
            $('.bonus-canvas-container').show();
            $(".transGamebg").show();
      }
      this.bonusDataModel = new BonusDataModel();
      this.buttonInitObj = new BonusButtonInit(this);
      this.canvasWidth = $('#bonusCanvas').attr("width");
      this.canvasHeight = $('#bonusCanvas').attr("height");
      this.frameCount = 0;
      this.ctx = $('#bonusCanvas')[0].getContext('2d');

      $("#bonus-coin-val").attr("value", "$" + this.coinValue);
      $("#chance-text").attr("value", this.chanceAllowed);
      this.remainingChances = this.chanceAllowed;
      
      this.imageArray = [];
      this.checkAttempt = 0;
      this.tempClickAttempt = 0;
      this.totalValue = 0;
      $("#bonus-point").attr("value", this.totalValue);
      this.animTimer = 0;
      this.liverCount1 = 0;
      this.liverCount2 = 0;
      this.liverCount3 = 0;
      //this.numFrames = 21;
      this.ctx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
      this.initialize();
      this.soundArr = [];
      this.clockx= 110;
      this.clocky =108;
      
      this.tempWinValueArray = this.symbolValue;
      this.tempWinUnmatchArray = this.symbolValue;
      this.clickedImgArray=[];
      
      this.matchValuePosArr1 = [];
      this.matchValuePosArr2 = [];
      this.matchValuePosArr3 = [];
      
      this.winClockspriteImage1 = new Image();
      this.winClockspriteImage1.src = this.bonusDataModel.imageSrc + "Glow_Sprite1.png";
      
      this.winClockspriteImage2 = new Image();
      this.winClockspriteImage2.src = this.bonusDataModel.imageSrc + "Glow_Sprite2.png";
      
      this.winClockspriteImage3 = new Image();
      this.winClockspriteImage3.src = this.bonusDataModel.imageSrc + "Glow_Sprite3.png";
      
      this.dataModelObj.explosion = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'explosion.mp3',
                        this.dataModelObj.soundSrc + 'explosion.wav' ]
      });
      
      if(this.dataModelObj.GAME_BG_SOUND != null ){
          this.dataModelObj.GAME_BG_SOUND.stop();
      }
      this.bonusGameAliceSounds();
      
      this.isWinValueAnimateActive1 = false;
      this.isWinValueAnimateActive2 = false;
      this.isWinValueAnimateActive3 = false;
    }
}


BonusMain.prototype.checkAndIncrementAttempt = function(pos, img) {
    var self = this;
    
    if(this.checkAttempt < this.chanceAllowed && this.tempWinValueArray.length>0) {
        var valueCounter =0;
        var clickValueImg;
        
        for (var i = 0; i < this.clickedImgArray.length; i++) {
            var clickedImg = this.clickedImgArray[i];
            var clickedImgScore = clickedImg.value;
            if(parseInt(clickedImgScore) === parseInt(img.value)){
                valueCounter++;
                clickValueImg = clickedImg;
            }
        }
        
        var index = this.tempWinValueArray.indexOf(img.value);
        
        if (index > -1) {
            
            if(valueCounter >= 1 ){
                this.tempWinValueArray.splice(index, 1);
                this.removeMatchedValue(clickValueImg.value);
                this.checkAttempt++;
                this.totalValue += parseInt(img.value);
                this.remainingChances = parseInt(this.remainingChances)-1;

                if(this.checkAttempt===1){
                    this.matchValuePosArr1[0] = clickValueImg;
                    this.matchValuePosArr1[1] = img;
                } else if(this.checkAttempt===2){
                    this.matchValuePosArr2[0] = clickValueImg;
                    this.matchValuePosArr2[1] = img;
                } else if(this.checkAttempt===3){
                    this.matchValuePosArr3[0] = clickValueImg;
                    this.matchValuePosArr3[1] = img;
                }

            }else{
                this.clickedImgArray.push(img);
            }
            
        } else {
            if(valueCounter >= 1){
                var switchValue = this.tempWinUnmatchArray[0];
                if(switchValue != undefined){
                    this.switchImageArray(pos, switchValue);
                    var tmpCounter = 0;
                    var clickValueImg2;
                    for (var i = 0; i < this.clickedImgArray.length; i++) {
                        var clickedImg = this.clickedImgArray[i];
                        var clickedImgScore = clickedImg.value;
                        if(parseInt(clickedImgScore) === parseInt(switchValue)){
                            tmpCounter++;
                            clickValueImg2 = clickedImg;
                        }
                    }
                    
                    var tempIndex = this.tempWinValueArray.indexOf(switchValue);
                    
                    if (tempIndex > -1 && tmpCounter >= 1) {
                        this.removeMatchedValue(clickValueImg2.value);
                        this.tempWinValueArray.splice(tempIndex, 1);
                        this.checkAttempt++;
                        this.totalValue += parseInt(switchValue);
                        
                        this.remainingChances = parseInt(this.remainingChances)-1;
                        if(this.checkAttempt===1){
                            this.matchValuePosArr1[0] = clickValueImg2;
                            this.matchValuePosArr1[1] = img;
                        } else if(this.checkAttempt===2){
                            this.matchValuePosArr2[0] = clickValueImg2;
                            this.matchValuePosArr2[1] = img;
                        } else if(this.checkAttempt===3){
                            this.matchValuePosArr3[0] = clickValueImg2;
                            this.matchValuePosArr3[1] = img;
                        }
                        

                        
                    }else{
                        this.clickedImgArray.push(img);
                    }
                }
                
            }else{
                this.clickedImgArray.push(img);
            }
        }
    }
}

BonusMain.prototype.removeMatchedValue = function(removeValue){
    
    for (var i = 0; i < this.clickedImgArray.length; i++) {
        var clickedImg = this.clickedImgArray[i];
        var clickedImgScore = clickedImg.value;
        if(parseInt(clickedImgScore) === parseInt(removeValue)){
            this.clickedImgArray.splice(i, 1);
        }
    }
}

BonusMain.prototype.initialize = function() {
      var self = this;
      
      var image = new Image()
      image.src = this.bonusDataModel.imageSrc + "Clock_sprite.png";

      image.onload = function() {
            for (var i = 1; i < 25; i++) {
                  var imageObj = new Object();
                  imageObj.img = image;
                  imageObj.x = self.clockx;
                  imageObj.y = self.clocky;
                  
                  var symbolIndex = Math.floor(Math.random()* (self.valueArr.length - 1));
                  imageObj.value = self.valueArr[symbolIndex];
                  imageObj.isClicked = false;
                  self.valueArr.splice(symbolIndex, 1);
                  
                  self.ctx.drawImage(imageObj.img, self.bonusDataModel.animWidth
                              * self.frameCount, 0, self.bonusDataModel.animWidth,
                              self.bonusDataModel.animHeight, imageObj.x, imageObj.y,
                              self.bonusDataModel.animWidth,
                              self.bonusDataModel.animHeight);
                  
                  self.imageArray.push(imageObj);
                  self.clockx += 234;
                  self.clockY += 247;
                  if(i%25==0) {
                      self.clocky += 0;
                      
                  }
                 
                  if(i==6) {
                      self.clockx = 110;
                      self.clocky = 328;
                      
                  } 
                 else if(i==12) {
                      self.clockx = 110;
                      self.clocky = 548
                      
               }
                  
                  else if(self.clockx > 1366){
                         self.clockx = 110;
                         self.clocky = 768
                  }
                     
              }
              
                self.clockx = 234;
                self.clocky = 247;
            self.buttonInitObj.bindEvents();
      }
}


BonusMain.prototype.clearContainer = function() {
    "use strict";
    var self = this;
    
    this.isWinValueAnimateActive1=false;
    this.isWinValueAnimateActive2=false;
    this.isWinValueAnimateActive3=false;
    
    if (this.animTimer != null) {
        clearInterval(this.animTimer);
    }
    

	    if (this.winClockAnimationTimer1 != null) {
		clearInterval(this.winClockAnimationTimer1);
	}

	if (this.winClockAnimationTimer2 != null) {
		clearInterval(this.winClockAnimationTimer2);
	}

	if (this.winClockAnimationTimer3 != null) {
		clearInterval(this.winClockAnimationTimer3);
	}

	if (this.winClockAnimUpdateTimer1 != null) {
		clearInterval(this.winClockAnimUpdateTimer1);
	}

	if (this.winClockAnimUpdateTimer2 != null) {
		clearInterval(this.winClockAnimUpdateTimer2);
	}

	if (this.winClockAnimUpdateTimer3 != null) {
		clearInterval(this.winClockAnimUpdateTimer3);
	}

	if (this.showBonusPopupTimer != null) {
		clearInterval(this.showBonusPopupTimer);
	}
}

/*
 * This function check the hits of dynamite and draw text of win amount.
 */

BonusMain.prototype.checkObjectHit = function(posX, posY) {

    for (var i = 0; i < this.imageArray.length; i++) {
            if (posX >= (this.imageArray[i].x)
                        && posX <= (this.imageArray[i].x + this.bonusDataModel.animWidth)
                        && posY >= (this.imageArray[i].y)
                        && posY <= (this.imageArray[i].y + this.bonusDataModel.animHeight) && this.imageArray[i].isClicked === false) {
                  if (this.checkAttempt < this.chanceAllowed) {
                	  	if(this.dataModelObj.isSoundPlay === true ){
                		  self.dataModelObj.GAME_BG_SOUND.stop();
                		  self.dataModelObj.bonusPointsWin.stop();
                      	  self.dataModelObj.clickToPlayGame.stop().play();
                      }
                        this.tempClickAttempt++;
                        this.buttonInitObj.unBindEvents();
                        this.checkAndIncrementAttempt(i,this.imageArray[i]);
                        this.startFlipAnimation(this.imageArray[i]);
                        this.imageArray[i].isClicked = true;
                        this.imageArray.splice(i, 1);
                        break;
                  } else {
                        this.buttonInitObj.unBindEvents();
                  }

            }
      }
}


BonusMain.prototype.switchImageArray = function(pos, score) {
      var tempValue = this.imageArray[pos].value;
      for (var i = 0; i < this.imageArray.length; i++) {
            if ((parseInt(this.imageArray[i].value)) === (parseInt(score))) {
                  //this.imageArray[i].value = tempValue;
                  this.imageArray[pos].value = score;
                  break;
            }
      }
}

/*
* This function start mine clock animation
*/
BonusMain.prototype.startFlipAnimation = function(animObj) {
      var self = this;
      this.frameCount = 0;
      
      if(this.animTimer != null){
            clearInterval(this.animTimer);
      }
      
      if (this.dataModelObj.isSoundPlay === true) {
            this.dataModelObj.explosion.stop().play();
      }
      
      this.animTimer = setInterval(function() {
            self.animateClock(animObj);
      }, 1000 / 10);
     
}
/*
* This function calls when the blast in dinamite and display the win text and win pop up. 
 */

BonusMain.prototype.animateClock = function(AnimObj) {
      var self = this;
      this.numFrames = 19;
      this.tmpAnimObj = AnimObj;

      this.ctx.clearRect(AnimObj.x, AnimObj.y, this.bonusDataModel.animWidth,
                  this.bonusDataModel.animHeight);
      this.ctx.drawImage(AnimObj.img, this.bonusDataModel.animWidth * this.frameCount, 
                  0, this.bonusDataModel.animWidth,
                  this.bonusDataModel.animHeight, AnimObj.x, AnimObj.y,
                  this.bonusDataModel.animWidth, this.bonusDataModel.animHeight);

      this.frameCount++;
      if (this.frameCount >= this.numFrames) {
            clearInterval(this.animTimer);
            
            if(this.checkAttempt===1 && this.isWinValueAnimateActive1===false){
                var tmpCheckAtt = this.checkAttempt;
                this.isWinValueAnimateActive1 = true;
                
                if(this.winClockAnimationTimer1 != null){
                      clearInterval(this.winClockAnimationTimer1);
                }
                
                if(this.dataModelObj.isSoundPlay === true ){
                	self.dataModelObj.GAME_BG_SOUND.stop();
                	self.dataModelObj.bonusPointsWin.stop().play();
                }
                
                this.winClockAnimationTimer1 = setInterval(function() {
                      self.winClockAnimation(AnimObj, tmpCheckAtt);
                }, 1000 / 15);
            
            
                if(this.winClockAnimUpdateTimer1 != null){
                    clearInterval(this.winClockAnimUpdateTimer1);
                }
                
                this.winClockAnimUpdateTimer1 = setInterval(function() {
                      if(self.liverCount1===0) {
                    	  clearInterval(self.winClockAnimUpdateTimer1);
                          $("#bonus-point").attr("value", self.totalValue);
                          $("#chance-text").attr("value", parseInt(self.remainingChances));
                          if (self.checkAttempt >= self.chanceAllowed) {
                    		  self.updateBonusPlayed();
                    	  }
                      }
                }, 1000 / 5);
            
            }
            
            
            if(this.checkAttempt===2 && this.isWinValueAnimateActive2===false){
                this.isWinValueAnimateActive2= true;
                var tmpCheckAtt = this.checkAttempt;
                
                if(this.winClockAnimationTimer2 != null){
                    clearInterval(this.winClockAnimationTimer2);
                }
                
                if(this.dataModelObj.isSoundPlay === true ){
                	self.dataModelObj.GAME_BG_SOUND.stop();
                	self.dataModelObj.bonusPointsWin.stop().play();
                }
                
                this.winClockAnimationTimer2 = setInterval(function() {
                    self.winClockAnimation(AnimObj, tmpCheckAtt);
                }, 1000 / 15);
            
            
                if(this.winClockAnimUpdateTimer2 != null){
                    clearInterval(this.winClockAnimUpdateTimer2);
                }
                
                this.winClockAnimUpdateTimer2 = setInterval(function() {
                      if(self.liverCount2==0) {
                    	  	clearInterval(self.winClockAnimUpdateTimer2);
                            $("#bonus-point").attr("value", self.totalValue);
                            $("#chance-text").attr("value", parseInt(self.remainingChances));
                            if (self.checkAttempt >= self.chanceAllowed) {
                                self.updateBonusPlayed();
                            }
                      }
                }, 1000 / 5);
            
            }
            
            if(this.checkAttempt===3 && this.isWinValueAnimateActive3===false){
                
                this.isWinValueAnimateActive3 = true;
                var tmpCheckAtt = this.checkAttempt;
                if(this.winClockAnimationTimer3 != null){
                      clearInterval(this.winClockAnimationTimer3);
                }
                
                if(this.dataModelObj.isSoundPlay === true ){
                	self.dataModelObj.GAME_BG_SOUND.stop();
                	self.dataModelObj.bonusPointsWin.stop().play();
                }
                                
                this.winClockAnimationTimer3 = setInterval(function() {
                    self.winClockAnimation(AnimObj, tmpCheckAtt);
                }, 1000 / 15);
            
            
                if(this.winClockAnimUpdateTimer3 != null){
                      clearInterval(this.winClockAnimUpdateTimer3);
                }
                
                this.winClockAnimUpdateTimer3 = setInterval(function() {
                      if(self.liverCount3==0) {
                    	  clearInterval(self.winClockAnimUpdateTimer3);
                          $("#bonus-point").attr("value", self.totalValue);
                          $("#chance-text").attr("value", parseInt(self.remainingChances));
                          if (self.checkAttempt >= self.chanceAllowed) {
                              self.updateBonusPlayed();
                          }
                      }
                }, 1000 / 5);
            
            }
            
            this.showWinValue(AnimObj);
            this.buttonInitObj.bindEvents();
            
      }
}

/*
* This function is for getting the mouse movement
*/

BonusMain.prototype.updateBonusPlayed = function(){
      var self = this;
      this.showBonusPopupDelayTime = 2000;
      if(this.showBonusPopupTimer != null){
            clearInterval(this.showBonusPopupTimer);
      }
      var self = this;
        if (this.chanceAllowed == this.checkAttempt) {
        	if (this.imageArray.length > 0) {
                this.showLoseValues();
            }
            this.spinService.bonusRoundPlayed();
            var finalWinAmount = parseFloat(this.totalValue * this.coinValue).toFixed(2);
            if (this.showBonusPopupTimer != null) {
                clearInterval(this.showBonusPopupTimer);
            }
            
            this.showBonusPopupTimer = setInterval(function() {
                if (self.dataModelObj.hasErrorInBonusUpadte == false
                        && self.dataModelObj.bIsBonusUpdated == true) {
                    clearInterval(self.showBonusPopupTimer);
                    self.clearContainer();
                    self.spinService.showBonusAmountWinPopup($.i18n.prop("bonus.win.roundAmount", finalWinAmount));
                    if(self.dataModelObj.isSoundPlay === true ){
                        self.dataModelObj.GAME_BG_SOUND.stop();
                        self.dataModelObj.BonusWinPopUp.stop().play();
                    }
                } else if (self.dataModelObj.hasErrorInBonusUpadte === true
                        && self.dataModelObj.bIsBonusUpdated === true) {
                    clearInterval(self.showBonusPopupTimer);
                    self.clearContainer();
                }
            }, this.showBonusPopupDelayTime);
        }
}

BonusMain.prototype.mouseMoveHandler = function(ev) {
      var pos = this.findPos(ev.target);
      var x = ev.pageX - pos.x;
      var y = ev.pageY - pos.y;
      var ratioX = (this.canvasWidth / $('#bonusCanvas').width());
      var ratioY = (this.canvasHeight / $('#bonusCanvas').height());
      this.changeCursor(x * ratioX, y * ratioY);
}

BonusMain.prototype.changeCursor = function(posX, posY) {
      $('#bonusCanvas').css('cursor', 'default');
      for (var i = 0; i < this.imageArray.length; i++) {

            if (posX >= (this.imageArray[i].x + 40)
                        && posX <= (this.imageArray[i].x
                                    + this.bonusDataModel.animWidth - 45)
                        && posY >= (this.imageArray[i].y + 40)
                        && posY <= (this.imageArray[i].y
                                    + this.bonusDataModel.animHeight - 50)) {
                  $('#bonusCanvas').css('cursor', 'pointer');
            }
      }
}

BonusMain.prototype.canvasClickHandler = function(ev) {
      var pos = this.findPos(ev.target);
      var x = ev.pageX - pos.x;
      var y = ev.pageY - pos.y;
      var ratioX = (1920 / $('#bonusCanvas').width());
      var ratioY = (1080 / $('#bonusCanvas').height());
      this.checkObjectHit(x * ratioX, y * ratioY);
}

/*
* Logic to find the position of cursor
*/
BonusMain.prototype.findPos = function(obj) {
      var curleft = 0, curtop = 0;
      if (obj.offsetParent) {
            do {
                  curleft += obj.offsetLeft;
                  curtop += obj.offsetTop;
            } while (obj = obj.offsetParent);
            return {
                  x : curleft,
                  y : curtop
            };
      }
      return undefined;
}


function BonusDataModel() {
      this.imageSrc = "assests/aliceWonderLand/Bonus/";
      this.animHeight = 231;
      this.animWidth = 254;
      //this.pyramidHight =100;
      this.sndArr = [ "BonusBackGround" ];

}

function BonusButtonInit(bonusMainObj) {
      this.canvasElem = $("#bonusCanvas");
      this.bonusMainObj = bonusMainObj;
}

BonusButtonInit.prototype.bindEvents = function() {
      this.canvasElem.bind('mousemove', $.proxy(
                  this.bonusMainObj.mouseMoveHandler, this.bonusMainObj));
      this.canvasElem.bind('click', $.proxy(this.bonusMainObj.canvasClickHandler,
                  this.bonusMainObj));
}

BonusButtonInit.prototype.unBindEvents = function() {
      this.canvasElem.unbind('mousemove', $.proxy(
                  this.bonusMainObj.mouseMoveHandler, this.bonusMainObj));
      this.canvasElem.unbind('click', $.proxy(
                  this.bonusMainObj.canvasClickHandler, this.bonusMainObj));
}

/*
* This method is for the animation of tnt box while clicking on the dynamite
*/

BonusMain.prototype.winClockAnimation = function(AnimValueObj,tmpCheckAttempt) {
    var self = this;
    this.numFrames = 2;

    if(tmpCheckAttempt===1){
        for(var i=0; i<this.matchValuePosArr1.length;i++) {
            var AnimObj = this.matchValuePosArr1[i];
            this.ctx.clearRect(AnimObj.x, AnimObj.y, this.bonusDataModel.animWidth,
                      this.bonusDataModel.animHeight);
            
            this.ctx.drawImage(this.winClockspriteImage1, this.bonusDataModel.animWidth
                          * this.liverCount1, 0, this.bonusDataModel.animWidth,
                          this.bonusDataModel.animHeight, AnimObj.x, AnimObj.y,
                          this.bonusDataModel.animWidth, this.bonusDataModel.animHeight);
            this.showWinValue(AnimObj);
        }
        this.liverCount1++;
        if (this.liverCount1 >= this.numFrames) {
            this.liverCount1 = 0;
        }
    }
    
    if(tmpCheckAttempt===2){
        for(var i=0; i<this.matchValuePosArr2.length;i++) {
            var AnimObj2 = this.matchValuePosArr2[i];
            this.ctx.clearRect(AnimObj2.x, AnimObj2.y, this.bonusDataModel.animWidth,
                      this.bonusDataModel.animHeight);
            
            this.ctx.drawImage(this.winClockspriteImage2, this.bonusDataModel.animWidth
                          * this.liverCount2, 0, this.bonusDataModel.animWidth,
                          this.bonusDataModel.animHeight, AnimObj2.x, AnimObj2.y,
                          this.bonusDataModel.animWidth, this.bonusDataModel.animHeight);
            this.showWinValue(AnimObj2);
        }
        this.liverCount2++;
        if (this.liverCount2 >= this.numFrames) {
            this.liverCount2 = 0;
        }
    }
    
    if(tmpCheckAttempt===3){
        for(var i=0; i<this.matchValuePosArr3.length;i++) {
            var AnimObj3 = this.matchValuePosArr3[i];
            this.ctx.clearRect(AnimObj3.x, AnimObj3.y, this.bonusDataModel.animWidth,
                      this.bonusDataModel.animHeight);
            
            this.ctx.drawImage(this.winClockspriteImage3, this.bonusDataModel.animWidth
                          * this.liverCount3, 0, this.bonusDataModel.animWidth,
                          this.bonusDataModel.animHeight, AnimObj3.x, AnimObj3.y,
                          this.bonusDataModel.animWidth, this.bonusDataModel.animHeight);
            this.showWinValue(AnimObj3);
        }
        this.liverCount3++;
        if (this.liverCount3 >= this.numFrames) {
            this.liverCount3 = 0;
        }
    }
    
}

BonusMain.prototype.showWinValue = function(AnimObj) {
    var self = this;
    this.ctx.fillStyle = "#fff";
    this.ctx.font = "bold 50pt Klavika";
    this.ctx.shadowOffsetX = 5;
    this.ctx.shadowOffsetY = 5;
    this.ctx.shadowBlur = 10;
    this.ctx.textAlign = 'center';
    this.ctx.strokeStyle = "#fad4d4";
    this.ctx.lineWidth = 5; 
    this.ctx.strokeText(AnimObj.value, AnimObj.x + 128, AnimObj.y + (this.bonusDataModel.animHeight -70));
    this.ctx.fillText(AnimObj.value, AnimObj.x + 128, AnimObj.y + (this.bonusDataModel.animHeight -70));
}

BonusMain.prototype.showLoseValues = function () {
    for (var valueCount = 0; valueCount < this.imageArray.length; valueCount++) {
        this.ctx.fillStyle = "#112102";
        this.ctx.font = "bold 60pt Klavika";
        this.ctx.textAlign = 'center';
        this.ctx.strokeStyle = "#fff";
        this.ctx.lineWidth = 5;
        this.ctx.strokeText(this.imageArray[valueCount].value, this.imageArray[valueCount].x + 130, this.imageArray[valueCount].y + 160);
        this.ctx.fillText(this.imageArray[valueCount].value, this.imageArray[valueCount].x + 130, this.imageArray[valueCount].y + 160);
  }
}


BonusMain.prototype.bonusGameAliceSounds = function() {
 if (this.dataModelObj.clickToPlayGame == null) {
     this.dataModelObj.clickToPlayGame = new Howl({
         urls : [ this.dataModelObj.soundSrc + 'ButtonClick.mp3',
                 this.dataModelObj.soundSrc + 'ButtonClick.wav' ]
     });
 }

 if (this.dataModelObj.bonusPointsWin == null) {
     this.dataModelObj.bonusPointsWin = new Howl({
         urls : [ this.dataModelObj.soundSrc + 'BonusPointWinsound.mp3',
                 this.dataModelObj.soundSrc + 'BonusPointWinsound.wav' ]
     });
 }

 if (this.dataModelObj.BonusWinPopUp == null) {
     this.dataModelObj.BonusWinPopUp = new Howl({
         urls : [ this.dataModelObj.soundSrc + 'BonusCongratulationPopup.mp3',
                 this.dataModelObj.soundSrc + 'BonusCongratulationPopup.wav' ]
     });
 }
 
};
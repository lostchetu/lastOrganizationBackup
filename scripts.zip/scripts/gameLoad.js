
$(document).ready(function() {
    var dataModelObj = new DataModel();
    loadGame(dataModelObj);
    loadBundles("en");
});

window.addEventListener('resize', function () {
    setTimeout(function () {
        loadfitTextResizer();
    }, 500);
});

/*
 * This function calls when the game load by hitting on server.
 */

function loadGame(dataModelObj) {
    this.dataModelObj = dataModelObj;
    this.errorMessageObj = new ErrorMessage(this.dataModelObj);
    var spinSource = $("#spinSource").val();
    var spinToken = $("#spinToken").val();
    var gameType = $("#gameType").val();
    var loadUrl ="";

    $.ajax({
          cache: false,
          url: "loadGame?spinSource="+spinSource+"&spinToken="+spinToken,
          type: "POST",
          datatype: "json",
          success: function (response) {
                    if(response.responseStr){
                       dataModelObj.responseStr = response.responseStr;
                    dataModelObj.payTableResponse = response.payTableResponse;
                        if(response.spinToken){
                            $('#spinToken').val(response.spinToken);
                        }
                     }else if(response.hasError){
                         var json = JSON.parse(JSON.stringify(response));
                         self.errorMessageObj.formatErrorMessage(json.ErrorCode);
                       }else {
                           self.errorMessageObj.formatErrorMessage(-1);
                         }
                       var preObj = new PreLoader(dataModelObj); 
              },
               error: function (error) {
              }
          });
}

function loadBundles(lang) {
    jQuery.i18n.properties({
        name:'Messages', 
        path:'messageResource/', 
        mode:'map',
        language:lang
    });
}
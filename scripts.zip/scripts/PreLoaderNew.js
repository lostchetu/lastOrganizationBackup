/*global PreLoader, dataModel, Image, Spin,console, setTimeout
 * this method load all js and image assests at loading time.
 * */

 function PreLoader(dataModelObj) {
     /*for orientation-change*/
    
     $(window).on('orientationchange', function () {
            window.scrollTo(0, 0);
        });
     /*for orientation-change*/
     this.preloaderPopUp = $('<div id="preloaderHandler" class="loader"><div class="loader-wrapper"><div class="loader-logo"></div><span id="timer">Loading : 0%</span><div class="gameloading"><div class="progress-bar"></div></div></div></div>');
      $("body").append(this.preloaderPopUp);
      //defining the temporory variables 
      var canvasAreaWidth = $(".canvas-area").width();
      var canvasModWidth = canvasAreaWidth * (57/100)
      this.imageCounter = 0;
      this.imageLoaded = 0;
   //instantiating the global DataModel class
      this.dataModelObj = dataModelObj;
      this.canvas = document.getElementById("gameCanvas");//getting canvas id
      if (this.canvas.getContext) {
         this.ctx = this.canvas.getContext("2d");
      } else {
         console.log("canvas doesn't have context",canvas);
     }
   this.canvasW = ((this.dataModelObj.imageWidth + 10) * this.dataModelObj.columnCount)-10;//setting the width of canvas dynamically according to imageWidth and no of columns
   this.canvasH =((this.dataModelObj.imageHeight+10 ) * this.dataModelObj.rowCount)-10;//setting the height of canvas dynamically according to imagehehight and no of columns
   this.canvas.setAttribute("width", this.canvasW);
   this.canvas.setAttribute("height", this.canvasH);
   this.dataModelObj.canvasHeight = this.canvasH;
   this.dataModelObj.canvasHeight = this.canvasW;
   //instantiating the spin class and pass the reference of dataModel class
   this.errorMessageObj = new ErrorMessage(this.dataModelObj);
   this.stringSplitObj = new StringSplitter(this.dataModelObj,this.errorMessageObj);
   this.stringSplitObj.initialDisplayData();
   this.Spin_obj=new Spin(this.ctx, this.dataModelObj,this.stringSplitObj,this.errorMessageObj);
   this.loadImages();
 }
 
 PreLoader.prototype.loadImages = function(){
    for(var i=0 ; i<this.dataModelObj.imageArray.length; i++) {
        var imageObj = new ImageObj(this.dataModelObj.imageSrc+this.dataModelObj.imageArray[i],this);
        imageObj.name = this.dataModelObj.imageArray[i];
        this.Spin_obj.imageHolderArr.push(imageObj)
    }
    for(var j=0 ; j<this.dataModelObj.imageArray.length; j++) {
        var imageObj = new ImageObj(this.dataModelObj.animSrc+this.dataModelObj.imageArray[j],this);
        imageObj.name = this.dataModelObj.imageArray[j];
        this.Spin_obj.animHolderArr.push(imageObj)
    }
 }
 
 PreLoader.prototype.moveBar = function (loaded) {
  if(loaded == 20) {
     this.Spin_obj.initializeInterface();
  }
};


function loadfitTextResizer() {
    $("#wrapper").resizer(1.77);
    $('#paytable_lightbox').fitText(4.8);
    $("#wrapper").fitText(3.3);
    $(".errorpopup-container").resizer(1.3);
}

window.onresize = function() {
  var canvasAreaWidth = $(".canvas-area").width();
  var canvasModWidth = canvasAreaWidth * (57/100);
  loadfitTextResizer();
}

/*
 * This method calls at the time of game loading. 
 */

window.onload=function() {
    var self = this;
    var preloadercount = 0;
	// code for preloader page window
	preloadercountTimer = setInterval(function() {
		$('#timer').text("Loading : " + preloadercount + '%');
		$('.progress-bar').css({
			'width' : preloadercount + '%'
		}).addClass('loader-progress');
		preloadercount += 1;
		if (preloadercount == 100) {
			clearInterval(preloadercountTimer);
		//	gameLoader.stop();
			$(".main").css("display", "block");
			loadfitTextResizer();
			setTimeout(function() {
				$('#blackdiv').remove();
				$('#preloaderHandler').fadeOut('slow', function() {
					$(this).remove();
					window.scrollTo(0, 1);
				});

			}, 100);
		}
	}, 100);

	AllButtonClickEvent();
	loadfitTextResizer();
};

/*
 * This method calls on all button click events and add class on buttons.
 */
function AllButtonClickEvent() {
    var allEventHandlers = ".paytable-btn,.betone,.spin_btn, .betmax, .right-arrow, .left-arrow,.sound_btn, .history-btn,.help-btn, .freespin-btn, .exit-btn,.coinright-arrow,.coinleft-arrow";
    $(allEventHandlers ).mouseup(function() {$( this ).removeClass( "active" );})
    .mousedown(function() {    $( this ).addClass( "active" );
    });
}

function getCurrentGameAssestFolderByURL() {
	var currGameName = window.location.pathname;
    var n = currGameName.lastIndexOf("/")+1;
    currGameName = currGameName.substr(n, currGameName.length);
    currGameName = currGameName.substr(0, ((currGameName.length)-11));
    currGameName = currGameName.charAt(0).toLowerCase() + currGameName.slice(1);
    return currGameSoundPath
}

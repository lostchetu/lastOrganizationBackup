/*global ImageObj, Image */
/*this js use to define and create new image object*/
function ImageObj(src,preObj) {
    "use strict";
    this.img = new Image();
    this.src = src;
    this.xpos = 0;
    this.ypos = 0;
    this.name = "*";
    this.value = -1;
    this.rendered = false;
    this.id = 0;
    this.vy = 0;
    this.width = 0;
    this.height = 0;
    this.visible = true;
    this.imageLoaded = 0;
    this.draw(preObj);
}
ImageObj.prototype.draw = function (preObj) {
    "use strict";
    var loaded, self = this;
    this.img.src = this.src;
    this.img.onload = function () {
    loaded = preObj.imageLoaded += 1;
    preObj.moveBar(loaded);
    }
};
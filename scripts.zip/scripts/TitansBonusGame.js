function BonusMain(spinServiceObj, totalArrayValues, symbolValues,
        chanceAllowed, coinValue, dataModelObj, stringSplitObj) {
    "use strict";
    var self = this;

    this.chanceAllowed = chanceAllowed;
    this.dataModelObj = dataModelObj;
    this.stringSplit = stringSplitObj;
    this.spinService = spinServiceObj;

    if (this.dataModelObj.bonusGameVisible === false) {
        this.dataModelObj.bonusGameVisible = true;
        this.symbolValue = symbolValues;
        this.coinValue = coinValue;
        if (chanceAllowed > 1) {
            this.valueArr = this.symbolValue;
        } else {
            this.valueArr = new Array(this.symbolValue);
        }
       
        $('.bonus-canvas-back').show();
        if ($('.bonus-canvas-container')) {
            $('.bonus-canvas-container').show();
            $(".transGamebg").show();
        }

        this.wonValues = "";
        this.bonusIndex = 0;

        this.spriteBackground = new Image();
        this.StoneImage = new Image();
        this.zeusImage = new Image();
        this.clickImage = new Image();
        this.ZeusAnimationImage = new Image();
        this.stoneBlastAnimationImage = new Image();
        this.diamondImage = new Image();

        this.spriteBackground.src = "assests/titans/Bonus/bonus-screen-image.jpg";
        this.zeusImage.src = "assests/titans/Bonus/zeus.png";
        this.StoneImage.src = "assests/titans/Bonus/stone.png";

        this.ZeusAnimationImage.src = "assests/titans/Bonus/zeus-animation.png";

        this.diamondImagesArray = [
                "assests/titans/Bonus/diamond.png",
                "assests/titans/Bonus/diamond2.png",
                "assests/titans/Bonus/diamond3.png" ];

        this.diamondImage.src = this.diamondImagesArray[this.bonusIndex];

        this.stoneBlastAnimationArray = [
                "assests/titans/Bonus/stone_blast.png",
                "assests/titans/Bonus/stone_blast_2.png",
                "assests/titans/Bonus/stone_blast_3.png" ];

        this.stoneBlastAnimationImage.src = this.stoneBlastAnimationArray[this.bonusIndex];

        this.isAssestLoaded = false;
        this.isZeusAnimate = false;
        this.istoneBlast = false;
        this.isdiamond = false;

        this.frameCountstone = 0;
        this.frameCountZeusAnimation = 0;
        this.frameCountdiamond = 0;
        this.frameCountStoneblast = 0;
        this.BgframeCount = 0;

        if (this.GameInterval != null) {
            clearInterval(this.GameInterval);
        }
        this.clearContainer();

        this.autocanvas = $("#myCanvas");
        this.ctx = $("#myCanvas")[0].getContext('2d');

        this.ctx.save();
        //Use the identity matrix while clearing the canvas
        this.ctx.setTransform(1, 0, 0, 1, 0, 0);
        this.ctx.clearRect(0, 0, this.autocanvas.width, this.autocanvas.height);
        // Restore the transform
        this.ctx.restore();

        this.totalValue = 0;
        $("#bonus-coin-val").attr("value", "$" + this.coinValue);
        $("#chance-text").attr("value", this.chanceAllowed);
        $("#bonus-point").attr("value", this.totalValue);

        this.clickToplay = $("#clickToPlay");
        this.valueContainer = $(".input-field");
        this.GameInterval = null;

        this.showBonusPopupTimer = null;
        this.textFade = null;
        
        if(this.dataModelObj.GAME_BG_SOUND != null ){
        	this.dataModelObj.GAME_BG_SOUND.stop();
        }
        this.init();
		this.addClickEvent();
        this.bonusGameTitansSounds();
    }
}

BonusMain.prototype.init = function() {
    "use strict";
    var self = this;
    if (this.GameInterval != null) {
        clearInterval(this.GameInterval);
    }
    this.GameInterval = setInterval(function() {
        self.TitanBackground();
        if (self.isZeusAnimate === true) {
            self.ZeusAnimation();
        } else if (self.istoneBlast === true) {
            self.stoneBlastAnimation();
        } else if (self.isdiamond === true) {
            self.diamondAnimation();
            self.baseZeus();
        } else {
            self.stoneAnimation();
            self.baseZeus();
            $("#win-value").css("display", "none");
        }
    }, 250);
}

BonusMain.prototype.TitanBackground = function() {
    "use strict";
    var numFrames = 15
    var frameSize = 1920;
    if (numFrames > this.BgframeCount) {
        this.ctx.clearRect(0, 0, frameSize, 1080);
        this.ctx.drawImage(this.spriteBackground,
                frameSize * this.BgframeCount, 0, frameSize, 1080, 0, 0,
                frameSize, 1080);
        this.BgframeCount++;
        if (4 === this.BgframeCount && false === this.isAssestLoaded) {
            this.clickToplay.css("display", "block");
            this.valueContainer.css("display", "block");
            this.isAssestLoaded = true;
        }
        if (this.BgframeCount == numFrames) {
            this.BgframeCount = 0;
        }
    }
}

BonusMain.prototype.clearContainer = function() {
    "use strict";
    var self = this;
    if (this.GameInterval != null) {
        clearInterval(this.GameInterval);
    }
    
    if (this.textFade != null) {
        clearInterval(this.textFade);
    }
}
BonusMain.prototype.baseZeus = function() {
    this.ctx.drawImage(this.zeusImage, 0, 252, 328, 828);
}

BonusMain.prototype.stoneAnimation = function() {
   "use strict";
    var numFrames = 10;
    var frameSize = 400;
    if (numFrames > this.frameCountstone) {
        this.ctx.clearRect(0, 0, 0, 1080);
        this.ctx.drawImage(this.StoneImage, frameSize * this.frameCountstone,
                0, frameSize, 400, 805, 75, frameSize, 400);
        this.frameCountstone++;
        if (this.frameCountstone == numFrames) {
            this.frameCountstone = 0;
        }
    }
}

BonusMain.prototype.ZeusAnimation = function() {
    "use strict";
    var numFrames = 8;
    var frameSize = 1284;
    if (numFrames > this.frameCountZeusAnimation) {
        this.ctx.clearRect(0, 0, 0, 1080);
        this.ctx.drawImage(this.ZeusAnimationImage, frameSize
                * this.frameCountZeusAnimation, 0, frameSize, 1080, 0, 0,
                frameSize, 1080);
        this.frameCountZeusAnimation++;
        if(this.dataModelObj.isSoundPlay === true && this.frameCountZeusAnimation == 1 ){
        	this.dataModelObj.GAME_BG_SOUND.stop();
            this.dataModelObj.magicSpell.stop().play();
        }
        if (this.frameCountZeusAnimation == numFrames) {
            this.frameCountZeusAnimation = 0;
            this.isZeusAnimate = false;
            this.istoneBlast = true;
        
        }
    }
}

BonusMain.prototype.stoneBlastAnimation = function() {
    "use strict";
    var numFrames = 5;
    var frameSize = 1920;
    if (numFrames > this.frameCountStoneblast) {
        this.ctx.clearRect(0, 0, 0, 655);
        this.ctx.drawImage(this.stoneBlastAnimationImage, frameSize
                * this.frameCountStoneblast, 0, frameSize, 1080, 0, 0,
                frameSize, 1080);
        this.frameCountStoneblast++;
        if(this.dataModelObj.isSoundPlay === true && this.frameCountStoneblast == 3 ){
        	this.dataModelObj.GAME_BG_SOUND.stop();
        	this.dataModelObj.magicSpell.stop();
        	this.dataModelObj.bonusBlast.stop().play();
        }
        if (this.frameCountStoneblast == numFrames) {
            this.frameCountStoneblast = 0;
            this.istoneBlast = false;
            this.isdiamond = true;
        }
    }
}

BonusMain.prototype.diamondAnimation = function() {
    "use strict";
    var numFrames = 5;
    var frameSize = 736;
    if (numFrames > this.frameCountdiamond) {
        this.ctx.clearRect(0, 0, 0, 655);
        this.ctx.drawImage(this.diamondImage, frameSize
                * this.frameCountdiamond, 0, frameSize, 658, 640, 0, frameSize,
                658);
        this.frameCountdiamond++;
        if(this.dataModelObj.isSoundPlay === true && this.frameCountdiamond == 1){
        	this.dataModelObj.GAME_BG_SOUND.stop();
            this.dataModelObj.bonusPointsWin.stop().play();
        }
        
        if (this.frameCountdiamond == 2) {
            this.chanceAllowed--;
            if (parseInt((this.chanceAllowed)) > 1) {
                $("#chance-text").attr("value", this.chanceAllowed);
            } else {
                $("#chance-text").attr("value", this.chanceAllowed);
            }

            this.currentValue = this.valueArr[this.bonusIndex];
            ++this.bonusIndex;
            
            this.totalValue += parseInt(this.currentValue);
            this.wonValues = this.wonValues.concat(this.currentValue + ",");
            $("#win-value").css("display", "block");
            $('#win-value').addClass('color' + this.bonusIndex );
            $("#win-value").empty().append("" + this.currentValue + "");
            $("#bonus-point").attr("value", this.totalValue);
            if (this.chanceAllowed == 0) {
                this.soundArr = [];
                this.spinService.bonusRoundPlayed();
            }
        }

        if (this.frameCountdiamond == 5) {
            if (this.chanceAllowed > 0) {
                this.addClickEvent();
            } else {
                this.showWinAmountPopup();
            }
        }

        if (this.frameCountdiamond == numFrames) {
            this.isdiamond = false;
            this.frameCountdiamond = 0;
        }
    }
}

BonusMain.prototype.showWinAmountPopup = function() {
    "use strict";
    var self = this;
    this.showBonusPopupDelayTime = 1000;
    if (this.chanceAllowed == 0) {
        this.removeClickEvent();
        var finalWinAmount = parseFloat(this.totalValue * this.coinValue)
                .toFixed(2);
        if (this.showBonusPopupTimer != null) {
            clearInterval(this.showBonusPopupTimer);
        }
        this.showBonusPopupTimer = setInterval(function() {
            if (self.dataModelObj.hasErrorInBonusUpadte == false
                    && self.dataModelObj.bIsBonusUpdated == true) {
                clearInterval(self.showBonusPopupTimer);
                self.clearContainer();
                self.spinService.showBonusAmountWinPopup($.i18n.prop(
                        "bonus.win.roundAmount", finalWinAmount));
                if(self.dataModelObj.isSoundPlay === true ){
                	self.dataModelObj.GAME_BG_SOUND.stop();
                    self.dataModelObj.BonusWinPopUp.stop().play();
                }
            } else if (self.dataModelObj.hasErrorInBonusUpadte === true
                    && self.dataModelObj.bIsBonusUpdated === true) {
                clearInterval(self.showBonusPopupTimer);
                self.clearContainer();
            }
        }, this.showBonusPopupDelayTime);
      
        
    }
}

BonusMain.prototype.addClickEvent = function() {
    this.clickToplay.bind("click", $.proxy(this.mouseClickHandler, this));
    this.clickToplay.attr("disabled", false);
    $('#win-value').attr("class","");
};
//for remove click events from button
BonusMain.prototype.removeClickEvent = function() {
    this.clickToplay.attr("disabled", true);
    this.clickToplay.unbind("click", $.proxy(this.mouseClickHandler, this));
};

BonusMain.prototype.mouseClickHandler = function(ev) {
    "use strict";
    if (this.chanceAllowed > 0) {
        this.diamondImage.src = this.diamondImagesArray[this.bonusIndex];
        this.stoneBlastAnimationImage.src = this.stoneBlastAnimationArray[this.bonusIndex];
        this.isZeusAnimate = true;
        if(this.dataModelObj.isSoundPlay === true ){
            this.dataModelObj.clickToPlay.stop().play();
        }
        this.removeClickEvent();
    }
}


BonusMain.prototype.bonusGameTitansSounds = function() {
	
	if (this.dataModelObj.magicSpell == null) {
		this.dataModelObj.magicSpell = new Howl({
			urls : [ this.dataModelObj.soundSrc + 'magicSpell.mp3',
					this.dataModelObj.soundSrc + 'magicSpell.wav' ]
		});
	}

	if (this.dataModelObj.clickToPlay == null) {
		this.dataModelObj.clickToPlay = new Howl({
			urls : [ this.dataModelObj.soundSrc + 'ButtonClick.mp3',
					this.dataModelObj.soundSrc + 'ButtonClick.wav' ]
		});
	}

	if (this.dataModelObj.bonusPointsWin == null) {
		this.dataModelObj.bonusPointsWin = new Howl({
			urls : [ this.dataModelObj.soundSrc + 'BonusPointWinsound.mp3',
					this.dataModelObj.soundSrc + 'BonusPointWinsound.wav' ]
		});
	}

	if (this.dataModelObj.bonusBlast == null) {
		this.dataModelObj.bonusBlast = new Howl({
			urls : [ this.dataModelObj.soundSrc + 'explosion.mp3',
					this.dataModelObj.soundSrc + 'explosion.wav' ]
		});
	}

	if (this.dataModelObj.BonusWinPopUp == null) {
		this.dataModelObj.BonusWinPopUp = new Howl({
			urls : [ this.dataModelObj.soundSrc + 'BonusCongratulationPopup.mp3',
					this.dataModelObj.soundSrc + 'BonusCongratulationPopup.wav' ]
		});
	}
};

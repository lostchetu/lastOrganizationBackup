/*
 * This method is for the resizing of the canvas
 */
(function ($) {
    $.fn.resizer = function (p) {
        // Setup options
        var preportion = p || 1;
        return this.each(function () {
            // Store the object
            var $this = $(this);
            var reSizer = function () {
                var parentHeight = $this.parent().height();
                var parentWidth = $this.parent().width();
                if (parentHeight * preportion >= parentWidth) {
                    $this.css('width', parentWidth);
                    $this.css('height', parentWidth / preportion);
                    $this.css('top', (parentHeight - (parentWidth / preportion)) / 2);
                }
                else {
                    $this.css('height', parentHeight);
                    $this.css('width', parentHeight * preportion);
                    $this.css('top', 0);
                }
            };
            // Call once to set.  
            reSizer();
            // Call on resize. Opera debounces their resize by default.
            $(window).on('load.resizer resize.resizer orientationchange.resizer', reSizer);
        });

    };
})(jQuery);
/*This function loads all model object, string splitter object,chances and scores */
function BonusMain(spinServiceObj, totalScores, symbolValues, chanceAllowed,
        coinValue, dataModelObj, stringSplitObj) {

    var self = this;

    this.dataModelObj = dataModelObj;
    this.stringSplit = stringSplitObj;
    this.spinService = spinServiceObj;
    
    if (this.dataModelObj.bonusGameVisible === false) {
        this.dataModelObj.bonusGameVisible = true;
        this.chanceAllowed = chanceAllowed;
        this.totalScores = totalScores;
        this.symbolValue = symbolValues;

        this.coinValue = coinValue;
        this.valueArr = this.totalScores;

        $('.bonus-canvas-back').show();
        if ($('.bonus-canvas-container')) {
            $('.bonus-canvas-container').show();
            $(".transGamebg").show();
        }
        this.bonusDataModel = new BonusDataModel();
        this.buttonInitObj = new BonusButtonInit(this);
        this.canvasWidth = $('#bonusCanvas').attr("width");
        this.canvasHeight = $('#bonusCanvas').attr("height");
        this.frameCount = 0;
        this.ctx = $('#bonusCanvas')[0].getContext('2d');

        $("#bonus-coin-val").attr("value", "$" + this.coinValue);
        $("#chance-text").attr("value", this.chanceAllowed);
        this.remainingChances = this.chanceAllowed;
        this.chancesRemainingToPlayed = this.chanceAllowed;

        this.imageArray = [];
        this.checkAttempt = 0;
        this.tempClickAttempt = 0;
        this.totalValue = 0;
        $("#bonus-point").attr("value", this.totalValue);
        this.animTimer = 0;
        this.liverCount = 0;

        this.ctx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
        this.soundArr = [];
        this.clockx = 110;
        this.clocky = 108;

        this.blenderImage = new Image();
        this.blenderImage.src = "assests/juicyFruits/Bonus/blender.png";

        this.tempWinValueArray = this.symbolValue;
        this.tempWinUnmatchArray = this.symbolValue;
        this.clickedImgArray = [];

        this.remainingChances = -1;
        this.bonusDataModel.imageSrc = 'assests/juicyFruits/Bonus/';

        var apple_anim_1 = new Image();
        apple_anim_1.src = this.bonusDataModel.imageSrc
                + "/animations/apple-anim-1.png";

        var banana_anim_2 = new Image();
        banana_anim_2.src = this.bonusDataModel.imageSrc
                + "/animations/banana-anim-2.png";

        var cherry_anim_3 = new Image();
        cherry_anim_3.src = this.bonusDataModel.imageSrc
                + "/animations/cherry-anim-3.png";

        var grapes_anim_4 = new Image();
        grapes_anim_4.src = this.bonusDataModel.imageSrc
                + "/animations/grapes-anim-4.png";

        var kiwi_anim_5 = new Image();
        kiwi_anim_5.src = this.bonusDataModel.imageSrc
                + "/animations/kiwi-anim-5.png";

        var raspberry_anim_6 = new Image();
        raspberry_anim_6.src = this.bonusDataModel.imageSrc
                + "/animations/raspberry-anim-6.png";

        var pear_anim_7 = new Image();
        pear_anim_7.src = this.bonusDataModel.imageSrc
                + "/animations/pear-anim-7.png";

        var peach_anim_8 = new Image();
        peach_anim_8.src = this.bonusDataModel.imageSrc
                + "/animations/peach-anim-8.png";

        var watermelon_anim_9 = new Image();
        watermelon_anim_9.src = this.bonusDataModel.imageSrc
                + "/animations/watermelon-anim-9.png";

        var orange_anim_10 = new Image();
        orange_anim_10.src = this.bonusDataModel.imageSrc
                + "/animations/orange-anim-10.png";

        var strawberry_anim_11 = new Image();
        strawberry_anim_11.src = this.bonusDataModel.imageSrc
                + "/animations/strawberry-anim-11.png";

        var pineapple_anim_12 = new Image();
        pineapple_anim_12.src = this.bonusDataModel.imageSrc
                + "/animations/pineapple-anim-12.png";

        var image1 = new Image();
        image1.src = this.bonusDataModel.imageSrc + 'bonus-icon-1.png';

        var image2 = new Image();
        image2.src = this.bonusDataModel.imageSrc + 'bonus-icon-2.png';

        var image3 = new Image();
        image3.src = this.bonusDataModel.imageSrc + 'bonus-icon-3.png';

        var image4 = new Image();
        image4.src = this.bonusDataModel.imageSrc + 'bonus-icon-4.png';

        var image5 = new Image();
        image5.src = this.bonusDataModel.imageSrc + 'bonus-icon-5.png';

        var image6 = new Image();
        image6.src = this.bonusDataModel.imageSrc + 'bonus-icon-10.png';

        var image7 = new Image();
        image7.src = this.bonusDataModel.imageSrc + 'bonus-icon-8.png';

        var image8 = new Image();
        image8.src = this.bonusDataModel.imageSrc + 'bonus-icon-7.png';

        var image9 = new Image();
        image9.src = this.bonusDataModel.imageSrc + 'bonus-icon-12.png';

        var image10 = new Image();
        image10.src = this.bonusDataModel.imageSrc + 'bonus-icon-6.png';

        var image11 = new Image();
        image11.src = this.bonusDataModel.imageSrc + 'bonus-icon-11.png';

        var image12 = new Image();
        image12.src = this.bonusDataModel.imageSrc + 'bonus-icon-9.png';

        this.path1 = [ {
            x : 45,
            y : 45
        }, {
            x : 45,
            y : 20
        }, {
            x : 45,
            y : 45
        }, {
            x : 45,
            y : 20
        }, {
            x : 45,
            y : 30
        }, {
            x : 360,
            y : 35
        }, {
            x : 640,
            y : 45
        }, {
            x : 1250,
            y : 45
        }, {
            x : 1250,
            y : 50
        }, {
            x : 1250,
            y : 90
        }, {
            x : 1250,
            y : 120
        } ];
        this.path2 = [ {
            x : 360,
            y : 40
        }, {
            x : 360,
            y : 30
        }, {
            x : 360,
            y : 40
        }, {
            x : 360,
            y : 20
        }, {
            x : 360,
            y : 40
        }, {
            x : 640,
            y : 35
        }, {
            x : 640,
            y : 30
        }, {
            x : 950,
            y : 40
        }, {
            x : 1250,
            y : 120
        } ];
        this.path3 = [ {
            x : 640,
            y : 40
        }, {
            x : 640,
            y : 30
        }, {
            x : 640,
            y : 40
        }, {
            x : 640,
            y : 20
        }, {
            x : 640,
            y : 40
        }, {
            x : 950,
            y : 35
        }, {
            x : 950,
            y : 30
        }, {
            x : 950,
            y : 40
        }, {
            x : 1250,
            y : 120
        } ];
        this.path4 = [ {
            x : 950,
            y : 40
        }, {
            x : 950,
            y : 30
        }, {
            x : 950,
            y : 40
        }, {
            x : 1250,
            y : 20
        }, {
            x : 1250,
            y : 40
        }, {
            x : 1250,
            y : 35
        }, {
            x : 1250,
            y : 30
        }, {
            x : 1250,
            y : 40
        }, {
            x : 1250,
            y : 120
        } ];

        this.path5 = [ {
            x : 79,
            y : 348
        }, {
            x : 79,
            y : 248
        }, {
            x : 79,
            y : 348
        }, {
            x : 79,
            y : 280
        }, {
            x : 79,
            y : 250
        }, {
            x : 360,
            y : 200
        }, {
            x : 620,
            y : 188
        }, {
            x : 950,
            y : 150
        }, {
            x : 950,
            y : 150
        }, {
            x : 1150,
            y : 148
        }, {
            x : 1250,
            y : 148
        }

        ];
        this.path6 = [ {
            x : 360,
            y : 348
        }, {
            x : 360,
            y : 258
        }, {
            x : 360,
            y : 348
        }, {
            x : 360,
            y : 250
        }, {
            x : 360,
            y : 260
        }, {
            x : 360,
            y : 200
        }, {
            x : 620,
            y : 188
        }, {
            x : 950,
            y : 150
        }, {
            x : 950,
            y : 150
        }, {
            x : 1150,
            y : 148
        }, {
            x : 1250,
            y : 148
        }

        ];
        this.path7 = [ {
            x : 630,
            y : 348
        }, {
            x : 630,
            y : 235
        }, {
            x : 630,
            y : 348
        }, {
            x : 630,
            y : 235
        }, {
            x : 630,
            y : 200
        }, {
            x : 630,
            y : 188
        }, {
            x : 620,
            y : 150
        }, {
            x : 950,
            y : 150
        }, {
            x : 1150,
            y : 148
        }, {
            x : 1250,
            y : 148
        }

        ];
        this.path8 = [ {
            x : 950,
            y : 340
        }, {
            x : 950,
            y : 355
        }, {
            x : 950,
            y : 340
        }, {
            x : 950,
            y : 355
        }, {
            x : 950,
            y : 340
        }, {
            x : 950,
            y : 225
        }, {
            x : 950,
            y : 200
        }, {
            x : 1100,
            y : 185
        }, {
            x : 1150,
            y : 155
        }, {
            x : 1250,
            y : 155
        }

        ];

        this.path9 = [ {
            x : 87,
            y : 660
        }, {
            x : 87,
            y : 560
        }, {
            x : 87,
            y : 660
        }, {
            x : 87,
            y : 560
        }, {
            x : 87,
            y : 660
        }, {
            x : 87,
            y : 550
        }, {
            x : 87,
            y : 500
        }, {
            x : 87,
            y : 450
        }, {
            x : 87,
            y : 400
        }, {
            x : 360,
            y : 350
        }, {
            x : 640,
            y : 300
        }, {
            x : 850,
            y : 250
        }, {
            x : 950,
            y : 200
        }, {
            x : 1200,
            y : 150
        }, {
            x : 1250,
            y : 150
        }, {
            x : 1300,
            y : 150
        }

        ];
        this.path10 = [ {
            x : 360,
            y : 660
        }, {
            x : 360,
            y : 560
        }, {
            x : 360,
            y : 660
        }, {
            x : 360,
            y : 600
        }, {
            x : 360,
            y : 560
        }, {
            x : 360,
            y : 500
        }, {
            x : 360,
            y : 450
        }, {
            x : 460,
            y : 400
        }, {
            x : 560,
            y : 350
        }, {
            x : 640,
            y : 300
        }, {
            x : 850,
            y : 250
        }, {
            x : 950,
            y : 200
        }, {
            x : 1200,
            y : 150
        }, {
            x : 1250,
            y : 150
        }

        ];

        this.path11 = [ {
            x : 640,
            y : 660
        }, {
            x : 640,
            y : 560
        }, {
            x : 640,
            y : 660
        }, {
            x : 640,
            y : 600
        }, {
            x : 640,
            y : 560
        }, {
            x : 640,
            y : 500
        }, {
            x : 640,
            y : 450
        }, {
            x : 640,
            y : 400
        }, {
            x : 640,
            y : 350
        }, {
            x : 740,
            y : 300
        }, {
            x : 840,
            y : 250
        }, {
            x : 950,
            y : 200
        }, {
            x : 1150,
            y : 150
        }, {
            x : 1200,
            y : 150
        }, {
            x : 1250,
            y : 150
        }

        ];

        this.path12 = [ {
            x : 950,
            y : 660
        }, {
            x : 950,
            y : 560
        }, {
            x : 950,
            y : 660
        }, {
            x : 950,
            y : 600
        }, {
            x : 950,
            y : 560
        }, {
            x : 950,
            y : 500
        }, {
            x : 950,
            y : 450
        }, {
            x : 950,
            y : 400
        }, {
            x : 950,
            y : 350
        }, {
            x : 1000,
            y : 300
        }, {
            x : 1050,
            y : 250
        }, {
            x : 1100,
            y : 200
        }, {
            x : 1150,
            y : 185
        }, {
            x : 1150,
            y : 180
        }, {
            x : 1200,
            y : 175
        }, {
            x : 1250,
            y : 170
        }

        ];

        image1.onload = function() {
            self.ctx.drawImage(image1, 45, 40, 260, 240);
        }

        image2.onload = function() {
            self.ctx.drawImage(image2, 360, 40, 260, 240);
        }

        image3.onload = function() {
            self.ctx.drawImage(image3, 640, 40, 260, 240);
        }

        image4.onload = function() {
            self.ctx.drawImage(image4, 950, 40, 260, 240);
        }

        this.imageTray1 = [ {
            img : image1,
            id : 1,
            x : 45,
            y : 40,
            sw : 260,
            sh : 240,
            movePath : this.path1,
            isClicked : false,
            animateImg : apple_anim_1
        }, {
            img : image2,
            id : 2,
            x : 360,
            y : 40,
            sw : 260,
            sh : 240,
            movePath : this.path2,
            isClicked : false,
            animateImg : banana_anim_2
        }, {
            img : image3,
            id : 3,
            x : 640,
            y : 40,
            sw : 260,
            sh : 240,
            movePath : this.path3,
            isClicked : false,
            animateImg : cherry_anim_3
        }, {
            img : image4,
            id : 4,
            x : 950,
            y : 40,
            sw : 260,
            sh : 240,
            movePath : this.path4,
            isClicked : false,
            animateImg : grapes_anim_4
        } ];

        image5.onload = function() {
            self.ctx.drawImage(image5, 79, 348, 260, 240);
        }

        image6.onload = function() {
            self.ctx.drawImage(image6, 385, 348, 260, 240);
        }

        image7.onload = function() {
            self.ctx.drawImage(image7, 650, 348, 260, 240);
        }

        image8.onload = function() {
            self.ctx.drawImage(image8, 950, 355, 260, 240);
        }

        this.imageTray2 = [ {
            img : image5,
            id : 5,
            x : 79,
            y : 348,
            sw : 260,
            sh : 240,
            movePath : this.path5,
            isClicked : false,
            animateImg : kiwi_anim_5
        }, {
            img : image6,
            id : 6,
            x : 385,
            y : 348,
            sw : 260,
            sh : 240,
            movePath : this.path6,
            isClicked : false,
            animateImg : raspberry_anim_6
        }, {
            img : image7,
            id : 7,
            x : 650,
            y : 348,
            sw : 260,
            sh : 240,
            movePath : this.path7,
            isClicked : false,
            animateImg : pear_anim_7
        }, {
            img : image8,
            id : 8,
            x : 950,
            y : 355,
            sw : 260,
            sh : 240,
            movePath : this.path8,
            isClicked : false,
            animateImg : peach_anim_8
        } ];

        image9.onload = function() {
            self.ctx.drawImage(image9, 87, 660, 260, 240);
        }

        image10.onload = function() {
            self.ctx.drawImage(image10, 350, 660, 260, 240);
        }

        image11.onload = function() {
            self.ctx.drawImage(image11, 650, 660, 260, 240);
        }

        image12.onload = function() {
            self.ctx.drawImage(image12, 950, 660, 260, 240);
        }
        this.imageTray3 = [ {
            img : image9,
            id : 9,
            x : 87,
            y : 660,
            sw : 260,
            sh : 240,
            movePath : this.path9,
            isClicked : false,
            animateImg : watermelon_anim_9
        }, {
            img : image10,
            id : 10,
            x : 350,
            y : 660,
            sw : 260,
            sh : 240,
            movePath : this.path10,
            isClicked : false,
            animateImg : orange_anim_10
        }, {
            img : image11,
            id : 11,
            x : 650,
            y : 660,
            sw : 260,
            sh : 240,
            movePath : this.path11,
            isClicked : false,
            animateImg : strawberry_anim_11
        }, {
            img : image12,
            id : 12,
            x : 950,
            y : 660,
            sw : 260,
            sh : 240,
            movePath : this.path12,
            isClicked : false,
            animateImg : pineapple_anim_12
        } ];

               
        if(this.dataModelObj.GAME_BG_SOUND != null ){
            this.dataModelObj.GAME_BG_SOUND.stop();
        }
                
        this.initialize();
        this.bonusGameJuicyFruitsSounds();
      
    }
}

BonusMain.prototype.initialize = function() {
    var self = this;
    this.blenderImage.onload = function() {
        self.ctx.drawImage(this, 1209, 415, 547, 666);
        self.drawFruits();
    }
}

BonusMain.prototype.drawFruits = function() {
    var self = this;
    for (var i = 0; i < self.imageTray1.length; i++) {
        this.imageArray.push(self.imageTray1[i]);
    }

    for (var i = 0; i < self.imageTray2.length; i++) {
        this.imageArray.push(self.imageTray2[i]);
    }

    for (var i = 0; i < self.imageTray3.length; i++) {
        this.imageArray.push(self.imageTray3[i]);
    }
    this.buttonInitObj.bindEvents();
}

BonusMain.prototype.clearContainer = function() {
    "use strict";
    var self = this;

    if (this.animTimer != null) {
        clearInterval(this.animTimer);
    }

    if (this.showBonusPopupTimer != null) {
        clearInterval(this.showBonusPopupTimer);
    }

    if (this.moveClickedAnimUpdateTimer != null) {
        clearInterval(this.moveClickedAnimUpdateTimer);
    }

    if (this.drawFruitsTimer != null) {
        clearInterval(this.drawFruitsTimer);
    }

    if (this.recheckFruitsDrawTimer != null) {
        clearInterval(this.recheckFruitsDrawTimer);
    }
}

/*
 * This function check the hits of dynamite and draw text of win amount.
 */

BonusMain.prototype.checkObjectHit = function(posX, posY) {
    if (this.winValueTimer != undefined) {
        clearTimeout(this.winValueTimer);
        this.ctx.clearRect(1225, 280, 694, 801);
        this.ctx.drawImage(this.blenderImage, 1209, 415, 547, 666);
    }
    if(self.dataModelObj.isSoundPlay === true ){
        self.dataModelObj.GAME_BG_SOUND.stop();
       self.dataModelObj.clickToPlayGame.stop().play();
    }
    for (var i = 0; i < this.imageArray.length; i++) {
        if (posX >= (this.imageArray[i].x)
                && posX <= (this.imageArray[i].x + this.bonusDataModel.animWidth)
                && posY >= (this.imageArray[i].y)
                && posY <= (this.imageArray[i].y + this.bonusDataModel.animHeight)
                && this.imageArray[i] !== undefined
                && this.imageArray[i].isClicked === false) {
            if (this.checkAttempt < this.chanceAllowed) {
                this.chancesRemainingToPlayed--;
                this.ctx.drawImage(this.blenderImage, 1209, 415, 547, 666);
                this.checkAttempt++;
                this.imageArray[i].isClicked = true;
                this.buttonInitObj.unBindEvents();
                this.moveClickedImage(this.imageArray[i]);
                this.remainingChances++;

                break;
            } else {
                this.buttonInitObj.unBindEvents();
                this.checkAttempt = 0;
            }
        }
    }
}

BonusMain.prototype.moveClickedImage = function(clickedImgObj) {
    var self = this;
    if (clickedImgObj != undefined) {
        var xPath = clickedImgObj.movePath;
        var prex = 0;
        var prey = 0;

        if (xPath != undefined) {
            var i = 0;
            this.moveClickedAnimUpdateTimer = setInterval(function() {
                var path = xPath[i];
            	
                if(this.dataModelObj.isSoundPlay === true ){
                    self.dataModelObj.GAME_BG_SOUND.stop();
                   self.dataModelObj.FruitMove.stop().play();
                }

                if (path != undefined) {
                    if (prex === 0 && prey === 0) {
                        self.ctx.clearRect(path.x, path.y, clickedImgObj.sw,clickedImgObj.sh);
                    } else {
                        self.ctx.clearRect(prex, prey, clickedImgObj.sw,clickedImgObj.sh);
                        for (var j = 0; j < self.imageArray.length; j++) {
                            var imgObj = self.imageArray[j];
                            if (imgObj.id !== clickedImgObj.id && imgObj.isClicked === false) {
                                self.ctx.clearRect(imgObj.x, imgObj.y,imgObj.sw, imgObj.sh);
                                self.ctx.drawImage(imgObj.img, imgObj.x,imgObj.y, imgObj.sw, imgObj.sh);
                            }
                        }
                        self.ctx.drawImage(clickedImgObj.img, path.x, path.y,clickedImgObj.sw, clickedImgObj.sh);
                    }

                    prex = path.x;
                    prey = path.y;
                    i++;
                    if (i >= xPath.length) {
                        self.ctx.clearRect(prex, prey, clickedImgObj.sw,clickedImgObj.sh);
                        if(this.dataModelObj.isSoundPlay === true ){
                            self.dataModelObj.GAME_BG_SOUND.stop();
                           self.dataModelObj.fruitsexplosion.stop().play();
                        }
                        self.startBlunderAnimation(clickedImgObj);
                        clearInterval(self.moveClickedAnimUpdateTimer);
                    }
                } else {
                    self.ctx.clearRect(prex, prey, clickedImgObj.sw,clickedImgObj.sh);
                    if(this.dataModelObj.isSoundPlay === true ){
                        self.dataModelObj.GAME_BG_SOUND.stop();
                       self.dataModelObj.fruitsexplosion.stop().play();
                    }
                    self.startBlunderAnimation(clickedImgObj);
                    clearInterval(self.moveClickedAnimUpdateTimer);
                }

            }, 1000 / 5);
        }
    }
}

/*
 * This function start mine clock animation
 */
BonusMain.prototype.startBlunderAnimation = function(animObj) {
    var self = this;
    this.frameCount = 0;
    

    if (this.animTimer != null) {
        clearInterval(this.animTimer);
    }


    this.animTimer = setInterval(function() {
        self.animateBlunder(animObj);
    }, 2000 / 8);
}

BonusMain.prototype.animateBlunder = function(AnimObj) {
    var self = this;
    this.numFrames = 21;
    this.frameSize = 694;
    var tmpAnimObj = AnimObj.animateImg;
    this.ctx.clearRect(1225, 280, 694, 801);
    this.ctx.drawImage(tmpAnimObj, this.frameSize * this.frameCount, 0,
            this.frameSize, 801, 1225, 280, this.frameSize, 801);

    this.frameCount++;
    if (this.frameCount >= this.numFrames) {

        clearInterval(this.animTimer);

        self.showWinValue(this.symbolValue[this.remainingChances]);
        self.totalValue += parseInt(this.symbolValue[this.checkAttempt - 1]);
        
        if(this.dataModelObj.isSoundPlay === true ){
            self.dataModelObj.GAME_BG_SOUND.stop();
           self.dataModelObj.bonusPointsWin.stop().play();
        }
        $("#bonus-point").attr("value", this.totalValue);
        $("#chance-text").attr("value", parseInt(this.chancesRemainingToPlayed));

        this.updateBonusPlayed();
        this.buttonInitObj.bindEvents();
        clearInterval(this.blunderAnimTimer);
    }
}

/*
 * This function is for getting the mouse movement
 */

BonusMain.prototype.updateBonusPlayed = function() {
    var self = this;
    this.showBonusPopupDelayTime = 4000;
    if (this.showBonusPopupTimer != null) {
        clearInterval(this.showBonusPopupTimer);
    }

    var self = this;
    if (this.checkAttempt >= this.chanceAllowed) {
        if (this.imageArray.length > 0) {
            this.showLoseValues();
        }
        if (this.chanceAllowed == this.checkAttempt) {
            this.spinService.bonusRoundPlayed();
            var finalWinAmount = parseFloat(this.totalValue * this.coinValue)
                    .toFixed(2);
            if (this.showBonusPopupTimer != null) {
                clearInterval(this.showBonusPopupTimer);
            }

            this.showBonusPopupTimer = setInterval(function() {
                if (self.dataModelObj.hasErrorInBonusUpadte == false
                        && self.dataModelObj.bIsBonusUpdated == true) {
                    clearInterval(self.showBonusPopupTimer);
                    self.clearContainer();
                    self.spinService.showBonusAmountWinPopup($.i18n.prop(
                            "bonus.win.roundAmount", finalWinAmount));
                    if (self.dataModelObj.isSoundPlay === true) {
                        self.dataModelObj.GAME_BG_SOUND.stop();
                        self.dataModelObj.BonusWinPopUp.stop().play();
                        
                    }
                } else if (self.dataModelObj.hasErrorInBonusUpadte === true
                        && self.dataModelObj.bIsBonusUpdated === true) {
                    clearInterval(self.showBonusPopupTimer);
                    self.clearContainer();
                }
            }, this.showBonusPopupDelayTime);
        }
    }

}

BonusMain.prototype.mouseMoveHandler = function(ev) {
    var pos = this.findPos(ev.target);
    var x = ev.pageX - pos.x;
    var y = ev.pageY - pos.y;
    var ratioX = (this.canvasWidth / $('#bonusCanvas').width());
    var ratioY = (this.canvasHeight / $('#bonusCanvas').height());
    this.changeCursor(x * ratioX, y * ratioY);
}

BonusMain.prototype.changeCursor = function(posX, posY) {
    $('#bonusCanvas').css('cursor', 'default');
    for (var i = 0; i < this.imageArray.length; i++) {

        if (posX >= (this.imageArray[i].x + 40)
                && posX <= (this.imageArray[i].x
                        + this.bonusDataModel.animWidth - 45)
                && posY >= (this.imageArray[i].y + 40)
                && posY <= (this.imageArray[i].y
                        + this.bonusDataModel.animHeight - 50)
                && this.imageArray[i] !== undefined) {
            $('#bonusCanvas').css('cursor', 'pointer');
        }
    }
}

BonusMain.prototype.canvasClickHandler = function(ev) {
    var pos = this.findPos(ev.target);
    var x = ev.pageX - pos.x;
    var y = ev.pageY - pos.y;
    var ratioX = (1920 / $('#bonusCanvas').width());
    var ratioY = (1080 / $('#bonusCanvas').height());
    this.checkObjectHit(x * ratioX, y * ratioY);
}

/*
 * Logic to find the position of cursor
 */
BonusMain.prototype.findPos = function(obj) {
    var curleft = 0, curtop = 0;
    if (obj.offsetParent) {
        do {
            curleft += obj.offsetLeft;
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);
        return {
            x : curleft,
            y : curtop
        };
    }
    return undefined;
}

function BonusDataModel() {
    this.imageSrc = "assests/juicyFruits/Bonus/";
    this.animHeight = 231;
    this.animWidth = 254;
    //this.pyramidHight =100;
    this.sndArr = [ "BonusBackGround" ];

}

function BonusButtonInit(bonusMainObj) {
    this.canvasElem = $("#bonusCanvas");
    this.bonusMainObj = bonusMainObj;
}

BonusButtonInit.prototype.bindEvents = function() {
    this.canvasElem.bind('mousemove', $.proxy(
            this.bonusMainObj.mouseMoveHandler, this.bonusMainObj));
    this.canvasElem.bind('click', $.proxy(this.bonusMainObj.canvasClickHandler,
            this.bonusMainObj));
}

BonusButtonInit.prototype.unBindEvents = function() {
    this.canvasElem.unbind('mousemove', $.proxy(
            this.bonusMainObj.mouseMoveHandler, this.bonusMainObj));
    this.canvasElem.unbind('click', $.proxy(
            this.bonusMainObj.canvasClickHandler, this.bonusMainObj));
}

BonusMain.prototype.showWinValue = function(value) {   
    var self = this;
    this.ctx.fillStyle = "#fc6112";
    this.ctx.font = "bold 3em Klavika";
    this.ctx.shadowOffsetX = 5;
    this.ctx.shadowOffsetY = 5;
    this.ctx.shadowBlur = 10;
    this.ctx.textAlign = 'center';
    this.ctx.strokeStyle = "#fbd5aa";
    this.ctx.lineWidth = 5;
    this.ctx.strokeText(value, 1480, 480);
    this.ctx.fillText(value, 1480, 480);
    this.winValueTimer = setTimeout(function() {
        self.ctx.clearRect(1225, 280, 694, 801);
        self.ctx.drawImage(self.blenderImage, 1209, 415, 547, 666);
    }, 3000);

}

BonusMain.prototype.showLoseValues = function() {
    var self = this;
    for (var valueCount = 0; valueCount < self.imageArray.length; valueCount++) {
        if (self.imageArray[valueCount].isClicked === false) {
            self.ctx.fillStyle = "#64db11";
            self.ctx.font = "bold 3em Klavika";
            self.ctx.textAlign = 'center';
            self.ctx.strokeStyle = "#fff";
            self.ctx.lineWidth = 5;
            self.ctx.strokeText(self.totalScores[valueCount],
                    self.imageArray[valueCount].x + 130,
                    self.imageArray[valueCount].y + 160);
            self.ctx.fillText(self.totalScores[valueCount],
                    self.imageArray[valueCount].x + 130,
                    self.imageArray[valueCount].y + 160);
        }
    }
}



BonusMain.prototype.bonusGameJuicyFruitsSounds = function() {
	
	   if (this.dataModelObj.FruitMove == null) {
	        this.dataModelObj.FruitMove = new Howl({
	            urls : [ this.dataModelObj.soundSrc + 'Blender.mp3',
	                    this.dataModelObj.soundSrc + 'Blender.wav' ]
	        });
	    }
    
    if (this.dataModelObj.fruitsexplosion == null) {
        this.dataModelObj.fruitsexplosion = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'ExplodingFruit.mp3',
                    this.dataModelObj.soundSrc + 'ExplodingFruit.wav' ]
        });
    }

    if (this.dataModelObj.clickToPlayGame == null) {
        this.dataModelObj.clickToPlayGame = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusfruitClick.mp3',
                    this.dataModelObj.soundSrc + 'BonusfruitClick.wav' ]
        });
    }

    if (this.dataModelObj.bonusPointsWin == null) {
        this.dataModelObj.bonusPointsWin = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusPointWinsound.mp3',
                    this.dataModelObj.soundSrc + 'BonusPointWinsound.wav' ]
        });
    }

    if (this.dataModelObj.BonusWinPopUp == null) {
        this.dataModelObj.BonusWinPopUp = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusCongratulationPopup.mp3',
                    this.dataModelObj.soundSrc + 'BonusCongratulationPopup.wav' ]
        });
    }
};








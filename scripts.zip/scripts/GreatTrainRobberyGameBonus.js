function BonusMain(spinServiceObj, totalArrayValues, symbolValues,
        chanceAllowed, coinValue, dataModelObj, stringSplitObj) {
    var self = this;

    this.chanceAllowed = chanceAllowed;
    this.dataModelObj = dataModelObj;
    this.stringSplit = stringSplitObj;
    this.spinService = spinServiceObj;

    if (this.dataModelObj.bonusGameVisible === false) {
        this.dataModelObj.bonusGameVisible = true;
        
        this.symbolValue = symbolValues;
        this.coinValue = coinValue;
        if (chanceAllowed > 1) {
            this.valueArr = this.symbolValue;
        } else {
            this.valueArr = new Array(this.symbolValue);
        }


        $('.bonus-canvas-back').show();

        if ($('.bonus-canvas-container')) {
            $('.bonus-canvas-container').show();
            $('.coming-train').show();

            $(".transGamebg").show();
            
        }

        this.wonValues = "";
        this.bonusIndex = 0;
        this.spriteComingTrain = new Image();
        this.spriteBackground = new Image();
        this.cowboyImage = new Image();
        this.cowboyAnimationImage = new Image();
        this.clickImage = new Image();
        this.lockerAnimationImage = new Image();

        this.spriteComingTrain.src = "assests/greatTrainRobbery/Bonus/coming-train.gif";
        this.spriteBackground.src = "assests/greatTrainRobbery/Bonus/bonus-screen-image.jpg";
        this.cowboyAnimationImage.src = "assests/greatTrainRobbery/Bonus/cowboy-animation.png";
        this.cowboyImage.src = "assests/greatTrainRobbery/Bonus/cowboy-stop.png";
        this.lockerAnimationImage.src = "assests/greatTrainRobbery/Bonus/locker-animation.png";
        this.isAssestLoaded = false;
        this.iscowboyAnimate = false;
        
        this.frameCountBg = 0;
        this.frameCountcowboyAnimation = 0;
        this.frameCountLockerAnimation = 0;
        
        if (this.GameInterval != null) {
            clearInterval(this.GameInterval);
        }
        
        this.clearContainer();
        
        this.autocanvas = $("#myCanvas");
        this.ctx = $("#myCanvas")[0].getContext('2d');

        this.ctx.save();
        //Use the identity matrix while clearing the canvas
        this.ctx.setTransform(1, 0, 0, 1, 0, 0);
        this.ctx.clearRect(0, 0, this.autocanvas.width, this.autocanvas.height);
        // Restore the transform
        this.ctx.restore();
        
        this.totalValue = 0;
        $("#bonus-coin-val").attr("value", "$" + this.coinValue);
        $("#chance-text").attr("value", this.chanceAllowed);
        $("#bonus-point").attr("value", this.totalValue);

        this.clickToplay = $("#clickToPlay");
        this.valueContainer = $(".input-field");
        this.GameInterval = null;
        this.showBonusPopupTimer = null;
        this.textFade = null;
        
        if(this.dataModelObj.GAME_BG_SOUND != null ){
            this.dataModelObj.GAME_BG_SOUND.stop();
        }
       
        this.isBonusInit = false;
        
        if(this.dataModelObj.trainMoving == null && this.dataModelObj.isSoundPlay === true) {
            this.dataModelObj.trainMoving = new Howl({
                urls : [ this.dataModelObj.soundSrc + 'Train.mp3',this.dataModelObj.soundSrc + 'Train.wav'],
                autoplay:true,
                buffer: false,
                loop:true,
                preload :true,
                onplay : function(){
                    if(self.isBonusInit === false){
                        self.init();
                        self.addClickEvent();
                        self.isBonusInit = true;
                    }
                },
                onloaderror : function(){
                    if(self.isBonusInit === false){
                        self.init();
                        self.addClickEvent();
                        self.isBonusInit = true;
                    }
                },
                onplayerror : function(){
                    if(self.isBonusInit === false){
                        self.init();
                        self.addClickEvent();
                        self.isBonusInit = true;
                    }
                }
            });
        } else {
            if(this.dataModelObj.isSoundPlay === true ){
                this.dataModelObj.GAME_BG_SOUND.stop();
                this.dataModelObj.trainMoving.stop().play();
            }
            this.init();
            this.addClickEvent();
        }
        
        this.bonusGameSounds();
    }
}



BonusMain.prototype.init = function() {
    var self = this;
    if (this.GameInterval != null) {
        clearInterval(this.GameInterval);
    }
    this.GameInterval = setInterval(function() {
        self.Background();
        if (self.iscowboyAnimate === true) {
            self.cowboyAnimation();
        } else if (self.islockerAnimate === true) {
            self.lockerAnimation();
        } else {
            self.cowBoyStop();
            $("#win-value").css("display", "none");
        }
    }, 300);

}

BonusMain.prototype.clearContainer = function() {
    var self = this;
    if (this.GameInterval != null) {
        clearInterval(this.GameInterval);
    }
    
    if (this.textFade != null) {
        clearInterval(this.textFade);
    }
    
    if(this.dataModelObj.trainMoving != null){
        this.dataModelObj.trainMoving.stop();
    }
}

BonusMain.prototype.Background = function() {
    var numFrames = 15;
    var frameSize = 1920;
    
    if (this.frameCountBg < numFrames) {
        this.ctx.clearRect(0, 0, frameSize, 1080);
        this.ctx.drawImage(this.spriteBackground,
                frameSize * this.frameCountBg, 0, frameSize, 1080, 0, 0,
                frameSize, 1080);
        this.frameCountBg++;
        if (this.frameCountBg == 2 && this.isAssestLoaded === false) {
            this.clickToplay.css("display", "block");
            this.valueContainer.css("display", "block");
            this.isAssestLoaded = true;
        }

        if (this.frameCountBg == numFrames) {
            this.frameCountBg = 0;
            $('.coming-train').hide();
        }
    }
   
}

BonusMain.prototype.cowBoyStop = function() {
    this.ctx.drawImage(this.cowboyImage, 0, 0, 1111, 1080);
}

BonusMain.prototype.cowboyAnimation = function() {

    var numFrames = 7;
    var frameSize = 1111;
    if (this.frameCountcowboyAnimation < numFrames) {
        this.ctx.clearRect(0, 0, 0, 904);
        this.ctx.drawImage(this.cowboyAnimationImage, frameSize
                * this.frameCountcowboyAnimation, 0, frameSize, 904, 0, 176,
                frameSize, 904);
        this.frameCountcowboyAnimation++;
        if(this.dataModelObj.isSoundPlay === true && this.frameCountcowboyAnimation == 4 ){
            this.dataModelObj.GAME_BG_SOUND.stop();
            this.dataModelObj.gunShot.stop().play();
        }
        
        if (this.frameCountcowboyAnimation == numFrames) {
            this.frameCountcowboyAnimation = 0;
            this.iscowboyAnimate = false;
            this.islockerAnimate = true;
        }
    }
}

BonusMain.prototype.lockerAnimation = function() {
    var numFrames = 12;
    var frameSize = 1270;

    if (this.frameCountLockerAnimation < numFrames) {
        this.ctx.clearRect(0, 0, 0, 904);
        this.ctx.drawImage(this.lockerAnimationImage, frameSize
                * this.frameCountLockerAnimation, 0, frameSize, 904, 0, 176,
                frameSize, 904);
        this.frameCountLockerAnimation++;
        
        if(this.dataModelObj.isSoundPlay === true && this.frameCountLockerAnimation == 2 ){
            this.dataModelObj.GAME_BG_SOUND.stop();
            this.dataModelObj.coinJackpot.stop().play();
        }
        
        if(this.dataModelObj.isSoundPlay === true && this.frameCountLockerAnimation == 12){
            this.dataModelObj.GAME_BG_SOUND.stop();
            this.dataModelObj.trainMoving.stop().play();
        }
        
        if (this.frameCountLockerAnimation == 10) {
            if(this.dataModelObj.isSoundPlay === true ){
                this.dataModelObj.coinJackpot.stop();
                this.dataModelObj.GAME_BG_SOUND.stop();
                this.dataModelObj.bonusPointsWin.stop().play();
            }
            this.chanceAllowed--;
            if (parseInt((this.chanceAllowed)) > 1) {
                $("#chance-text").attr("value", this.chanceAllowed);
            } else {
                $("#chance-text").attr("value", this.chanceAllowed);
            }

            this.currentValue = this.valueArr[this.bonusIndex];

            if (this.bonusIndex < (this.valueArr.length - 1)) {
                ++this.bonusIndex;
            }
            
            this.totalValue += parseInt(this.currentValue);
            this.wonValues = this.wonValues.concat(this.currentValue + ",");
            $("#win-value").css("display", "block");
            $("#win-value").empty().append("" + this.currentValue + "");
            $("#bonus-point").attr("value", this.totalValue);

            if (this.chanceAllowed == 0) {
                this.soundArr = [];
                this.spinService.bonusRoundPlayed();
            }
        }

        if (this.frameCountLockerAnimation == 12) {
            if (this.chanceAllowed > 0) {
                this.addClickEvent();
            } else {
                this.showWinAmountPopup();
            }
        }

        if (this.frameCountLockerAnimation == numFrames) {
            this.frameCountLockerAnimation = 0;
            this.islockerAnimate = false;
        }
    }
}

BonusMain.prototype.showWinAmountPopup = function() {
    var self = this;
    this.showBonusPopupDelayTime = 1000;
    if (this.chanceAllowed == 0) {
        this.removeClickEvent();
        var finalWinAmount = parseFloat(this.totalValue * this.coinValue)
                .toFixed(2);
        if (this.showBonusPopupTimer != null) {
            clearInterval(this.showBonusPopupTimer);
        }
        
        this.showBonusPopupTimer = setInterval(function() {
            if (self.dataModelObj.hasErrorInBonusUpadte === false) {
                if (self.dataModelObj.bIsBonusUpdated === true) {
                    clearInterval(self.showBonusPopupTimer);
                    self.clearContainer();
                    self.spinService.showBonusAmountWinPopup($.i18n.prop(
                            "bonus.win.roundAmount", finalWinAmount));
                    if(self.dataModelObj.isSoundPlay === true ){
                        self.dataModelObj.GAME_BG_SOUND.stop();
                        self.dataModelObj.trainMoving.stop();
                        self.dataModelObj.BonusWinPopUp.stop().play();
                    }
                }
            } else if (self.dataModelObj.hasErrorInBonusUpadte === true
                    && self.dataModelObj.bIsBonusUpdated === true) {
                clearInterval(self.showBonusPopupTimer);
                self.clearContainer();
            }
        }, this.showBonusPopupDelayTime);
    }
}

BonusMain.prototype.addClickEvent = function() {
    this.clickToplay.attr("disabled", false);
    this.clickToplay.bind("click", $.proxy(this.mouseClickHandler, this));
};
// for remove click events from button
BonusMain.prototype.removeClickEvent = function() {
    this.clickToplay.attr("disabled", true);
    this.clickToplay.unbind("click", $.proxy(this.mouseClickHandler, this));
};

BonusMain.prototype.mouseClickHandler = function(ev) {
    if (this.chanceAllowed > 0) {
        this.iscowboyAnimate = true;
        if(this.dataModelObj.isSoundPlay === true ){
            this.dataModelObj.trainMoving.stop();
            this.dataModelObj.clickToPlay.stop().play();
        }
        this.removeClickEvent();
    }
}

/*    
 * play sound for bonus game when shoot of bullet.
 * sonali 
 */

BonusMain.prototype.bonusGameSounds = function() {
    
    if(this.dataModelObj.gunShot == null){
        this.dataModelObj.gunShot = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'Gunshot.mp3',
                    this.dataModelObj.soundSrc + 'Gunshot.wav' ]
        });
    }
    
    if(this.dataModelObj.clickToPlay == null){
        this.dataModelObj.clickToPlay = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'ButtonClick.mp3',
                    this.dataModelObj.soundSrc + 'ButtonClick.wav' ]
        });
    }

    if(this.dataModelObj.bonusPointsWin == null){
        this.dataModelObj.bonusPointsWin = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusPointWinsound.mp3',
                    this.dataModelObj.soundSrc + 'BonusPointWinsound.wav' ]
        });
    }

    if(this.dataModelObj.coinJackpot == null){
        this.dataModelObj.coinJackpot = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'CoinFlipping.mp3',
                     this.dataModelObj.soundSrc + 'CoinFlipping.wav' ]
        });
    }

    if(this.dataModelObj.BonusWinPopUp == null){
        this.dataModelObj.BonusWinPopUp = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusCongratulationPopup.mp3',
                this.dataModelObj.soundSrc + 'BonusCongratulationPopup.wav' ]
        });
    }
};

/*global Animation, Image, console, setInterval, clearInterval*/
/*This js use for symbol animation  when user win*/
function Animation(img, x, y, width, height, dataModelObj) {
    "use strict";
    this.img = img
    this.name = "*";
    this.x = x ;
    this.y = y ;
    this.width = width;
    this.height = height;
    this.req = -1;
    this.frameCount = -1;
    this.spinDataModelObj = dataModelObj;
}

Animation.prototype.startAnimation = function (context, animationArrayLength) {
    "use strict";
    var self;
    this.ctx = context ;
    self = this;
    this.req = setInterval(function () { self.drawAnimation(animationArrayLength) }, 1000/6 );
};

Animation.prototype.drawAnimation = function (animationArrayLength) {
    "use strict";
    this.ctx.clearRect(this.x,this.y, this.width, this.height);
    this.frameCount += 1;
    if (this.frameCount === 14) {
        this.frameCount = 0;
        
        if(animationArrayLength==1){
        	this.spinDataModelObj.blshowBonusGame = true;
        	this.spinDataModelObj.bIsWinLineShowStoped = true;
        }
    }
    this.ctx.drawImage(this.img, this.width * this.frameCount, 0, this.width, this.height, this.x, this.y, this.width, this.height);    
};

Animation.prototype.clearAllInterval = function () {
    "use strict";
    this.frameCount = -1;
    clearInterval(this.req);
};
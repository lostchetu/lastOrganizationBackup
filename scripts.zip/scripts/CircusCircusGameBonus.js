function BonusMain(spinServiceObj, totalArrayValues, symbolValues,
        chanceAllowed, coinValue, dataModelObj, stringSplitObj) {
    "use strict";
    var self = this;
    this.dataModelObj = dataModelObj;
    this.stringSplit = stringSplitObj;
    this.spinService = spinServiceObj;

    if (this.dataModelObj.bonusGameVisible === false) {
        this.dataModelObj.bonusGameVisible = true;
        this.chanceAllowed = chanceAllowed;
        this.symbolValue = symbolValues;
        this.coinValue = coinValue;
        if (chanceAllowed > 1) {
            this.valueArr = this.symbolValue;
        } else {
            this.valueArr = new Array(this.symbolValue);
        }

        //$('.bonus-canvas-back').show();
        if ($('.bonus-canvas-container')) {
            $('.bonus-canvas-container').show();
            $(".transGamebg").show();
        }

        this.wonValues = "";
        this.bonusIndex = 0;
        this.totalValue = 0;
        this.roundValue = 0;

        $("#bonus-coin-val").attr("value", "$" + this.coinValue);
        $("#chance-text").attr("value", this.chanceAllowed);
        $("#bonus-game_lightbox").hide();
        $("#bonus-point").attr("value", this.totalValue);
        
        $("#roundValue1, #roundValue2, #roundValue3").hide();
        $("#bsRoundSpin1,#bsRoundSpin2, #bsRoundSpin3").hide();
        for(var i=1; i<=this.chanceAllowed;i++){
            $("#roundValue"+i).show();
            $("#roundValue"+i).attr("value",this.roundValue);
            $("#bsRoundSpin"+i).show();
        }
        
        this.winValue = $("#win-value");
        this.winValue.empty();
        this.bonusSprite = $('#bonusSprite1');
        this.showBonusPopupTimer = null;
        
        this.clickToplay = $('.play-button');
        this.clickToplay.fadeIn();
        this.animatedWheelSpinBtn = $('#bonusWheelSpinBtn');
        

        this.animatedClown = $('.clown-img');
        this.directionImg = $('.direction-img');

        this.clearContainer();
        
        if(this.dataModelObj.GAME_BG_SOUND != null ){
            this.dataModelObj.GAME_BG_SOUND.stop();
        }
        
        this.init();
        this.addWheelClickEvent();
        this.bonusGameAztecSounds();
    }
}

BonusMain.prototype.rotateWheel = function() {
    "use strict";
    var self = this;

    if(this.chanceAllowed > 0) {
        this.removeWheelClickEvent();
        this.winValue.empty().css("display", "none");
        this.bonusSprite.attr('class', '');
        this.bonusSprite.addClass('spriteBonus animated-animation-icon');
        
         
        if(this.dataModelObj.isSoundPlay === true ){
            this.dataModelObj.clickToPlayGame.stop().play();
        }
        
        var winamount = this.valueArr[this.bonusIndex];
        this.currentValue = this.valueArr[this.bonusIndex];

        this.totalValue += parseInt(this.currentValue);
        this.wonValues.concat(this.currentValue + ",");

        ++this.bonusIndex;
        this.chanceAllowed--;

        if (parseInt((this.chanceAllowed)) > 1) {
            $("#chance-text").attr("value", this.chanceAllowed);
        } else {
            $("#chance-text").attr("value", this.chanceAllowed);
        }

        this.animation;
        switch (parseInt(winamount)) {
        case 150:
            this.animation = 1;
            break;
        case 20:
            this.animation = 2;
            break;
        case 200:
            this.animation = 3;
            break;
        case 10:
            this.animation = 4;
            break;
        case 100:
            this.animation = 5;
            break;
        case 75:
            this.animation = 6;
            break;
        case 150:
            this.animation = 7;
            break;
        case 50:
            this.animation = 8;
            break;
        case 200:
            this.animation = 9;
            break;
        case 40:
            this.animation = 10;
            break;
        case 100:
            this.animation = 11;
            break;
        case 25:
            this.animation = 12;
            break;
        }
        
        if(this.bonusSprite.hasClass('animated-animation-icon' + self.animation)){
            //this.bonusSprite.removeClass('animated-animation-icon' + self.animation);
        }
        
        setTimeout(function() {
             if(self.dataModelObj.isSoundPlay === true ){
                 self.dataModelObj.GAME_BG_SOUND.stop();
                self.dataModelObj.spinLoop.stop().play();
             }
             
            self.bonusSprite.addClass('animated-animation-icon' + self.animation);
  
        }, 10);

        setTimeout(
            function() {
            		
                self.animatedClown.addClass('animated-clown2');
                self.directionImg.addClass('animated-direction-img');
                self.directionImg.removeClass('direction-img');
                self.winValue.empty().append("" + self.currentValue + "");
                $("#bonus-point").attr("value", self.totalValue);
                $("#roundValue" + self.bonusIndex).attr("value",self.currentValue);
                self.winValue.css("display", "block");

                
                if(self.dataModelObj.isSoundPlay === true ){
                    self.dataModelObj.GAME_BG_SOUND.stop();
                    self.dataModelObj.bonusPointsWin.stop().play();
                    self.dataModelObj.clownWinWow.stop().play();
                }
                
                if (self.chanceAllowed == 0) {
                    self.soundArr = [];
                    self.spinService.bonusRoundPlayed();
                    self.showWinAmountPopup();
                } else {
                    setTimeout(function() {
                        if(self.dataModelObj.isSoundPlay === true ){
                            self.dataModelObj.GAME_BG_SOUND.stop();
                          }
                        
                        self.addWheelClickEvent();
                   },4000);
                }
            }, 12000);
    }
}

BonusMain.prototype.init = function() {
    "use strict";
    //$('#bonusSprite1').removeClass('animated-animation-icon' + self.animation);
    $("#bonus-game_lightbox").show();
    $(".transGamebg").show();
}


BonusMain.prototype.showWinAmountPopup = function() {
    "use strict";
    var self = this;
    this.showBonusPopupDelayTime = 4000;
    if (this.chanceAllowed == 0) {
        var finalWinAmount = parseFloat(this.totalValue * this.coinValue)
                .toFixed(2);
        if (this.showBonusPopupTimer != null) {
            clearInterval(this.showBonusPopupTimer);
        }
        this.showBonusPopupTimer = setInterval(function() {
            if (self.dataModelObj.hasErrorInBonusUpadte === false) {
                if (self.dataModelObj.bIsBonusUpdated === true) {
                    clearInterval(self.showBonusPopupTimer);
                    self.clearContainer();
                    self.spinService.showBonusAmountWinPopup($.i18n.prop(
                            "bonus.win.roundAmount", finalWinAmount));
                    if(self.dataModelObj.isSoundPlay === true ){
                        self.dataModelObj.BonusWinPopUp.stop().play();
                    }
                    
                    $('#bonus-canvas-container').attr('class', '');
                    $('#bonus-canvas-container').addClass('bonus-canvas-container');
                }
            } else if (self.dataModelObj.hasErrorInBonusUpadte === true
                    && self.dataModelObj.bIsBonusUpdated === true) {
                clearInterval(self.showBonusPopupTimer);
                self.clearContainer();
            }
        }, this.showBonusPopupDelayTime);
    }
}

BonusMain.prototype.clearContainer = function() {
    var self = this;
    
    if(this.showBonusPopupTimer != null){
        clearInterval(this.showBonusPopupTimer);
    }
    
    this.removeWheelClickEvent();
    
    
    this.bonusSprite.removeClass('animated-animation-icon' + self.animation);
    this.animatedClown.removeClass('animated-clown');
    this.animatedClown.removeClass('animated-clown2');
    this.animatedClown.addClass('clown-img');
    this.directionImg.removeClass('animated-direction-img');
    this.directionImg.addClass('direction-img');
}

BonusMain.prototype.addWheelClickEvent = function() {
    "use strict";
    this.animatedWheelSpinBtn.bind("click", $.proxy(this.rotateWheel, this));
    this.animatedWheelSpinBtn.attr('class', '');
    this.animatedWheelSpinBtn.addClass('animated-click-btn');

    this.animatedClown.bind("click", $.proxy(this.rotateWheel, this));
    this.animatedClown.attr('class', '');
    this.animatedClown.addClass('clown-img');

    this.directionImg.bind("click", $.proxy(this.rotateWheel, this));
    this.directionImg.attr('class', '');
    this.directionImg.addClass('direction-img');
};

//for remove click events from button
BonusMain.prototype.removeWheelClickEvent = function() {
    "use strict";
    this.animatedWheelSpinBtn.attr('class', '');
    this.animatedWheelSpinBtn.addClass('animated-click-btn-disable');
    this.animatedWheelSpinBtn.unbind("click", $.proxy(this.rotateWheel, this));

    this.directionImg.attr('class', '');
    this.directionImg.addClass('direction-img');
    this.directionImg.unbind("click", $.proxy(this.rotateWheel, this));   

    this.animatedClown.attr('class', '');
    this.animatedClown.addClass('animated-clown');
    this.animatedClown.unbind("click", $.proxy(this.rotateWheel, this));   
};

BonusMain.prototype.bonusGameAztecSounds = function() {
    
    if (this.dataModelObj.spinLoop == null) {
        this.dataModelObj.spinLoop = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'clown_wheel_animation.mp3',
                    this.dataModelObj.soundSrc + 'clown_wheel_animation.wav' ]
        });
    }

    
    if (this.dataModelObj.clownWinWow == null) {
        this.dataModelObj.clownWinWow = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'clown_win_wow.mp3',
                    this.dataModelObj.soundSrc + 'clown_win_wow.wav' ]
        });
    }
    
    
    if (this.dataModelObj.clickToPlayGame == null) {
        this.dataModelObj.clickToPlayGame = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'ButtonClick.mp3',
                    this.dataModelObj.soundSrc + 'ButtonClick.wav' ]
        });
    }

    if (this.dataModelObj.bonusPointsWin == null) {
        this.dataModelObj.bonusPointsWin = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusPointWinsound.mp3',
                    this.dataModelObj.soundSrc + 'BonusPointWinsound.wav' ]
        });
    }

    if (this.dataModelObj.BonusWinPopUp == null) {
        this.dataModelObj.BonusWinPopUp = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusCongratulationPopup.mp3',
                    this.dataModelObj.soundSrc + 'BonusCongratulationPopup.wav' ]
        });
    }
};


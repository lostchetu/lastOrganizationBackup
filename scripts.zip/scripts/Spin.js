//global Spin
function Spin(context, DataModelObj, stringSplitObj, errorMessage) {
    this.reelCtx = context;//getting canvas context from Preloader class
    this.spinDataModelObj = DataModelObj;//setting refernce for datamodel class
    this.reelHolderArr = [];
    //start Added by firdous
    this.currJumpingReelArray = [];
    //End added by firdous
    this.imageHolderArr = [];
    this.animHolderArr = [];
    this.stringSplitObj = stringSplitObj;
    this.errorMessageObj = errorMessage;
    this.animArray = [];
    this.paylineObj = new Payline(this.spinDataModelObj);//create payline object
    this.btnEventObj = new ButtonEventHandler(this, this.spinDataModelObj,
            this.stringSplitObj);
    this.btnEventObj.assignBtnEvents();

    this.spinServiceObj = new SpinService(this, this.btnEventObj,
            this.spinDataModelObj, this.stringSplitObj, this.errorMessageObj);
    this.spinServiceObj.initialSpinService();

    this.gameInfoObj = new GameInfo(this.spinDataModelObj);
    this.coinValCount = 0;
    this.blWinSoundON = true;
    this.Canvas1 = $("#spincanvas");
    this.Canvas2 = $("#spincanvas1");
    this.Canvas3 = $("#spincanvas2");
    this.Canvas4 = $("#spincanvas3");
    this.Canvas5 = $("#spincanvas4");
    this.bonusGameObj = null;
    this.inErrorStopReel = null;
    this.exclusionOrImposeTimer = null;
    this.waitingTimer = null;
    this.autoSpinRadioValue = 0;
}

Spin.prototype.initializeInterface = function() {
    this.reelCounter = 0;
    this.reelStopCounter = 0;
    this.reelSymbolCount = -1;
    this.symbolCount = -1;
    this.stopped = false;
    this.stopClick = false;
    this.drawTextFields();
    this.loadContent();
    this.animArray = [];
    this.animRunning = false;
    var numPayLines = document.getElementById('payline-val-txt').value;
    this.paylineTxtFld = $("#payline-val-txt");
    this.paylineTxtFld.attr('value', numPayLines);
    this.paylineValCount = numPayLines;
    this.coinValFld = $("#coin-val-txt");
    this.coinValFld.attr("value", this.spinDataModelObj.coinvalArray[0]+ "\242");
    this.lineBetTxt = $('#linebet-text');
    this.lineBetTxt.attr('value',"$"+ (this.paylineValCount * (this.spinDataModelObj.coinvalArray[0]) / 100).toFixed(2));
    this.paylineShowCount = 0;
    this.changePayTimer = 0;
    this.paylineObj.showOnePaylineOnStart(numPayLines);
}

Spin.prototype.loadContent = function() {

    var columnNo, imageCount, imageX, imageY, randomImage, imageObj, imgContainer;
    for (columnNo = 0; columnNo < this.spinDataModelObj.columnCount; columnNo = columnNo + 1) {
        this.imageX = (columnNo * (this.spinDataModelObj.imageWidth + 10)) + 0;
        this.imageY = 0;
        origImagePos = 0;
        dummyStartPos = this.spinDataModelObj.imagePerColumn
                - this.spinDataModelObj.rowCount;
        this.imgContainer = [];
        for (imageCount = 0; imageCount < this.spinDataModelObj.imagePerColumn; imageCount = imageCount + 1) {
            this.reelSymbolCount += 1;
            if (imageCount > 2) {
                //set random images other than backend original symbols
                this.imageY = (-dummyStartPos * (this.spinDataModelObj.imageHeight + 10));
                randomImage = Math.floor(Math.random()
                        * ((this.spinDataModelObj.imageArray.length) - 1));
                var obj = new Object();
                obj.name = this.spinDataModelObj.imageArray[randomImage];
                obj.x = this.imageX;
                //start Added by firdous
                obj.originaly = this.imageY;
                //end Added by firdous
                obj.y = this.imageY;
                obj.id = this.reelSymbolCount;
                this.imgContainer.push(obj);
                dummyStartPos -= 1;
            } else {
                if (origImagePos == 0) {
                    this.imageY = 0;
                } else {
                    this.imageY = (origImagePos * (this.spinDataModelObj.imageHeight + 10));
                }

                if (imageCount >= 0
                        && imageCount < (this.spinDataModelObj.rowCount)) {
                    //set backend symbol images for first three position of every reel
                    this.symbolCount += 1; //for getting next image from image array
                    for (imgNameList = 0; imgNameList < this.spinDataModelObj.imageArray.length; imgNameList += 1) {
                        if (this.spinDataModelObj.imageArray[imgNameList] === this.spinDataModelObj.reelSymbols[this.symbolCount]) {
                            var obj = new Object();
                            obj.name = this.spinDataModelObj.imageArray[imgNameList];
                            obj.x = this.imageX;
                            obj.y = this.imageY;
                            obj.originaly = this.imageY;
                            obj.id = this.reelSymbolCount;
                            this.imgContainer.push(obj);

                        }
                    }

                }
                origImagePos += 1;
            }

        }

        this.reelHolderArr[columnNo] = this.imgContainer;
        this.currJumpingReelArray[columnNo] = this.imgContainer;
    }
    this.drawAllReelSymbol();

};

/**
 * This Method is called when Spin button event is generated.
 */
Spin.prototype.spinBtnHandler = function(betType) {
    var self = this;
    $('.auto-spin-control').removeClass('autospin-animate');
    $('.auto-spin-control input').removeAttr('checked');
    if ($(window).width() <= 767) {
        $("#show-menu").removeClass('move-up');
        $('.footer-bottom-new').removeClass('animate-f');
    }
    
    $("#spin").attr('value', "Spin");
    
    if(this.waitingTimer !== null){
        clearInterval(this.waitingTimer);
    }
    
    if (this.spinDataModelObj.isImposeLimitApplied === "true"
            || this.spinDataModelObj.isImposeLimitApplied === true
            || this.spinDataModelObj.isSystemLimitApplied === "true"
            || this.spinDataModelObj.isSystemLimitApplied === true) {
        
        this.spinDataModelObj.isExclusionOrImposePerformSpin = false;
        this.spinDataModelObj.isExclusionOrImposeStopSpin = false;

        this.spinDataModelObj.isAccountBlock = false;
        this.spinDataModelObj.hasBlockNote = false;

        this.spinDataModelObj.blockNote = null;
        this.spinDataModelObj.selfExcluseMsg = '';
        //End 

        this.btnEventObj.unAssignSpinBtnEvents();
        if (this.exclusionOrImposeTimer !== null) {
            clearInterval(this.exclusionOrImposeTimer);
        }
        

        this.performOneSpin = true;
        this.spinServiceObj
                .checkSelfExclusionOrImposeLimit(this.exclusionOrImposeTimer);
        this.exclusionOrImposeTimer = setInterval(
                function() {
                    if (self.spinDataModelObj.isExclusionOrImposePerformSpin === true
                            && self.performOneSpin === true) {
                        clearInterval(self.exclusionOrImposeTimer);
                        self.btnEventObj.assignBtnEvents();
                        self.spinPerform(betType);
                        self.performOneSpin = false;
                    } else if (self.spinDataModelObj.isExclusionOrImposePerformSpin === false
                            && self.spinDataModelObj.isExclusionOrImposeStopSpin === true) {
                        clearInterval(self.exclusionOrImposeTimer);
                        self.btnEventObj.assignBtnEvents();
                    }
                }, 50);

    } else {
        self.spinPerform(betType);
    }
};

Spin.prototype.spinPerform = function(betType) {
    var self = this;
    
    if (this.spinDataModelObj.isSoundPlay === true) {
        this.spinDataModelObj.ButtonClick.stop().play();
    }
    
    if (this.exclusionOrImposeTimer !== null) {
        clearInterval(this.exclusionOrImposeTimer);
    }
    
    if(this.waitingTimer !== null){
        clearInterval(this.waitingTimer);
    }
    
    if(this.updateAutoSpinContainerTimer !== null){
        clearInterval(this.updateAutoSpinContainerTimer);
    }
    this.spinDataModelObj.isPostUpdateAutoSpinContainer = false;
    
    $("#spin").attr('value', "Spin");
    $('#win-text').val("$0.00");
    this.spinDataModelObj.bIsAutoFreeSpin = false;
    this.spinDataModelObj.bIsReelStoped = false;
    this.spinDataModelObj.bonusWinAmount = 0.00;
    
    $("#betType").attr('value', "3"); // bet type 3 for spin button , 2 for bet one and 1 for bet max.
    if (betType !== "undefined" && (betType === 1 || betType === 2)) {
        $("#betType").attr('value', betType);
    }
    
    if (parseFloat(this.spinDataModelObj.creditPoint) < (parseFloat(this.paylineValCount
            * (this.spinDataModelObj.coinvalArray[this.coinValCount]) / 100))) {
        this.spinDataModelObj.isAutoSpin = false;
        this.spinServiceObj.removeAutoSpinInterval();
        this.btnEventObj.unAssignAutoSpinContainer();
        this.errorMessageObj.formatErrorMessage(70);
        this.spinDataModelObj.autoSpinCount=0;
        
    } else if (this.spinDataModelObj.selfExcluseMsg != undefined
            && this.spinDataModelObj.selfExcluseMsg !== null
            && this.spinDataModelObj.selfExcluseMsg !== ""
            && this.spinDataModelObj.selfExcluseMsg.length > 0) {
        this.spinDataModelObj.isAutoSpin = false;
        this.spinServiceObj.removeAutoSpinInterval();
        this.btnEventObj.unAssignAutoSpinContainer();
        this.errorMessageObj.formatErrorMessage(72);
    } else if ((this.spinDataModelObj.isSystemLimitApplied === true || this.spinDataModelObj.isImposeLimitApplied === true)
            && this.spinDataModelObj.bIsAutoFreeSpin === false
            && (this.spinDataModelObj.blockNote != undefined && (this.spinDataModelObj.blockNote != "" || this.spinDataModelObj.blockNote != null))) {
    } else {
        this.spinServiceObj.stopHeartBeat();
        var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
        if (isSafari) {
            reelTimer = 1000;
            this.spinDataModelObj.frameRate = 500;
            this.spinDataModelObj.speed = 80
        } else {
            reelTimer = 1500;
        }
        
        this.reelSpeed1 = this.spinDataModelObj.speed;
        this.reelSpeed2 = this.spinDataModelObj.speed;
        this.reelSpeed3 = this.spinDataModelObj.speed;
        this.reelSpeed4 = this.spinDataModelObj.speed;
        this.reelSpeed5 = this.spinDataModelObj.speed;
        
        if (this.spinDataModelObj.autoSpinCount >0 && betType==="autoSpin") {
            this.spinDataModelObj.autoSpinCount = this.spinDataModelObj.autoSpinCount - 1;
            this.spinDataModelObj.isPostUpdateAutoSpinContainer = true;
        }
        
        this.paylineObj.hideAllPaylines();
        this.btnEventObj.unAssignSpinBtnEvents();
        this.paylineShowCount = 0;
        this.postUpdation();
        
        this.spinDataModelObj.bIsWinLineShowStoped = false;
        
        
        self.spinDataModelObj.blshowBonusGame = false;
        self.spinDataModelObj.bHasError = false;
        self.stringSplitObj.spinResult();
        
        this.waitingTimer = setInterval(function() {
            self.startStopSpin();
            if (self.stringSplitObj.dataFound == true) {
                self.stringSplitObj.dataFound = false;
                self.stopClick = true;
                self.spinServiceObj.loadBonusGame();
            }
        }, reelTimer / self.spinDataModelObj.frameRate)

        if (this.spinDataModelObj.isSoundPlay === true) {
            this.spinDataModelObj.GAME_BG_SOUND.stop();
            this.spinDataModelObj.reelMoveSound.stop().play();
        }

        if (this.inErrorStopReel !== null) {
            clearInterval(this.inErrorStopReel);
        }
        this.inErrorStopReel = setInterval(function() {
            if (self.spinDataModelObj.bHasError === true) {
                self.spinDataModelObj.bHasError = false;
                clearInterval(self.inErrorStopReel);
            }
        }, 500);
    }
}

/**
 * This Method is called when Freespin button event is generated.
 */
Spin.prototype.freeSpinBtnHandler = function() {
    var self = this;
    $("#spin").attr('value', "Free Spin");
    $('#win-text').val("$0.00");
    this.spinDataModelObj.isPostUpdateAutoSpinContainer = false;
    this.spinDataModelObj.bonusWinAmount = 0.00;
    
    if (this.exclusionOrImposeTimer !== null) {
        clearInterval(this.exclusionOrImposeTimer);
    }
    
    
    if(this.waitingTimer !== null){
        clearInterval(this.waitingTimer);
    }
    
    if(this.updateAutoSpinContainerTimer !== null){
        clearInterval(this.updateAutoSpinContainerTimer);
    }
    
    if (this.spinDataModelObj.isAccountBlock === true
            && this.spinDataModelObj.selfExcluseMsg !== null
            && this.spinDataModelObj.selfExcluseMsg !== ""
            && this.spinDataModelObj.selfExcluseMsg.length > 0) {
        this.spinDataModelObj.isAutoSpin = false;
        this.spinServiceObj.removeAutoSpinInterval();
        this.btnEventObj.unAssignAutoSpinContainer();
        this.errorMessageObj.formatErrorMessage(72);
    } else {
        this.spinDataModelObj.bIsAutoFreeSpin = true;
        this.spinDataModelObj.bIsReelStoped = false;
        this.spinServiceObj.stopHeartBeat();
        this.reelSpeed1 = this.spinDataModelObj.speed;
        this.reelSpeed2 = this.spinDataModelObj.speed;
        this.reelSpeed3 = this.spinDataModelObj.speed;
        this.reelSpeed4 = this.spinDataModelObj.speed;
        this.reelSpeed5 = this.spinDataModelObj.speed;
        this.paylineObj.hideAllPaylines();
        this.btnEventObj.unAssignSpinBtnEvents();
        this.paylineShowCount = 0;
        this.postUpdation();
        self.spinDataModelObj.bHasError = false;
        self.spinDataModelObj.bIsWinLineShowStoped = false;
        self.stringSplitObj.spinResult();
        var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
        if (isSafari) {
            reelTimer = 1000;
            this.spinDataModelObj.frameRate = 500;
            this.spinDataModelObj.speed = 80
        } else {
            reelTimer = 1500;
        }
        
        if($.browser.mozilla){
            console.log("reelTimer-----== "+reelTimer+"  frameRate ==== "+this.spinDataModelObj.frameRate+" speed======  "+this.spinDataModelObj.speed);
        }
        
        this.waitingTimer = setInterval(function() {
            self.startStopSpin();
            if (self.stringSplitObj.dataFound == true) {
                self.stringSplitObj.dataFound = false;
                self.stopClick = true;
                self.spinServiceObj.loadBonusGame();
            }
        }, reelTimer / self.spinDataModelObj.frameRate);

        if (this.inErrorStopReel !== null) {
            clearInterval(this.inErrorStopReel);
        }
        this.inErrorStopReel = setInterval(function() {
            if (self.spinDataModelObj.bHasError === true) {
                self.spinDataModelObj.bHasError = false;
                clearInterval(self.inErrorStopReel);
            }
        }, 1000);
        
        if (this.spinDataModelObj.isSoundPlay === true) {
            this.spinDataModelObj.GAME_BG_SOUND.stop();
            this.spinDataModelObj.reelMoveSound.stop().play();
        }
    }
};

Spin.prototype.startStopSpin = function() {
    var self = this;
    var j, imgNameList, imageObj, reelCount, imgCount, reelImageCount;
    this.reelCtx.clearRect(0, 0, this.spinDataModelObj.canvasWidth,
            this.spinDataModelObj.canvasHeight);
    for (reelCount = 0; reelCount < this.spinDataModelObj.columnCount; reelCount += 1) {
        this.currentRow = reelCount;
        this.currReelArray = this.reelHolderArr[reelCount];
        for (reelImageCount = 0; reelImageCount < this.currReelArray.length; reelImageCount += 1) {
            this.moveReel(this.currReelArray[reelImageCount]);
        }
        for (imgCount = 0; imgCount < this.currReelArray.length; imgCount += 1) {
            if (this.currReelArray[imgCount].y > -this.spinDataModelObj.imageHeight
                    && this.currReelArray[imgCount].y < this.spinDataModelObj.canvasHeight + this.spinDataModelObj.imageHeight) {
                this.drawMovingImage(this.currReelArray[imgCount]);
            }
        }
    }
    // This section handle stopping of reels 
    if (this.stopClick == true) {

        this.colNo = 0;
        this.rowNo = 0;
        for (j = 0; j < this.spinDataModelObj.reelSymbols.length; j += 1) {
            if (j % this.spinDataModelObj.rowCount === 0 && j > 2) {
                this.colNo += 1;
            }

            this.rowNo = j % this.spinDataModelObj.rowCount;

            for (imgNameList = 0; imgNameList < this.imageHolderArr.length; imgNameList += 1) {
                if (this.imageHolderArr[imgNameList].name === this.spinDataModelObj.reelSymbols[j]) {
                    this.reelHolderArr[this.colNo][this.rowNo].name = this.imageHolderArr[imgNameList].name;
                    this.reelHolderArr[this.colNo][this.rowNo].img = this.imageHolderArr[imgNameList].img;
                    break;
                }
            }
        }
        this.stopClick = false;
        this.stopped = true;
    }
};
/* 
 *This method is to draw current reel image objects
 */
Spin.prototype.drawMovingImage = function(imageObj) {
    this.reelCtx.drawImage(imageObj.img, imageObj.x, imageObj.y);
};

/*
 * This method calls when reels image object move
 */

Spin.prototype.moveReel = function(reelImageObj) {

    // for stop reels
    var self = this;
    if (this.stopped == true) {
        if (reelImageObj.id === 0) {
            if (reelImageObj.y === 0) {
                this.reelSpeed1 = 0;
                self.Canvas1.removeClass('spinShow');
                self.Canvas1.addClass('spinHide');
            }
        }
        if (this.reelSpeed2 !== 0 && this.reelSpeed1 === 0
                && reelImageObj.id === this.spinDataModelObj.imagePerColumn) {
            if (reelImageObj.y === 0) {
                this.reelStopCounter += 1;
                if (this.reelStopCounter === 2) {
                    this.reelStopCounter = 0;
                    this.reelSpeed2 = 0;
                    self.Canvas2.removeClass('spinShow');
                    self.Canvas2.addClass('spinHide');
                }
            }
        }
        if (this.reelSpeed3 !== 0
                && this.reelSpeed2 === 0
                && reelImageObj.id === (2 * this.spinDataModelObj.imagePerColumn)) {
            if (reelImageObj.y === 0) {
                this.reelStopCounter += 1;
                if (this.reelStopCounter === 2) {
                    this.reelStopCounter = 0;
                    this.reelSpeed3 = 0;
                    self.Canvas3.removeClass('spinShow');
                    self.Canvas3.addClass('spinHide');
                }
            }
        }
        if (this.reelSpeed4 !== 0
                && this.reelSpeed3 === 0
                && reelImageObj.id === (3 * this.spinDataModelObj.imagePerColumn)) {

            if (reelImageObj.y === 0) {
                this.reelStopCounter += 1;
                if (this.reelStopCounter === 2) {
                    this.reelStopCounter = 0;
                    this.reelSpeed4 = 0;
                    self.Canvas4.removeClass('spinShow');
                    self.Canvas4.addClass('spinHide');
                }
            }
        }
        if (this.reelSpeed5 !== 0
                && this.reelSpeed4 === 0
                && reelImageObj.id === (4 * this.spinDataModelObj.imagePerColumn)) {
            if (reelImageObj.y === 0) {
                this.reelStopCounter += 1;
                if (this.reelStopCounter === 2) {
                    this.stopped = false;
                    this.reelStopCounter = 0;
                    this.reelSpeed5 = 0;
                    clearInterval(this.waitingTimer);
                    this.blWinSoundON = true;
                    this.updateGameScreen();
                    this.drawTextFields();
                    this.Canvas5.removeClass('spinShow');
                    this.Canvas5.addClass('spinHide');
                    
                    if($(window).width() < 767){
                        this.showHf();
                    }
                    
                    this.btnEventObj.assignBtnEvents();
                    
                    if(this.spinDataModelObj.bIsBonusWin === true){
                        this.btnEventObj.disableSpinBtn();
                    }

                    if(this.spinDataModelObj.isSoundPlay === true){
                        this.spinDataModelObj.reelMoveSound.stop();
                    }
                    this.spinDataModelObj.bIsReelStoped = true;
                    this.spinServiceObj.hasAvaliableFreeSpins();
                    this.spinServiceObj.startHeartBeat();
                }
            }
        }
    }

    //Logic for change position of symbols when they reach to canvas height+imagesize
    if (reelImageObj.y >= this.spinDataModelObj.canvasHeight) {
        var reelFactor;
        if (reelImageObj.id === (this.spinDataModelObj.imagePerColumn - 1)
                || reelImageObj.id === (2 * this.spinDataModelObj.imagePerColumn - 1)
                || reelImageObj.id === (3 * this.spinDataModelObj.imagePerColumn - 1)
                || reelImageObj.id === (4 * this.spinDataModelObj.imagePerColumn - 1)
                || reelImageObj.id === (5 * this.spinDataModelObj.imagePerColumn - 1)) {
            reelImageObj.y = this.currReelArray[0].y
                    - this.spinDataModelObj.imageHeight - 10;
        } else {
            reelFactor = this.currentRow + this.currentRow
                    * (this.spinDataModelObj.imagePerColumn - 1);
            if (reelImageObj.id >= 0
                    && reelImageObj.id < (this.spinDataModelObj.imagePerColumn - 1)) {
                reelImageObj.y = this.currReelArray[reelImageObj.id + 1].y
                        - this.spinDataModelObj.imageHeight
                        + (this.spinDataModelObj.speed - 10);
            } else {
                reelImageObj.y = this.currReelArray[(reelImageObj.id % reelFactor) + 1].y
                        - this.spinDataModelObj.imageHeight
                        + (this.spinDataModelObj.speed - 10);
            }
        }

    } else {
        if (reelImageObj.id < this.spinDataModelObj.imagePerColumn) { //Logic for move symbols while they are in middle of canvas
            reelImageObj.y += this.reelSpeed1;
        }
        if (reelImageObj.id > (this.spinDataModelObj.imagePerColumn - 1)
                && reelImageObj.id < (2 * this.spinDataModelObj.imagePerColumn)) {
            reelImageObj.y += this.reelSpeed2;
        }
        if (reelImageObj.id > ((2 * this.spinDataModelObj.imagePerColumn) - 1)
                && reelImageObj.id < (3 * this.spinDataModelObj.imagePerColumn)) {
            reelImageObj.y += this.reelSpeed3;
        }
        if (reelImageObj.id > ((3 * this.spinDataModelObj.imagePerColumn) - 1)
                && reelImageObj.id < (4 * this.spinDataModelObj.imagePerColumn)) {
            reelImageObj.y += this.reelSpeed4;
        }
        if (reelImageObj.id > ((4 * this.spinDataModelObj.imagePerColumn) - 1)
                && reelImageObj.id < (5 * this.spinDataModelObj.imagePerColumn)) {
            reelImageObj.y += this.reelSpeed5;
        }
    }
}

/*
 *draw all reel symbol which are in reelHolderArr array 
 */
Spin.prototype.drawAllReelSymbol = function() {
    for (i = 0; i < this.spinDataModelObj.columnCount; i += 1) {
        for (k = 0; k < this.spinDataModelObj.imagePerColumn; k += 1) {
            for (var m = 0; m < this.imageHolderArr.length; m++)
                if (this.imageHolderArr[m].name == this.reelHolderArr[i][k].name) {
                    this.reelHolderArr[i][k].img = this.imageHolderArr[m].img;
                    this.reelCtx.drawImage(this.reelHolderArr[i][k].img,
                    this.reelHolderArr[i][k].x,
                    this.reelHolderArr[i][k].y);
                }
        }
    }
};

/*
 *  This Method assign value in TextField
 */

Spin.prototype.drawTextFields = function() {
    //display credit amount in credit input textbox
    $("#credit-text").attr("value","$"+ parseFloat(this.spinDataModelObj.creditPoint.trim()).toFixed(2)); 
    $("#win-text").attr("value","$" + parseFloat(this.spinDataModelObj.winningAmount).toFixed(2)); 

    if ($("#spin").val() === "Free Spin" || $("#spin").val() === "Freespin and Bonus") {
        var coinvalue = $('#coin-val-txt').val();
        if (coinvalue.indexOf('$') != -1) {
            coinvalue = coinvalue.trim().substring(1, coinvalue.length) * 100;
        } else {
            coinvalue = coinvalue.trim().substring(0, coinvalue.length - 1);
        }
        coinvalue = coinvalue + "";
        for (var i = 0; i < this.spinDataModelObj.jackpotPercentageArray.length; i++) {
            if (coinvalue === this.spinDataModelObj.jackpotPercentageArray[i]) {
                this.coinValCount = i;
            }
        }
        this.paylineValCount = parseInt($("#payline-val-txt").val());
    }
    $("#freespin").attr("value", this.spinDataModelObj.avaliableFreeSpins);
    
    if(this.spinDataModelObj.isPostUpdateAutoSpinContainer === true && this.spinDataModelObj.bIsAutoFreeSpin === false){
        
        if(this.spinDataModelObj.autoSpinCount === 0){
            this.spinDataModelObj.isPostUpdateAutoSpinContainer = false;
        }
        this.updateAutoSpinContainer();
    }
};

Spin.prototype.updateAutoSpinContainer= function() {
    var self = this;
    if(this.updateAutoSpinContainerTimer !== null){
        clearInterval(this.updateAutoSpinContainerTimer);
    }
    
    this.updateAutoSpinContainerTimer = setInterval(function(){
           if(self.spinDataModelObj.bIsReelStoped === true && self.spinDataModelObj.bIsBonusWin === false 
                   && self.spinDataModelObj.bonusGameVisible === false){
              clearInterval(self.updateAutoSpinContainerTimer);
              $("#autospin").attr("value", self.spinDataModelObj.autoSpinCount);
              var winAmount =    $('#win-text').val();
              winAmount = winAmount.substring(1,winAmount.length);
              var totalAmount = (parseFloat(winAmount) + parseFloat(self.spinDataModelObj.autoSpinTotalWinAmt)).toFixed(2);
              self.spinDataModelObj.autoSpinTotalWinAmt = totalAmount;
              
              $("#autospin_totalwin").val("$"+totalAmount);
              self.spinDataModelObj.bonusWinAmount = 0.00;
           }
    },50);
}
/*
 * This method update game screen through image icons
 */
Spin.prototype.updateGameScreen = function() {

    var i, colNo, rowNo, animCount, currentSymbArr = [];
    this.animArray = [];
    currentSymbArr = this.spinDataModelObj.highLightSymbArr[this.paylineShowCount].split(",");
    if (currentSymbArr != "") {
        for (i = 0; i < currentSymbArr.length; i += 1) {
            colNo = Math.floor(parseInt(currentSymbArr[i]) / 3);
            rowNo = (parseInt(currentSymbArr[i]) % 3);
            for (animCount = 0; animCount < this.animHolderArr.length; animCount += 1) {
                if (this.animHolderArr[animCount].name === this.reelHolderArr[colNo][rowNo].name) {
                    this.animationObj = new Animation(
                            this.animHolderArr[animCount].img,
                            this.reelHolderArr[colNo][rowNo].x,
                            this.reelHolderArr[colNo][rowNo].y - 1, 318, 261, this.spinDataModelObj); 
                    this.animArray.push(this.animationObj);
                }
            }
        }
        this.startAnimLoading();
    } else {
        this.spinDataModelObj.blshowBonusGame = true;
        this.spinDataModelObj.bIsWinLineShowStoped = true;
    }
};

Spin.prototype.startAnimLoading = function() {
    "use strict";
    var j;
    this.animRunning = true;
    this.paylineObj.showOnePayline(
            this.spinDataModelObj.activePaylineArr[this.paylineShowCount],
            this.spinDataModelObj.winMessage[this.paylineShowCount]);
    for (j = 0; j < this.animArray.length; j += 1) {
        this.animArray[j].startAnimation(this.reelCtx, this.spinDataModelObj.highLightSymbArr.length);
    }

    if (this.spinDataModelObj.highLightSymbArr.length > 1) {
        this.switchPayLines();
    }

    if (this.blWinSoundON === true) {
        this.WinningSound();
    }

};

/*
 * This method is used for play the winning sound if player wins on pay lines.
 */
Spin.prototype.WinningSound = function() {
    if (this.spinDataModelObj.isSoundPlay === true) {
        this.spinDataModelObj.winSound.stop().play();
    }
};

/*
 * This method switchs payline while winning on different 
 * payline one by one until the next spin play. 
 */

Spin.prototype.switchPayLines = function() {
    var self = this;

    this.changePayTimer = setTimeout(
            function() {
                self.postUpdation();
                if (self.paylineShowCount == self.spinDataModelObj.highLightSymbArr.length - 1) {
                    self.paylineObj
                            .hideOnePayline(self.spinDataModelObj.activePaylineArr[self.spinDataModelObj.activePaylineArr.length - 1]);
                    self.paylineShowCount = 0;
                    self.blWinSoundON = false;
                    self.spinDataModelObj.blshowBonusGame = true;
                    self.spinDataModelObj.bIsWinLineShowStoped = true;
                } else {
                    self.paylineObj
                            .hideOnePayline(self.spinDataModelObj.activePaylineArr[self.paylineShowCount]);
                    self.paylineShowCount += 1;
                }
                self.updateGameScreen();
            }, 1500);
}

/*
 * This method is for payline Button Click handler
 */
Spin.prototype.paylineBtnClickHandler = function(e) {

    if (this.animRunning == true) {
        this.postUpdation();
    }
    var paylineNo = parseInt(e.target.innerHTML, 10);
    this.paylineTxtFld.attr('value', paylineNo);
    this.paylineValCount = parseInt(paylineNo);
    this.lineBetTxt.attr('value',"$"+ (this.paylineValCount* (this.spinDataModelObj.coinvalArray[this.coinValCount]) / 100).toFixed(2));
    this.paylineValCount = paylineNo;
    this.paylineObj.showTargetPaylines(paylineNo);
    if (paylineNo !== parseInt(this.spinDataModelObj.totalPaylines)) {
        $("#next-paybtn").attr("disabled", false);
    } else {
        $("#next-paybtn").attr("disabled", true);
    }
    if (paylineNo !== 1) {
        $("#prev-paybtn").attr("disabled", false);
    } else {
        $("#prev-paybtn").attr("disabled", true);
    }
}
/*
 * This method calls when we click on payline previous and next 
 * button to increase and decrease payline number.
 */

$(window).load(function() {
    //Added by vikas
    $("#prev-paybtn").attr("disabled", true);
    $("#prev-coinval").attr("disabled", true);
});

Spin.prototype.payBtnClickHandler = function(evt) {
    var payNextBtn = "next-paybtn", payPrevBtn = "prev-paybtn";
    $('.issueReport-btn-gtr, .resposible_page_btn').removeClass('animate-r');
    this.paylineValCount = parseInt($("#payline-val-txt").val());   
    if(this.animRunning == true) {
        this.postUpdation();
    }
    if (evt.target.id === payNextBtn) {
        if(this.spinDataModelObj.isSoundPlay === true){
            this.spinDataModelObj.paylinesel.stop().play();
        }
        
        if(parseInt(this.paylineValCount) != parseInt(this.spinDataModelObj.totalPaylines)){
            $("#"+payPrevBtn).attr("disabled",false);
        }

        if(parseInt(this.paylineValCount) < parseInt(this.spinDataModelObj.totalPaylines)){
            this.paylineValCount = parseInt(this.paylineValCount)+1;
        }

        if (parseInt(this.paylineValCount) > parseInt(this.spinDataModelObj.totalPaylines) && parseInt($("#payline-val-txt").val()) > parseInt(this.spinDataModelObj.totalPaylines)) {
            this.paylineValCount = parseInt(this.spinDataModelObj.totalPaylines);
        }

        if (this.paylineValCount === parseInt(this.spinDataModelObj.totalPaylines)) {
            $("#"+payNextBtn).attr("disabled",true);
        }

        this.paylineTxtFld.attr('value', this.paylineValCount);
        this.paylineObj.showTargetPaylines(this.paylineValCount);
    }
    
    if (evt.target.id === payPrevBtn) {
        if(this.spinDataModelObj.isSoundPlay === true){
            this.spinDataModelObj.paylinesel.stop().play();
        }
        
        if(this.paylineValCount!= 1){
            $("#"+payNextBtn).attr("disabled",false);
        }
        
        this.paylineValCount = parseInt(this.paylineValCount)-1;
        if (this.paylineValCount <= 1) {
            this.paylineValCount = 1;
            $("#"+payPrevBtn).attr("disabled",true);
        }

        this.paylineTxtFld.attr('value', this.paylineValCount);
        this.paylineObj.showTargetPaylines(this.paylineValCount);
    }
    this.lineBetTxt.attr('value', "$" + (this.paylineValCount * (this.spinDataModelObj.coinvalArray[this.coinValCount])/100).toFixed(2));
}

/*
 * This method generate the event while click on coin 
 * value + or - button for increase or decrease the coin denomination.
 */

Spin.prototype.coinValBtnHandler = function(evt) {
    var coinNextBtn = "next-coinval", coinPrevBtn = "prev-coinval";
    if (evt.target.id === coinPrevBtn) {
        this.coinValCount -= 1;
        if (this.coinValCount < 0) {
            this.coinValCount = 0;
        }
        if (this.spinDataModelObj.coinvalArray[this.coinValCount] >= 100) {
            this.coinValFld.attr("value", "$"+ this.spinDataModelObj.coinvalArray[this.coinValCount]/ 100);
            $("#" + coinNextBtn).attr("disabled", false);
            if (this.spinDataModelObj.isSoundPlay === true) {
                this.spinDataModelObj.paylinesel.stop().play();
            }
        } else {
            this.coinValFld.attr("value",(this.spinDataModelObj.coinvalArray[this.coinValCount])+ "\242");
            if (this.spinDataModelObj.coinvalArray[this.coinValCount] >= 1) {
                if (this.spinDataModelObj.isSoundPlay === true) {
                    this.spinDataModelObj.paylinesel.stop().play();
                }
                $("#" + coinNextBtn).attr("disabled", false);
                
                if (this.coinValCount == 0) {
                    this.spinDataModelObj.paylinesel.pause;
                    $("#" + coinPrevBtn).attr("disabled", true);
                }
            } else {
                if (this.spinDataModelObj.isSoundPlay === true) {
                    this.spinDataModelObj.paylinesel.pause;
                }
                $("#" + coinPrevBtn).attr("disabled", true);
            }

        }
    }
    if (evt.target.id === coinNextBtn) {

        this.coinValCount += 1;
        if (this.coinValCount > this.spinDataModelObj.coinvalArray.length - 1) {
            this.coinValCount = this.spinDataModelObj.coinvalArray.length - 1;
        }
        if (this.spinDataModelObj.coinvalArray[this.coinValCount] >= 100) {
            this.coinValFld.attr("value", "$"+ this.spinDataModelObj.coinvalArray[this.coinValCount]/ 100);
            if (this.spinDataModelObj.isSoundPlay === true) {
                this.spinDataModelObj.paylinesel.stop().play();
            }
            if (this.spinDataModelObj.coinvalArray[this.coinValCount] >= 500) {
                if (this.spinDataModelObj.isSoundPlay === true) {
                    this.spinDataModelObj.paylinesel.pause;
                }
                $("#" + coinNextBtn).attr("disabled", true);
            }
        } else {
            if (this.spinDataModelObj.isSoundPlay === true) {
                this.spinDataModelObj.paylinesel.stop().play();
            }
            $("#" + coinPrevBtn).attr("disabled", false);
            this.coinValFld.attr("value",(this.spinDataModelObj.coinvalArray[this.coinValCount])+ "\242");
        }
    }

    this.lineBetTxt.attr('value',"$"+ (this.paylineValCount * (this.spinDataModelObj.coinvalArray[this.coinValCount]) / 100).toFixed(2));
}

//clear game screen before next spin

Spin.prototype.postUpdation = function() {
    clearTimeout(this.changePayTimer);
    if (this.animArray.length > 0) {
        var animCount = 0;
        this.animRunning = false;
        for (animCount; animCount < this.animArray.length; animCount++) {
            this.animArray[animCount].clearAllInterval();
        }
        this.animArray = [];
    }
    this.reelCtx.clearRect(0, 0, this.spinDataModelObj.canvasWidth,
            this.spinDataModelObj.canvasHeight);
    this.drawAllReelSymbol();
}

//For recieving paytable data
Spin.prototype.rcvPaytableData = function() {
    this.stringSplitObj.responsePayTableData();
}

/*
 * This handler handles the event when click on bet one button.
 */
Spin.prototype.betOneHandler = function() {
    $('.auto-spin-control').removeClass('autospin-animate');
    $('.auto-spin-control input').removeAttr('checked');
    if ($(window).width() <= 767) {
        $("#show-menu").removeClass('move-up');
        $('.footer-bottom-new').removeClass('animate-f');
    }
    this.paylineValCount = 1;
    this.paylineTxtFld.attr('value', this.paylineValCount);
    this.lineBetTxt.attr('value',"$"+ (this.paylineValCount * (this.spinDataModelObj.coinvalArray[this.coinValCount]) / 100).toFixed(2));
    this.spinBtnHandler(2);
}

/*
 * This handler handle the event of bet max button.
 */
Spin.prototype.betMaxHandler = function() {
    $('.auto-spin-control').removeClass('autospin-animate');
    $('.auto-spin-control input').removeAttr('checked');
    if ($(window).width() <= 767) {
        $("#show-menu").removeClass('move-up');
        $('.footer-bottom-new').removeClass('animate-f');
    }
    
    this.paylineValCount = this.spinDataModelObj.totalPaylines;
    this.paylineTxtFld.attr('value', this.paylineValCount);
    this.lineBetTxt.attr('value',"$"+ (this.paylineValCount    * (this.spinDataModelObj.coinvalArray[this.coinValCount]) / 100).toFixed(2));
    this.spinBtnHandler(1);
}

/*
 * This handler use to close the window of game.
 */
Spin.prototype.handleExitBtn = function() {
    var self = window;
    var thisSelf = this;
    $('.auto-spin-control').removeClass('autospin-animate');
	$('.auto-spin-control input').removeAttr('checked');
    setTimeout(function() {
        $(".informationpopup").resizer(1.3);
        $(".informationpopup").fitText(3.3);

    });

    this.exitpopup = $("<div id='dummyHandler' class='progress-fix' style='background-color:rgba(0,0,0, 0.8); width:100%; height:100%; position:fixed; top:0; left:0; '><div class='informationpopup'> <div class='game-exit-poup' ><div class='popupfotter close_btn_main'><button type='button' class='close_button'></button> </div><p>error</p><div class='popupfotter'><button type='button' class='ok_error_button'></button> </div></ </div></div></div>");
    if (this.spinDataModelObj.isSoundPlay === true) {
        this.spinDataModelObj.PopupSound.stop().play();
    }

    this.spinDataModelObj.isDummyHandlerActive= true;
    $(".main").append(this.exitpopup);
    $(".game-exit-poup p").text($.i18n.prop("game.exit"));
    $('.ok_error_button').click(function() {
        $("#dummyHandler").remove();
        thisSelf.spinDataModelObj.isDummyHandlerActive=false;
        if(thisSelf.spinDataModelObj.isSoundPlay === true){
        	thisSelf.spinDataModelObj.ButtonClick.stop().play();
        }
        self.open('', '_self', '');
        self.close();
    });
    $('.close_button').click(function() {
        $("#dummyHandler").remove();
        thisSelf.spinDataModelObj.isDummyHandlerActive=false;
        thisSelf.spinDataModelObj.PopupSound.stop();
         if(thisSelf.spinDataModelObj.isSoundPlay === true){
        	thisSelf.spinDataModelObj.ButtonClick.stop().play();
        }
    });
};

/*
 * This handler handles the sounds on ,off event.
 */

Spin.prototype.sndBtnHandler = function(e) {
    $("#sound-btn-id").toggleClass("sound_btn_off");
    if ($("#sound-btn-id").hasClass("sound_btn_off")) {
        for (var soundcount = 0; soundcount < this.spinDataModelObj.sndArr.length; soundcount++) {
            this.spinDataModelObj.sndArr[soundcount].pause();
        }
        this.spinDataModelObj.isSoundPlay = false;
    } else {
        this.spinDataModelObj.isSoundPlay = true;
    }
};

Spin.prototype.showHf = function() {
    var self = this;
    if(this.showHfStartTimer != null){
        clearInterval(this.showHfStartTimer);
    }
    
    this.showHfStartTimer = setInterval(function (){
        if (self.spinDataModelObj.bIsWinLineShowStoped === true) {
            $('.footer-bottom-new').addClass('animate-f');
            $("#show-menu").addClass('move-up');
            clearInterval(self.showHfStartTimer);
        }
  }, 20);
}

Spin.prototype.HideHf = function() {
    if ($(window).width() < 767) {
        $('.footer-bottom-new').removeClass('animate-f');    
    }
}

/**
 * This Method is called when radio button checked.
 */
Spin.prototype.radioautospinBtnHandler = function(e) {
	
    if(this.spinDataModelObj.isSoundPlay === true){ 
        this.spinDataModelObj.ButtonClick.stop().play();
    }
    this.autoSpinRadioValue = parseInt($(e.target).val());
    //$('.auto-spin-control input').removeAttr('checked');
}
/**
 * This Method is called when auto Spin button event is clicked.
 */
// 
Spin.prototype.autospinBtnHandler = function() {
    var self = this;
    $('.auto-spin-control input').removeAttr('checked');
    $('.auto-spin-control').toggleClass('autospin-animate');
    
    if ($(window).width() <= 767) {
        $("#show-menu").removeClass('move-up');
        $('.footer-bottom-new').removeClass('animate-f');
    }
    
    this.spinDataModelObj.isAutoSpin = true;
    if(this.spinDataModelObj.isSoundPlay === true){ 
        this.spinDataModelObj.ButtonClick.stop().play();
    }
    var amt = 0.00;
    this.spinDataModelObj.autoSpinCount = this.autoSpinRadioValue;
    this.spinDataModelObj.autoSpinPayLine = $("#payline-val-txt").val();
    this.spinDataModelObj.autoSpinCoinValue = $("#coin-val-txt").val();
    this.spinDataModelObj.autoSpinTotalWinAmt = (amt.toFixed(2));
    
    
    $("#autospin").attr("value", this.spinDataModelObj.autoSpinCount);
    $("#autospin_totalwin").val("$"+(this.spinDataModelObj.autoSpinTotalWinAmt));
    $('#autospin-payline').val(this.spinDataModelObj.autoSpinPayLine);
    $('#autospin-coinvalue').val(this.spinDataModelObj.autoSpinCoinValue);
    this.spinServiceObj.autoSpinPerform(0);
}

Spin.prototype.stopAutoSpinBtnHandler = function(){
    var self = this;
    if (this.spinDataModelObj.isSoundPlay === true) {
        this.spinDataModelObj.ButtonClick.stop().play();
    }
    this.spinDataModelObj.autoSpinCount = 0;
    this.spinDataModelObj.bIsReelStoped = true;

}

Spin.prototype.responsiblePageBtnHandler = function(){
    if(this.spinDataModelObj.isSoundPlay === true){ 
        this.spinDataModelObj.ButtonClick.stop().play();
    }
    window.open("https://chancesgames.com/ResponsibleGaming/ResponsibleGaming");
}

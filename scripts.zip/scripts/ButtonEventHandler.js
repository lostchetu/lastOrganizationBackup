/*
 * This method calls when the js load and assign all button objects.
 */
function ButtonEventHandler(spinObj,reelDataModelObj,stringSplitObj){
    this.spinObj = spinObj;
    this.btnDataModel = reelDataModelObj ;
    this.stringobjs = stringSplitObj;
    this.spinBtn = $(".spin_btn");
    this.autospinBtn = $("#showAutoSpin");
    this.disableAutoSpin = $(".autospin_show");
    this.radioAutoSpin = $("input[name='RadioAutoSpin']");
    var payBtnCount=0 ;
    this.paylineBtnArray =[];
    for (payBtnCount; payBtnCount < this.btnDataModel.totalPaylines; payBtnCount += 1) {
        this.paylineBtnArray[payBtnCount] = $('.payline_btn_' + (payBtnCount + 1));
    }
    
    this.nextPayBtn = $("#next-paybtn");
    this.prevPayBtn = $("#prev-paybtn");
    this.nextCoinVal = $("#next-coinval");
    this.prevCoinVal = $("#prev-coinval");
    this.paytableBtn = $("#paytable-btn");

    this.betOneBtn = $("#bet-one");
    this.betMaxBtn = $("#bet-max");
    this.freeSpinBtn = $("#freeSpinBtn");
    this.exitBtn = $(".exit-btn");// it work for exit the game
    this.historyBtn = $(".history-btn");
    this.soundBtn = $("#sound-btn-id");
    this.helpBtn = $(".help-btn");
    this.issueReport = $(".issueReport-btn-gtr");
    this.responsiblePage = $(".resposible_page_btn");
    this.reportIssueBtn = $("#reportIssue");
    this.closeIssuereportBtn = $("#closeForm");
    this.stopAutoSpin = $("#stopSpin");
    this.radioAutoSpin.bind("change", $.proxy(this.spinObj.radioautospinBtnHandler, this.spinObj));
    this.paytableBtnEventInit();
    this.unAssignAutoSpinContainer();
    this.unAssignAutoFreeSpin();
    this.containerShowHideEventInit();
}

/*
 * This method bind the button event.
 */
ButtonEventHandler.prototype.assignBtnEvents= function(){
    var self = this; 
    this.enableSpinBtn();
    if(this.btnDataModel.isButtonEventsBinded === false){
        this.btnDataModel.isButtonEventsBinded = true;
        var payBtnCount = 0 ;
        this.spinBtn.unbind("click").bind("click", $.proxy(this.spinObj.spinBtnHandler, this.spinObj));
    
        this.autospinBtn.unbind("click").bind("click", $.proxy(this.spinObj.autospinBtnHandler, this.spinObj));
        this.disableAutoSpin.bind("click", $.proxy(this.spinObj.radioautospinBtnHandler, this.spinObj));
    
        this.reportIssueBtn.unbind("click").bind("click", $.proxy(this.stringobjs.reportIssueBtnHandler, this.spinObj));
        this.betOneBtn.unbind("click").bind("click", $.proxy(this.spinObj.betOneHandler, this.spinObj));
        this.betMaxBtn.unbind("click").bind("click", $.proxy(this.spinObj.betMaxHandler, this.spinObj));
        
        this.nextPayBtn.unbind("click").bind("click", $.proxy(this.spinObj.payBtnClickHandler, this.spinObj));
        this.prevPayBtn.unbind("click").bind("click", $.proxy(this.spinObj.payBtnClickHandler, this.spinObj));
        this.nextCoinVal.unbind("click").bind("click", $.proxy(this.spinObj.coinValBtnHandler, this.spinObj));
        this.prevCoinVal.unbind("click").bind("click", $.proxy(this.spinObj.coinValBtnHandler, this.spinObj));
        
        this.paytableBtn.unbind("click").bind("click", $.proxy(this.spinObj.rcvPaytableData, this.spinObj));
        for (payBtnCount; payBtnCount < this.paylineBtnArray.length; payBtnCount += 1) {
             this.paylineBtnArray[payBtnCount].unbind("click").bind("click", $.proxy(this.spinObj.paylineBtnClickHandler, this.spinObj));
        }  
    
        this.setFreeSpinHandler();
        this.setSpinHandler();
        this.exitBtn.unbind("click").bind("click", $.proxy(this.spinObj.handleExitBtn, this.spinObj));
        this.historyBtn.unbind("click").bind("click", $.proxy(this.stringobjs.spinHistoryload, this.stringobjs));
        this.soundBtn.unbind("click").bind("click", $.proxy(this.spinObj.sndBtnHandler, this.spinObj));
        this.helpBtn.unbind("click").bind("click", $.proxy(this.stringobjs.sndHelpBtnHandler, this.stringobjs));
        this.closeIssuereportBtn.unbind("click").bind("click", $.proxy(this.stringobjs.closeIssueReport, this.spinObj));
        
        this.responsiblePage.unbind("click").bind("click", $.proxy(this.spinObj.responsiblePageBtnHandler, this.spinObj));
    }
};

/*
 * This method un-bind the button event.
 */
ButtonEventHandler.prototype.unAssignSpinBtnEvents= function(){
    this.btnDataModel.isButtonEventsBinded = false;
    this.disableSpinBtn();
    var payBtnCount = 0 ;
    this.spinBtn.unbind("click", $.proxy(this.spinObj.spinBtnHandler, this.spinObj));
    
    this.autospinBtn.unbind("click", $.proxy(this.spinObj.autospinBtnHandler, this.spinObj));
    this.disableAutoSpin.unbind("click", $.proxy(this.spinObj.radioautospinBtnHandler, this.spinObj));
    
    this.betOneBtn.unbind("click", $.proxy(this.spinObj.betOneHandler, this.spinObj));
    this.betMaxBtn.unbind("click", $.proxy(this.spinObj.betMaxHandler, this.spinObj));
    this.nextPayBtn.unbind("click", $.proxy(this.spinObj.payBtnClickHandler, this.spinObj));
    this.prevPayBtn.unbind("click", $.proxy(this.spinObj.payBtnClickHandler, this.spinObj));
    this.nextCoinVal.unbind("click", $.proxy(this.spinObj.coinValBtnHandler, this.spinObj));
    this.prevCoinVal.unbind("click", $.proxy(this.spinObj.coinValBtnHandler, this.spinObj));
    this.exitBtn.unbind("click", $.proxy(this.spinObj.handleExitBtn, this.spinObj));
    this.soundBtn.unbind("click", $.proxy(this.spinObj.sndBtnHandler, this.spinObj));
    this.freeSpinBtn.unbind("click", $.proxy(this.spinObj.freeSpinBtnHandler, this.spinObj));
    this.historyBtn.unbind("click", $.proxy(this.stringobjs.spinHistoryload, this.stringobjs));
    this.helpBtn.unbind("click", $.proxy(this.stringobjs.sndHelpBtnHandler, this.stringobjs));
    for (payBtnCount; payBtnCount < this.paylineBtnArray.length; payBtnCount += 1) {
        this.paylineBtnArray[payBtnCount].unbind("click", $.proxy(this.spinObj.paylineBtnClickHandler, this.spinObj));
    }
    this.issueReport.attr("disabled", true);
    this.responsiblePage.attr("disabled", true);
    this.reportIssueBtn.unbind("click", $.proxy(this.stringobjs.reportIssueBtnHandler, this.spinObj));
    this.closeIssuereportBtn.unbind("click", $.proxy(this.stringobjs.closeIssueReport, this.spinObj));
    this.responsiblePage.unbind("click", $.proxy(this.spinObj.responsiblePageBtnHandler, this.spinObj));
};

/*
 * This method enable all buttons when spin done 
 */

ButtonEventHandler.prototype.enableSpinBtn= function(){
    var payBtnCount = 0 ;
    this.spinBtn.attr("disabled", false);
    this.betOneBtn.attr("disabled", false);
    this.betMaxBtn.attr("disabled", false);
    var payLineValue = parseInt($("#payline-val-txt").val());    
    if(payLineValue !== parseInt(this.btnDataModel.totalPaylines)){
        this.nextPayBtn.attr("disabled", false);
    }
    if(payLineValue !== 1){
        this.prevPayBtn.attr("disabled", false);
    }
    this.nextCoinVal.attr("disabled", false);
    //this.prevCoinVal.attr("disabled", false);
    this.paytableBtn.attr("disabled", false);
    this.exitBtn.attr("disabled", false);
    this.soundBtn.attr("disabled", false);
    this.freeSpinBtn.attr("disabled", false);
    this.historyBtn.attr("disabled", false);
    this.helpBtn.attr("disabled", false);
    this.autospinBtn.attr("disabled", false);
    this.disableAutoSpin.attr("disabled", false);
    
    for (payBtnCount; payBtnCount < this.paylineBtnArray.length; payBtnCount += 1) {
        this.paylineBtnArray[payBtnCount].attr("disabled", false);
    }
    this.issueReport.attr("disabled", false);
    this.responsiblePage.attr("disabled", false);
    this.reportIssueBtn.attr("disabled", false);
};

/*
 * This method is for disable at the time of spin.
 */

ButtonEventHandler.prototype.disableSpinBtn= function(){
    var payBtnCount = 0 ;    
    this.spinBtn.attr("disabled", true);
    this.betOneBtn.attr("disabled", true);
    this.betMaxBtn.attr("disabled", true);
    this.nextPayBtn.attr("disabled", true);
    this.prevPayBtn.attr("disabled", true);
    this.nextCoinVal.attr("disabled", true);
    //this.prevCoinVal.attr("disabled", true);
    this.paytableBtn.attr("disabled", true);
    this.exitBtn.attr("disabled", true);
    this.soundBtn.attr("disabled", true);
    this.freeSpinBtn.attr("disabled", true);
    this.historyBtn.attr("disabled", true);
    this.helpBtn.attr("disabled", true);
    this.autospinBtn.attr("disabled", true);
    this.disableAutoSpin.attr("disabled", true);
    for (payBtnCount; payBtnCount < this.paylineBtnArray.length; payBtnCount += 1) {
        this.paylineBtnArray[payBtnCount].attr("disabled", true);
    }
    this.issueReport.attr("disabled", true);
    this.responsiblePage.attr("disabled", true);
    this.reportIssueBtn.attr("disabled", true);
    
};

/*
 * This method bind the event for free spin.
 */

ButtonEventHandler.prototype.setFreeSpinHandler=function(){
    if(this.btnDataModel.avaliableFreeSpins > 0) {
       this.unAssignSpinBtnEvents();
       this.freeSpinBtn.attr("disabled", true).unbind("click").bind("click", $.proxy(this.spinObj.freeSpinBtnHandler, this.spinObj));
    } else {
       this.freeSpinBtn.attr("disabled", true).unbind("click", $.proxy(this.spinObj.freeSpinBtnHandler, this.spinObj));
    }
};

/*
 *This method call when the player win free spin and 
 *assgin event to to auto free spin button. 
 */

ButtonEventHandler.prototype.assignAutoFreeSpin = function(){
    $(".reel-container").addClass("real-height-change");
    $("#autospinBtn").attr("disabled",false);
    $('#freespin-payline').val($("#payline-val-txt").val());
    $('#freespin-coinvalue').val($("#coin-val-txt").val());

    $(".footer-bottom-new").css("display","none");
    $(".menu_btn_demo").css("display","none");
    $(".freespin-container").css("display","block");
    $(".autospin-container").css("display","none");
};

/*
 *This method call when the player has completed their free spin 
 *and un-assgin event to to auto free spin button. 
 */
ButtonEventHandler.prototype.unAssignAutoFreeSpin=function(){

  $(".reel-container").removeClass("real-height-change");
  $(".footer-bottom-new").css("display","block");
  $(".menu_btn_demo").css("display","block");
  $(".freespin-container").css("display","none");
  $(".autospin-container").css("display","none");
  
  $("#autospinBtn").attr("disabled",true);
  $("#freeSpinBtn").attr("disabled", true);
};


ButtonEventHandler.prototype.setSpinHandler=function(){
    if(this.btnDataModel.autoSpinCount > 0 && this.btnDataModel.isAutoSpin === true) {
        this.unAssignSpinBtnEvents();
    }
};

/*
 *assgin event to to auto spin button. 
 */
ButtonEventHandler.prototype.assignAutoSpinContainer = function(){
    this.stopAutoSpin.unbind("click").bind("click", $.proxy(this.spinObj.stopAutoSpinBtnHandler, this.spinObj));
    $(".reel-container").addClass("real-height-change");
    $("#autospinBtn").attr("disabled",false);
    $(".autospin-container").css("display","block");
    $(".footer-bottom-new").css("display","none");
    $(".freespin-container").css("display","none");
    $(".menu_btn_demo").css("display","none");
    $("#stopSpin").css("display","block");
};

/*
 *and un-assgin event to to auto spin button. 
 */
ButtonEventHandler.prototype.unAssignAutoSpinContainer=function() {
    this.stopAutoSpin.unbind("click", $.proxy(this.spinObj.stopAutoSpinBtnHandler, this.spinObj));
    $(".reel-container").removeClass("real-height-change");
    $(".footer-bottom-new").css("display","block");
    $(".menu_btn_demo").css("display","block");
    $(".autospin-container").css("display","none");
    $(".freespin-container").css("display","none");
    $("#autospinBtn").attr("disabled",true);
    $("#stopSpin").css("display","none");
};


ButtonEventHandler.prototype.assignFooterBottom = function(){
    $(".freespin-container").css("display","none");
    $(".autospin-container").css("display","none");
    $(".footer-bottom-new").css("display","block");
    $(".menu_btn_demo").css("display","block");
};

ButtonEventHandler.prototype.unAssignFooterBottom=function(){
    $(".footer-bottom-new").css("display","none");
    $(".menu_btn_demo").css("display","none");
};

ButtonEventHandler.prototype.paytableBtnEventInit = function() {
    var self = this;
    var clas = 1;
    var $nextBtn = $('.next-btn');
    var $prevBtn = $('.prev-btn');
    var $closeBtn = $('.close_btn, .close_button, .issueReport-btn-gtr');
    var classes = '.part1, .part2, .part3';
    
    $nextBtn.click(function() {
        if(self.btnDataModel.isSoundPlay === true){ 
            self.btnDataModel.ButtonClick.stop().play();
        }
        clas++;
        $(classes).hide();
        $('.part' + clas).show();
        if (clas == 2) {
            $nextBtn.hide();
            $prevBtn.show();
        }

        if (clas == 1) {
            $nextBtn.show();
            $prevBtn.hide();
        }
    });
    
    $prevBtn.click(function() {
        if(self.btnDataModel.isSoundPlay === true){ 
            self.btnDataModel.ButtonClick.stop().play();
        }
        clas--;
        $(classes).hide();
        $('.part' + clas).show();
        if (clas == 1) {
            $prevBtn.hide();
            $nextBtn.show();
        }
        if (clas == 2) {
            $nextBtn.hide();
            $prevBtn.show();
        }
        ;
    });

    $('.paytable-btn').click(function() {
        $('.auto-spin-control').removeClass('autospin-animate');
        $('.auto-spin-control input').removeAttr('checked');
        if ($(window).width() <= 767) {
            $("#show-menu").removeClass('move-up');
            $('.footer-bottom-new').removeClass('animate-f');
        }
        
        $(classes).hide();
        $('.part1').show();
        clas = 1;
        $prevBtn.hide();
        $nextBtn.show();
    });
    
    $closeBtn.click(function() {
        $('.auto-spin-control').removeClass('autospin-animate');
        $('.auto-spin-control input').removeAttr('checked');
        if(self.btnDataModel.isSoundPlay === true){ 
            self.btnDataModel.ButtonClick.stop().play();
        }
    });
}

ButtonEventHandler.prototype.containerShowHideEventInit = function(){
	  var self = this;
    $('#AutospinBtn').on('click', function() {
         $("#showAutoSpin").attr('disabled', true);
         $('.auto-spin-control').toggleClass('autospin-animate');
         $('.auto-spin-control input').removeAttr('checked');
    });
    
    $('input[type="radio"]').on('click', function() {
       if($(this).attr('name') == 'RadioAutoSpin') {
           $("#showAutoSpin").attr('disabled', false);
       }
    });
    
    $('#autospin-close').on('click', function() {
        if(self.btnDataModel.isSoundPlay === true){
        	self.btnDataModel.ButtonClick.stop().play();
        }
        $('.auto-spin-control').toggleClass('autospin-animate');
        $('.auto-spin-control input').removeAttr('checked');
    });
    
    $("#show-menu").on('click', function() {
        $(this).toggleClass('move-up');
        $('.footer-bottom-new').toggleClass('animate-f');
        $('.auto-spin-control').removeClass('autospin-animate');
    });
    
    $("#show-menu-report").on('click', function() {
        $('.resposible_page_btn, .issueReport-btn-gtr').toggleClass('animate-r');
        $('.auto-spin-control').removeClass('autospin-animate');
        $('.auto-spin-control input').removeAttr('checked');
    });
    
    $(".sound_btn").on("click", function(){
        $('.auto-spin-control').removeClass('autospin-animate');
        $('.auto-spin-control input').removeAttr('checked');
    });
}

$(document).ready(function() {
    loadBundles("en");
});

function validateForm() {
    var userName = $("#username").val();
    var password = $("#password").val();
    var shortCircuit = false;
    var defaultUserName = ($.i18n.prop('login.default.username'));
    var defaultPassword  = ($.i18n.prop('login.default.password'));
    if(userName ==="" || userName == null || userName===defaultUserName){
        alert($.i18n.prop('login.invalid.username'));
        shortCircuit = true;
        return false;
    }
    
    if((password === "" || password == null || password===defaultPassword) && ! shortCircuit){
        alert($.i18n.prop('login.invalid.password'));
        return false;
    }
    return true;
}

function loadBundles(lang) {
    jQuery.i18n.properties({
        name:'Messages', 
        path:'messageResource/', 
        mode:'both',
        language:lang
    });
}

/* This js file controlling paylines events */
function Payline(paylineDataModel) {
    "use strict";
    this.paylineDataModel = paylineDataModel;
    this.isSoundPlay = true;
}

/*
 * This method calls when player click on the payline  and show the paylines.
 */
Payline.prototype.showTargetPaylines = function (paylineNo) {
    "use strict";
    var deselectPayLine = paylineNo, payline = 0;
    for (payline; payline < paylineNo; payline += 1) {
        
    	
        $('.payline_' + (payline + 1)).show();
        $(".payline_btn_" + (payline + 1)).css("display", "block");
        $(".payline_" + (payline + 1)+" input").css("display","none");
        if(this.paylineDataModel.isSoundPlay === true){ 
        	  this.paylineDataModel.GAME_BG_SOUND.stop();
        	this.paylineDataModel.ButtonClick.stop().play();
        }
    }
    for (deselectPayLine; deselectPayLine < this.paylineDataModel.totalPaylines; deselectPayLine += 1) {
        $('.payline_' + (deselectPayLine + 1)).hide();
        $(".payline_btn_" + (deselectPayLine + 1)).removeClass("active");
    }
};

Payline.prototype.showOnePaylineOnStart = function(paylineNo) {
    $('.payline_' + (paylineNo)).show();
    $(".payline_btn_" + (paylineNo)).css("display", "block");
};


/*
 * This method calls when player click on the payline and hide the paylines.
 */

Payline.prototype.hideAllPaylines = function() {
    "use strict";
    var paylineCount = 0;
    for (paylineCount; paylineCount < this.paylineDataModel.totalPaylines; paylineCount += 1) {
        $('.payline_' + (paylineCount + 1)).hide();
        $(".payline_btn_" + (paylineCount + 1)).removeClass("active");
    }
};

/*
 * This method call to show only one payline when click on the payline button.
 */
Payline.prototype.showOnePayline = function(paylineNo,winAmount) {
    $('.payline_' + (paylineNo)).show();
    $(".payline_btn_" + (paylineNo)).addClass("active");
    $(".payline_" + (paylineNo)+" input").css("display","block");
    
    if(winAmount!="" && winAmount !='undefined' && winAmount != null){
        $(".payline_" + paylineNo +" input").css("display","block");
        $(".payline_" + (paylineNo) +" input").attr("value","$"+ parseFloat(winAmount).toFixed(2));
    } else {
             $(".payline_" + paylineNo + " input").css("display","none");
        }
};

/*
 * This method call to hide only one payline when click on the payline button.
 */
Payline.prototype.hideOnePayline = function(paylineNo) {
    $('.payline_' + (paylineNo)).hide();
    $(".payline_btn_" + (paylineNo)).removeClass("active");
    $(".payline_" + (paylineNo)+" input").css("display","none");
};

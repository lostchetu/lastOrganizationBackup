function ErrorMessage(splitDataModel) {
    this.splitDataModel = splitDataModel ;
}

/*
 * This method calls to give the appropriate error 
 * message to the ui according to the error code. 
 */
ErrorMessage.prototype.formatErrorMessage = function(errorCode) {
    var self = this;
    var message = "";
    var hasCloseWindow = true;
    var isReloadWindow = false;
    self.splitDataModel.bHasError = true;
    if(errorCode === -1) {
        this.message = $.i18n.prop("error.default");
        this.hasCloseWindow = false;
        this.isReloadWindow = true;
    }else if (errorCode === 0) {
        this.hasCloseWindow = false;
        this.isReloadWindow = true;
        this.message = $.i18n.prop("error.network.disconnected_0");
    } else if (errorCode === 10) {
    	this.splitDataModel.reelMoveSound.stop();
        this.hasCloseWindow = true;
        this.message = $.i18n.prop("error.session.expired_10");
        
    }else if (errorCode === 11) {
        this.hasCloseWindow = true;
        this.message = $.i18n.prop("error.block.user_disable_11");
    } else if (errorCode === 20) {
        this.hasCloseWindow = true;
        this.message = $.i18n.prop("error.invalid.request_20");
    }  else if (errorCode === 25) {
        this.hasCloseWindow = false;
        this.isReloadWindow = true;
        this.message = $.i18n.prop("error.invalid.request.param_25");
    }  else if (errorCode === 26) {
        this.hasCloseWindow = true;
        this.message = $.i18n.prop("error.block.user_26");
    }  else if (errorCode === 30) {
        this.hasCloseWindow = false;
        this.isReloadWindow = true;
        this.message = $.i18n.prop("error.insufficient.balance_30");
    } else if (errorCode === 35) {
        this.hasCloseWindow = true;
        this.message = $.i18n.prop("error.invalid.payline_35");
    } else if (errorCode === 40) {
        this.hasCloseWindow = true;
        this.message = $.i18n.prop("error.invalid.coinValue_40");
    } else if (errorCode === 45) {
        this.hasCloseWindow = false;
        this.isReloadWindow = true;
        this.message = $.i18n.prop("error.invalid.connection_45");
    } else if (errorCode === 50) {
        this.hasCloseWindow = true;
        this.message = $.i18n.prop("error.invalid.spin_50");
    }else if (errorCode === 65) {
        this.hasCloseWindow = true;
        this.message =$.i18n.prop("errror.invalid.userBlock_65");
    }else if (errorCode === 70){
        this.hasCloseWindow = false;
        this.isReloadWindow = false;
        this.message = $.i18n.prop("error.invalid.balance_70");
    } else if (errorCode === 75){
        this.hasCloseWindow = false;
        this.isReloadWindow = true;
        this.message = $.i18n.prop("error.invalid.freeSpin_75");
    }else if (errorCode === 76){
        this.hasCloseWindow = false;
        this.isReloadWindow = false;
        this.message = $.i18n.prop("error.noActive_Bonus_Game_76");
    }else if (errorCode === 2){
        this.hasCloseWindow = false;
        this.isReloadWindow = false;
        this.message = $.i18n.prop("error.invalid.email");
    }else if (errorCode === 3){
        this.hasCloseWindow = false;
        this.isReloadWindow = false;
        this.message = $.i18n.prop("msg.issue.added");
    }else if (errorCode === 4){
        this.hasCloseWindow = false;
        this.isReloadWindow = false;
        this.message = $.i18n.prop("error.invalid.email");
    }else if (errorCode === 21){
        this.hasCloseWindow = true;
        this.isReloadWindow = false;
        this.message = $.i18n.prop("error.game.disable_21");
    }else if (errorCode === 22){
        this.hasCloseWindow = false;
        this.isReloadWindow = false;
        this.message = $.i18n.prop("error.game.noSpinHistory_22");
    }else if (errorCode === 81){
        this.hasCloseWindow = false;
        this.isReloadWindow = true;
        if(this.splitDataModel.blockNote != undefined && this.splitDataModel.blockNote !== null && this.splitDataModel.blockNote!==""){
        	this.message = this.splitDataModel.blockNote;
        }else{
        	this.message = $.i18n.prop("error.insufficient.limit_exceed");
        }
    }else if (errorCode === 72){
        this.hasCloseWindow = true;
        this.isReloadWindow = false;
        this.message = this.splitDataModel.selfExcluseMsg;
    }else {
        this.hasCloseWindow = false;
        this.isReloadWindow = true;
        this.message = $.i18n.prop("error.invalid.global.msg");
    }
    
    if(this.message !=="" || this.message !== undefined){
        $("#dummyHandler").remove();
        var winSelf = window;
        setTimeout(function(){
            $(".informationpopup").resizer(1.3);
            $(".informationpopup").fitText(3.3);
        
        });
        this.splitDataModel.isDummyHandlerActive=true;
        this.errorPopUp = $("<div id='dummyHandler' class='progress-fix' style='background-color:rgba(0,0,0, 0.8); width:100%; height:100%; position:fixed; top:0; left:0; '><div class='informationpopup'> <div class='error-pop' ><p></p><div class='popupfotter'><button type='button' class='ok_error_button'></button>  </div></ </div></div></div>");
            $(".main").append(this.errorPopUp);
            $(".error-pop p").append(this.message);
            if(this.splitDataModel.GAME_BG_SOUND != null ){
                this.splitDataModel.GAME_BG_SOUND.stop();
            }
            $('.ok_error_button').click(function () {
                if(self.splitDataModel.isSoundPlay === true){
                	self.splitDataModel.ButtonClick.stop().play();
                }
                if(self.hasCloseWindow === true){
                    winSelf.open('','_self',''); 
                    winSelf.close();
                }else if(self.isReloadWindow === true) {
                    location.reload(true);
                }
                self.splitDataModel.isDummyHandlerActive=false;
                $("#dummyHandler").remove();
            });
       }
};

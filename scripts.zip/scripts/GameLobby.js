// This function is used for open the old game page. 
function openGameView(gameName,gameURL,domainName,isPlayWithCustomScreen) { 
      var my_form=document.createElement('FORM');
      my_form.name=gameName;
      my_form.id=gameName;
      my_form.method='POST';
      
      my_form.action=domainName+"/"+gameName+'Game.action';
      my_form.target=gameName;
      
      var my_tb=document.createElement('INPUT');
      my_tb.type='HIDDEN';
      my_tb.name='login';
      my_tb.value=document.getElementById("login").value;
      my_form.appendChild(my_tb);

      var my_tb_pass=document.createElement('INPUT');
      my_tb_pass.type='HIDDEN';
      my_tb_pass.name='password';
      my_tb_pass.value=document.getElementById("password").value;
      my_form.appendChild(my_tb_pass);
      
      var my_tb_gameName=document.createElement('INPUT');
      my_tb_gameName.type='HIDDEN';
      my_tb_gameName.name='GameName';
      my_tb_gameName.value=gameName;
      my_form.appendChild(my_tb_gameName);
      document.body.appendChild(my_form);
      my_form.submit();
      document.body.removeChild(my_form);
}

//This function is used for open the old game page. 
function openNewGameView(gameName,isPlayWithCustomScreen){
	 var my_form=document.createElement('FORM');
     my_form.name=gameName;
     my_form.id=gameName;
     my_form.method='POST';
     
     my_form.action=gameName+'Game.action';
     my_form.target=gameName;
     
     var my_tb=document.createElement('INPUT');
     my_tb.type='HIDDEN';
     my_tb.name='login';
     my_tb.value=document.getElementById("login").value;
     my_form.appendChild(my_tb);

     var my_tb_pass=document.createElement('INPUT');
     my_tb_pass.type='HIDDEN';
     my_tb_pass.name='password';
     my_tb_pass.value=document.getElementById("password").value;
     my_form.appendChild(my_tb_pass);
     
     if(isPlayWithCustomScreen){
         var my_tb_forFun=document.createElement('INPUT');
         my_tb_forFun.type='HIDDEN';
         my_tb_forFun.name='playWithCustomScr';
         my_tb_forFun.value=true;
         my_form.appendChild(my_tb_forFun);
     }
     
     var my_tb_gameName=document.createElement('INPUT');
     my_tb_gameName.type='HIDDEN';
     my_tb_gameName.name='GameName';
     my_tb_gameName.value=gameName;
     my_form.appendChild(my_tb_gameName);
     document.body.appendChild(my_form);
     my_form.submit();
     document.body.removeChild(my_form);
}
//SpinService is used for write the method which are provide the functionality for game.
//Created By arvindkumar3
function SpinService(spinObj,btnEventObj, dataModelObj, stringSplitObj, errorMessage){
    this.serviceDataModel = dataModelObj;
    this.heartBeatObj = null;
    this.heartBeatFound = false;
    this.bonusGameObj = null;
    this.spinObj = spinObj;
    this.btnEventObj = btnEventObj;
    this.stringSplitObj = stringSplitObj;
    this.errorMessageObj = errorMessage;
    this.serviceStartTimer = null;
    this.loadBonusTimer = null;
    this.pendingGameTimer = null;
    this.hasPendingBonusGame =false;
    this.freeSpinWinTimer = null;
    this.isDummyHandlerAdded = false;
    this.autoSpinInterval = null;
    this.isFreeSpinActiveInAutoSpin = null;
    this.isBonusActiveInAutoSpin = null;
    this.isAutoSpinActive = null;
    this.isFreeSpinBonusActive = false;
    this.serviceDataModel.bonusGameVisible=false;
    this.isSoundPlay = true;
}
//This method is used for load the initial functionality which is start after remove the loader.
SpinService.prototype.initialSpinService = function(){
    var self = this;
    if(this.serviceStartTimer !== null){
        clearInterval(this.serviceStartTimer);
    }
    
    this.serviceDataModel.isAutoSpin = false;
    this.serviceDataModel.bonusGameVisible = false;
    
    this.serviceStartTimer = setInterval(function () {
       if(! $("#preloaderHandler").is("html *") && self.serviceDataModel.bIsContentLoaded === true) {
           if(self.serviceDataModel.selfExcluseMsg != undefined && self.serviceDataModel.selfExcluseMsg !== "" && self.serviceDataModel.selfExcluseMsg.length>0){
               self.btnEventObj.unAssignSpinBtnEvents();
               self.errorMessageObj.formatErrorMessage(72);
               clearInterval(self.serviceStartTimer);
           } else {
               self.btnEventObj.unAssignAutoFreeSpin();
               clearInterval(self.serviceStartTimer);
               self.getPendingBonus();
               self.checkPendingFreeSpin();
               self.startHeartBeat();
           }
       }
    },100);
}

//This method is used for player has more pending bonus game or not.
SpinService.prototype.checkOtherPendingGame = function(){
    var self = this;
    if(this.pendingGameTimer !== null){
        clearInterval(this.pendingGameTimer);
    }
    this.pendingGameTimer = setInterval(function () {
       if(self.serviceDataModel.blBonusGameClosed === true && self.hasPendingBonusGame === true) {
           self.serviceDataModel.blBonusGameClosed = false;
           self.getPendingBonus();
       }else if(self.hasPendingBonusGame === false){
           clearInterval(this.pendingGameTimer);
       }
    },1000);
};

//check player has previous free spin which are not played.
SpinService.prototype.checkPendingFreeSpin = function(){
  var self = this;
  if(parseInt(this.serviceDataModel.avaliableFreeSpins) >0 &&  this.serviceDataModel.availableFreeSpinList.length>1){
      self.serviceDataModel.bIsWinLineShowStoped = true;
      this.isDummyHandlerAdded = false;
      if(this.serviceDataModel.bIsAutoFreeSpin === false) {
          $("#total-win").val("$0.00");
      }
     var availableList = this.serviceDataModel.availableFreeSpinList;
     var list =null;
     var msg = "";
     for(var i=0;i<availableList.length-1;i++){
          list = availableList[i].split(",");
          msg =msg+ "<tr> <td style='width: 35%;'>"+list[0]+"</td><td style='width: 11%;'>$"+list[1]+"</td><td style='width: 35%;'>"+list[2]+"</td></tr>";
     }
     if(self.serviceDataModel.isSoundPlay === true){
             self.serviceDataModel.GAME_BG_SOUND.stop();
            self.serviceDataModel.PopupSound.stop().play();
            
        }
     msg = '<table>'+msg+'</table>';
     self.addFreeSpinWinPopup(this.serviceDataModel.avaliableFreeSpins, $.i18n.prop("msg.freeSpin.pending", this.serviceDataModel.avaliableFreeSpins) +"</br>"+ $.i18n.prop("msg.freeSpin.pending.list", msg),true);
   } else {
       this.startHeartBeat();
       if(this.serviceDataModel.isBonusScreenActive === false){
           this.getPendingBonus();
           this.checkOtherPendingGame();
       }
       
       this.btnEventObj.unAssignAutoFreeSpin();
   }
}

//update the game screen at idea mode
SpinService.prototype.startHeartBeat = function() {
    var self = this;
    this.serviceDataModel.isHeartBeat_ON = true;
    // check is heartBeat object is null then create new instance.
    if (this.heartBeatObj != null) {
        clearInterval(this.heartBeatObj);
    }
    this.heartBeatObj = setInterval(function() {
        if (self.serviceDataModel.isHeartBeat_ON == true ) {
            self.heartBeat();
        } 
    }, this.serviceDataModel.heartBeatDelayTime*1000);
};

//This method is used for stop the heart beat service.
SpinService.prototype.stopHeartBeat = function() {
    this.serviceDataModel.isHeartBeat_ON = false;
    if (this.heartBeatObj != null) {
        clearInterval(this.heartBeatObj);
    }
};

/*
 * This heartBeat method calls to get the latest data of game screen.
 */
SpinService.prototype.heartBeat = function() {
    var self = this;
    var gameType = $('#gameType').val();
    var isFreeSpinGame = false;
    if (gameType.trim() === 'Free Spin' || gameType.trim() === 'Freespin and Bonus'){
        isFreeSpinGame = true;
    }

    var spinSource = $('#spinSource').val();
    var spinToken = $('#spinToken').val();
    var winSelf = window;
    $.ajax({
        async : true,
        cache : false,
        timeout: 60000,
        url : "heartBeat?freeSpinGame=" + isFreeSpinGame + "&spinSource=" + spinSource+ "&spinToken=" + spinToken,
        contentType : this.contentType, 
        success : function(response) {
            if (response.responseStr) {
                self.serviceDataModel.responseStr = response.responseStr;
                if(response.spinToken){
                    $('#spinToken').val(response.spinToken);
                }
                self.heartBeatGot(response.responseStr);
                self.serviceDataModel.isHeartBeat_ON = true;
            } else if (response.hasError) {
                var json = JSON.parse(JSON.stringify(response));
                self.serviceDataModel.isHeartBeat_ON = false;
                self.stopHeartBeat();
                if((json.ErrorCode !== undefined || json.ErrorCode !=='undefined')){
                    self.errorMessageObj.formatErrorMessage(json.ErrorCode);
                }else{
                    self.errorMessageObj.formatErrorMessage(45);
                }
            } else {
                self.serviceDataModel.isHeartBeat_ON = false;
                self.stopHeartBeat();
            }
        },
        // When json call fails
        error : function() {
            self.stopHeartBeat();
        }
    });

};

/*
 * Iterator the game heart beat information and set in game screen
 */
SpinService.prototype.heartBeatGot = function (msg) {
    var self = this;
    var response = msg.split(";");
    var stringCount = 0, titleStr;
    var coinvalue = $("#coin-val-txt").val();
    this.serviceDataModel.isImposeLimitApplied = false;
    this.serviceDataModel.isSystemLimitApplied = false;
    this.serviceDataModel.selfExcluseMsg = '';
    this.serviceDataModel.blockNote = ''
     if(coinvalue.indexOf('$') != -1){
         coinvalue = coinvalue.trim().substring(1,coinvalue.length)*100;
     }else {
         coinvalue = coinvalue.trim().substring(0,coinvalue.length-1);
     }
     coinvalue = coinvalue+"";
      for (stringCount; stringCount < response.length; stringCount++) {
          titleStr = response[stringCount].split(":");
          switch (titleStr[0]) {
              case "playerCreditAmount":
                  self.serviceDataModel.creditPoint = titleStr[1];
                  $("#credit-text").attr("value","$"+((parseFloat(self.serviceDataModel.creditPoint.trim())).toFixed(2)));
                  break;
              case "jackPotAmount":
                  self.serviceDataModel.jackPotAmount = titleStr[1];
                  var jackpot = (parseFloat(self.serviceDataModel.jackPotAmount.trim())*(parseFloat(coinvalue)/100)).toFixed(2);
                  $("#jackpot-text").attr("value", "$"+jackpot);
                  break;
              case "availableFreeSpin":
                  this.serviceDataModel.avaliableFreeSpins = parseInt(titleStr[1]);
                  $("#freespin").attr("value", parseInt(titleStr[1]));
                  if(this.serviceDataModel.avaliableFreeSpins >0 && !this.isDummyHandlerAdded && this.serviceDataModel.bIsAutoFreeSpin === false && this.serviceDataModel.isBonusScreenActive === false ){
                      this.checkPendingFreeSpin();
                  } else if(!this.isDummyHandlerAdded && this.serviceDataModel.bIsAutoFreeSpin === false){
                     this.btnEventObj.unAssignAutoFreeSpin();
                  }
                  break;
              case "jackpotWinner":
                  if(titleStr[1] !== null && titleStr[1] !==""){
                      this.stringSplitObj.showHideJackpotWinner(titleStr[1]);
                  }
                  break;
                  
              case "isAccountBlk":
                  if(titleStr[1] !== null && titleStr[1] === "true"){
                      this.serviceDataModel.isAccountBlock = true;
                      this.serviceDataModel.isHeartBeat_ON = false;
                      this.stopHeartBeat();
                  } 
                  break;
                  
              case "blockNote":
                  if(titleStr[1] !== null && titleStr[1] !== "") {
                      this.serviceDataModel.blockNote = titleStr[1];
                  } 
                  break;
                  
              case "isSystemLimitApplied":
                  if(titleStr[1] !== null && titleStr[1] === "true") {
                      this.serviceDataModel.isSystemLimitApplied = true;
                  } 
                  break;
                  
              case "isLimitApplied":
                  if(titleStr[1] !== null && titleStr[1] === "true") {
                      this.serviceDataModel.isImposeLimitApplied = true;
                  } 
                  break;
                  
              case "selfExcluseMsg":
                  if(titleStr[1] !== null && titleStr[1] !== "") {
                      this.serviceDataModel.selfExcluseMsg = titleStr[1];
                  } 
                  break;
                
              default:
                  break;
          }
      }
     this.heartBeatFound = true;
 };

 /*
  *  Load the Bonus game screen for play the win bonus round
  */
 SpinService.prototype.startBonusGame = function(coinSelected) {
    var symbolValuesArr = [];
    var symbolLength=0;
    
    if(this.serviceDataModel.winBonusScoresStr.indexOf(',') != -1) {
        symbolValuesArr =  this.serviceDataModel.winBonusScoresStr.split(",");
        symbolLength = symbolValuesArr.length;
    }else{
        symbolValuesArr =  this.serviceDataModel.winBonusScoresStr.split(",");
        symbolLength = 1;
    }
    
    var bonusGameType = this.serviceDataModel.bonusGameType;
    bonusGameType = bonusGameType.trim();
    var spinId = -1;
    if(this.serviceDataModel.bIsBonusWin === true) {
        this.serviceDataModel.bIsBonusWin = false;
        this.serviceDataModel.blshowBonusGame = false;
       
        if(this.serviceDataModel.isBonusScreenActive === false){
            this.serviceDataModel.isBonusScreenActive = true;
            var bonusObj = new BonusMain(this,this.serviceDataModel.totalBonusScores,symbolValuesArr, symbolLength, (coinSelected/100),this.serviceDataModel,this.stringSplitObj);
        }
     }
  }
/*
 * This method is used for get the pending bonus game 
 */
 SpinService.prototype.getPendingBonus = function() {
    var self = this;
    var stringCount =0 ,titleStr;
    var gameType = $('#gameType').val();
    
    var spinType = $('#spin').val();
    var spinSource = $('#spinSource').val();
    var spinToken = $('#spinToken').val();
    this.hasPendingBonusGame = false;
    if (typeof(gameType) !== "undefined" && gameType !== undefined && gameType.trim() !== 'Free Spin'){
        gameURL = "checkPendingWinningBonus.action";
    
        $.ajax({
            async : true,
            cache : false,
            timeout: 40000,
            type:"POST",
            url : gameURL + "?spin=" + spinType + "&spinSource=" + spinSource+ "&spinToken=" + spinToken,
            contentType : this.contentType, 
            success : function(response) {
                if (response.responseStr !==null && response.responseStr!== undefined && response.responseStr !=='' ) {
                          self.hasPendingBonusGame = true;
                          self.serviceDataModel.isAutoSpin = false;
                          self.serviceDataModel.responseStr = response.responseStr.trim();
                          var resp = self.serviceDataModel.responseStr.split(";");
                          $('#win-text').val("$"+0.00);
                          self.btnEventObj.disableSpinBtn();
                          if(response.spinToken){
                              $('#spinToken').val(response.spinToken);
                          }
                         this.paylineObj = new Payline(self.serviceDataModel);
                         for (stringCount; stringCount < resp.length; stringCount++) {
                             titleStr = resp[stringCount].split(":");
                             switch (titleStr[0]) {
                             case "InitialPayLines":
                                 this.paylineNum = titleStr[1];
                                 break;
                             }
                         }
                          this.paylineObj.showTargetPaylines(parseInt(this.paylineNum));
                          self.stringSplitObj.paySymbolGot();
                          self.showBonusGamePopUp($.i18n.prop("bonus.pending.msg"));
                          if(self.serviceDataModel.isSoundPlay === true){
                                self.serviceDataModel.GAME_BG_SOUND.stop();
                                self.serviceDataModel.PopupSound.stop().play();
                            }
                } else {
                    if(self.pendingGameTimer !== null){
                        clearInterval(self.pendingGameTimer);
                    }
                    self.hasPendingBonusGame = false;
                    self.serviceDataModel.isAutoSpin = true;
                    var json = JSON.parse(JSON.stringify(response));
                } 
            },
            error : function() {
                self.hasPendingBonusGame = false;
                self.serviceDataModel.isAutoSpin = true;
                if(self.pendingGameTimer !== null){
                    clearInterval(self.pendingGameTimer);
                }
                self.errorMessageObj.formatErrorMessage(-1);
            }
        });
    }
 }
 //This method is used for show the pending bonus game popup.
 SpinService.prototype.showBonusGamePopUp = function(message){
    var self = this;
    if(!this.serviceDataModel.isDummyHandlerActive){
        setTimeout(function(){
            $(".informationpopup").resizer(1.3);
            $(".informationpopup").fitText(3.3);
        });
        this.serviceDataModel.isDummyHandlerActive = true;
        var bonusPopUp = $("<div id='dummyHandler' class='progress-fix' style='background-color:rgba(0,0,0, 0.8); width:100%; height:100%; position:fixed; top:0; left:0; '><div class='informationpopup'> <div class='error-pop' ><p></p><div class='popupfotter'><button type='button' class='ok_button'></button>  </div></div></div></div>");
        $(".main").append(bonusPopUp);
        $(".error-pop p").append(message);
         //   $(".popupfotter button").append(buttonTxt);
            $('.ok_button').click(function () {

                if(self.serviceDataModel.isSoundPlay === true){ 
                	self.serviceDataModel.ButtonClick.stop().play();
                }
                $("#dummyHandler").remove();
                self.serviceDataModel.isDummyHandlerActive = false;
                if(this.bonusGameObj != null){
                     clearInterval(this.bonusGameObj);
                }
                this.bonusGameObj =  setTimeout(function () {
                   if(self.serviceDataModel.bIsBonusWin === true){
                       self.startBonusGame(self.serviceDataModel.coinValue);
                   }
                },500);
            });
        }
    };

 /*
 * This method is used for load the bonus game.
 */
SpinService.prototype.loadBonusGame = function(){
    var self = this;
    if(this.loadBonusTimer != null){
        clearInterval(this.loadBonusTimer);
    }
    if(this.serviceDataModel.isAutoSpin === false) {
        this.loadBonusTimer =  setInterval(function () {
           if(self.serviceDataModel.blshowBonusGame === true  && self.serviceDataModel.bIsBonusWin === true && self.serviceDataModel.bIsWinLineShowStoped === true){
               self.isFreeSpinBonusActive = true;
               clearInterval(self.loadBonusTimer);
               self.serviceDataModel.blshowBonusGame = false;
               self.startBonusGame(self.serviceDataModel.coinValue);
           } else if(self.serviceDataModel.bIsBonusWin === false){
               self.isFreeSpinBonusActive = false;
               clearInterval(self.loadBonusTimer);
           }
        },1000);
    }
}

//update the bonus round played information.
SpinService.prototype.bonusRoundPlayed = function() {
   var self = this;
   var spinToken = $("#spinToken").val();
   var bonusSpinSource = $('#spinSource').val();
   var gameType = $("#gameType").val();
   this.serviceDataModel.hasErrorInBonusUpadte = false;
   this.serviceDataModel.bonusWinAmount = 0.00;
   if (gameType !=="" && gameType !== "undefined" && gameType !== undefined){
       gameType = gameType.trim();
   }else{
       return ;
   }
   var winSelf = window;
   $.ajax({
       async : true,
       cache: false,
       url: "updateBonusWin?spinToken="+spinToken+"&spinSource="+bonusSpinSource+"&gameType="+gameType,
       type: "POST",
       datatype: "json",
       
       success: function (response) {
               if(response.spinToken){
                   $('#spinToken').val(response.spinToken);
                }
                
               if(response.responseStr){
                    self.serviceDataModel.bIsBonusUpdated = true;
                    var  respStr = response.responseStr.split(";");
                    for(var i =0;i<respStr.length;i++ ) {
                    var  bonusStr = respStr[i].split(":");
                    switch(bonusStr[0]) {
                      case "playerCreditAmount":
                          $('#credit-text').val("$"+bonusStr[1]);
                          break;
                      case "bonusWinAmount":
                          self.serviceDataModel.bonusWinAmount = parseFloat(bonusStr[1]);
                          var winAmount =    $('#win-text').val();
                          if(winAmount.indexOf("$") > -1) {
                              winAmount = winAmount.substring(1,winAmount.length);
                          }
                          var totalWinAmount = parseFloat(bonusStr[1]) + parseFloat(winAmount);
                          $('#win-text').val("$"+(totalWinAmount).toFixed(2));
                          
                          break;
                      default:  break; 
                          }
                      }
                 //display the message if error occure in response. 
                 }else if(response.hasError){
                     self.serviceDataModel.bIsBonusUpdated = false;
                     var json = JSON.parse(JSON.stringify(response));
                     self.serviceDataModel.blBonusGameClosed = false;
                     self.serviceDataModel.hasErrorInBonusUpadte = true;
                     self.serviceDataModel.bonusWinAmount =0.00;
                     if((json.ErrorCode !== undefined || json.ErrorCode !=='undefined') && json.ErrorCode === 10){
                         self.errorMessageObj.formatErrorMessage(json.ErrorCode);
                         self.serviceDataModel.blBonusGameClosed = true;
                         self.serviceDataModel.bIsBonusUpdated = true;
                         self.removeAutoSpinInterval();
                     } else {
                         self.showBonusAmountWinPopup($.i18n.prop("error.noActive_Bonus_Game_76"));
                     }
                 }else {
                     self.serviceDataModel.bIsBonusUpdated = true;
                     self.serviceDataModel.blBonusGameClosed = false;
                     self.serviceDataModel.hasErrorInBonusUpadte = true;
                     self.serviceDataModel.bonusWinAmount =0.00;
                     self.removeAutoSpinInterval();
                     winSelf.open('','_self',''); 
                     winSelf.close();
                 }
      }, error: function (error) {
          self.serviceDataModel.bonusWinAmount =0.00;
          self.serviceDataModel.blBonusGameClosed = false;
          self.errorMessageObj.formatErrorMessage(-1);
          self.removeAutoSpinInterval();
      }
   });
};

//This method is uesd for show the bonus win amount popup
SpinService.prototype.showBonusAmountWinPopup = function(message){
   setTimeout(function(){
       $(".informationpopup").resizer(1.3);
       $(".informationpopup").fitText(3.3);
   
   });
   var self = this; 
   this.serviceDataModel.isDummyHandlerActive = true;
   var bonusPopUp = $("<div id='dummyHandler' class='progress-fix' style='background-color:rgba(0,0,0, 0.8); width:100%; height:100%; position:fixed; top:0; left:0; '><div class='informationpopup'> <div class='error-pop bonuspopup' ><p></p><div class='popupfotter'><button type='button' class='ok_button'></button>  </div></ </div></div></div>");
       $(".main").append(bonusPopUp);
       $(".error-pop p").append(message);
       if(this.serviceDataModel.isSoundPlay === true){
            this.serviceDataModel.PopupSound.stop().play();
        }
       $('.ok_button').click(function () {
           $("#dummyHandler").remove(); 
           if(self.serviceDataModel.isSoundPlay === true){ 
        	   self.serviceDataModel.ButtonClick.stop().play();
           }
           
           self.serviceDataModel.isDummyHandlerActive = false;             
           setTimeout(function(){ 
               $('.bonus-canvas-back').hide();
               if($('.bonus-canvas-container')){
                   $('.bonus-canvas-container').hide();
                   $('.transGamebg').hide();
                   $(".bonus-innerframe").hide();
               }
               
               self.serviceDataModel.blBonusGameClosed = true;
               self.serviceDataModel.bIsBonusUpdated = true;
               self.serviceDataModel.isBonusScreenActive = false;
               self.serviceDataModel.bonusGameVisible = false;
               
               if(self.serviceDataModel.autoSpinCount >0 ){
                   self.serviceDataModel.isAutoSpin = true;
                   self.autoSpinPerform(0);
               } else if(self.serviceDataModel.numFreeSpinsWin ==0 && self.serviceDataModel.autoSpinCount ==0) {
                   self.btnEventObj.enableSpinBtn();
               }
               
               self.isFreeSpinBonusActive = false;
           }, 200); 
       });
};


//This method is used for attach the available free spin popup. 
SpinService.prototype.addFreeSpinWinPopup = function(freeSpinCount,message,bIsShowPopUp) {
    var self = this;
    this.msg=message;
    //if(this.serviceDataModel.isAutoSpin === false){
        if(this.serviceDataModel.numFreeSpinsWin >0){
           bIsShowPopUp =true;
           this.msg = $.i18n.prop("msg.freeSpin.win",this.serviceDataModel.numFreeSpinsWin);
           
        }
        
        if(this.freeSpinWinTimer !== null){
            clearInterval(this.freeSpinWinTimer);
        }
        if(this.serviceDataModel.avaliableFreeSpins >0){
            this.freeSpinWinTimer = setInterval(function () {
               if(freeSpinCount >0 && ! $("#dummyHandler").is("html *") && self.serviceDataModel.bonusGameVisible === false && self.serviceDataModel.bIsBonusWin === false ) {
                   clearInterval(self.freeSpinWinTimer);
                   self.showFreeSpinPopupWin(freeSpinCount,self.msg,bIsShowPopUp);
               }
            },200);
        }
    //}
};

/*
 * This method execute to show the free spin win popup.
 */
SpinService.prototype.showFreeSpinPopupWin = function(freeSpinCount,message,bIsShowPopUp){
    var self = this;
    if(bIsShowPopUp && ! this.isDummyHandlerAdded){
        setTimeout(function(){
            $(".informationpopup").resizer(1.3);
            $(".informationpopup").fitText(3.3);
        });
        
        if(this.serviceDataModel.isSoundPlay === true){
           this.serviceDataModel.FreeSpinPopup.stop().play();
        }
        
        $("#dummyHandler").remove();
        this.isDummyHandlerAdded = true;
        this.serviceDataModel.isDummyHandlerActive = true;
        var freeSpinPopUp = $("<div id='dummyHandler' class='progress-fix' style='background-color:rgba(0,0,0, 0.8); width:100%; height:100%; position:fixed; top:0; left:0;'><div class='informationpopup'> <div class='error-pop freespinpopup' ><p></p><div class='popupfotter'><button type='button' class='freespin_gamebtn'></button>  </div></ </div></div></div>");
            $(".main").append(freeSpinPopUp);
            $(".error-pop p").append(message);
            $('.freespin_gamebtn').click(function () {
               $("#dummyHandler").remove();
               self.isDummyHandlerAdded = false;
               self.serviceDataModel.isDummyHandlerActive = false;
		        if(self.serviceDataModel.isSoundPlay === true){
		        	self.serviceDataModel.ButtonClick.stop().play();
		        }
               clearInterval(self.freeSpinWinTimer);
               self.serviceDataModel.isAutoSpin = false;
               if(self.serviceDataModel.avaliableFreeSpins >0){
                   self.btnEventObj.unAssignAutoSpinContainer();
                   self.btnEventObj.assignAutoFreeSpin();
                   self.btnEventObj.unAssignSpinBtnEvents();
                   self.availableFreeSpin();
               }else{
                   self.serviceDataModel.isAutoSpin = true;
                   self.btnEventObj.unAssignAutoFreeSpin();
                   self.autoSpinPerform(0);
               }
         });
    }else if(! this.isDummyHandlerAdded){
       $("#dummyHandler").remove();
       self.serviceDataModel.isDummyHandlerActive = false;
       self.serviceDataModel.isAutoSpin = false;
       self.btnEventObj.assignAutoFreeSpin();
       self.btnEventObj.unAssignSpinBtnEvents();
       self.availableFreeSpin();
       self.autoSpinPerform(0);
    }
};

/*
 * This method start the auto free spin
 */ 
SpinService.prototype.autoStartFreeSpin = function(freeSpinCount) {
    var self = this;
    if(this.autoSpinObj !=null){
        clearInterval(this.autoSpinObj);
    }
    
    this.autoSpinObj = setInterval(function(){
         if(self.serviceDataModel.bIsWinLineShowStoped === true && freeSpinCount >0  && self.isFreeSpinBonusActive === false 
        		 && self.serviceDataModel.bonusGameVisible === false && self.serviceDataModel.bIsBonusWin === false){
            clearInterval(self.autoSpinObj);
            self.spinObj.freeSpinBtnHandler();
         }
     },3000)
};

/*
 * This method is used for display the total amount won in auto free spin
 */ 
SpinService.prototype.freeSpinTotalWinPopup = function(message, totalAmt){
    var self = this;
    setTimeout(function(){
        $(".informationpopup").resizer(1.3);
        $(".informationpopup").fitText(3.3);
    });
    
    this.serviceDataModel.isAutoSpin=false;
    $("#dummyHandler").remove();
    this.serviceDataModel.isDummyHandlerActive = true;
    
    var freeSpinPopUp = $("<div id='dummyHandler' class='progress-fix' style='background-color:rgba(0,0,0, 0.8); width:100%; height:100%; position:fixed; top:0; left:0;'><div class='informationpopup'> <div class='error-pop freespinpopup' ><p></p><div class='popupfotter'><button type='button' class='ok_button'></button>  </div></ </div></div></div>");
        $(".main").append(freeSpinPopUp);
        $(".error-pop p").append(message);
        $('.ok_button').click(function () {
            self.serviceDataModel.isAutoSpin=true;
            self.serviceDataModel.isDummyHandlerActive = false;   
            if(self.serviceDataModel.isSoundPlay === true){ 
            	self.serviceDataModel.ButtonClick.stop().play();
            }           
            if(self.serviceDataModel.isBonusScreenActive === false){
                self.getPendingBonus();
                self.checkOtherPendingGame();
            }
            self.btnEventObj.unAssignAutoFreeSpin();
            self.autoSpinPerform(totalAmt);
            self.serviceDataModel.bIsAutoFreeSpin = false;
            $("#dummyHandler").remove();
     });
};

/*
 * This method Check if any other available free spin is pending ,if yes then run it .
 */
SpinService.prototype.hasAvaliableFreeSpins =function(){
     var self = this;
     if(this.serviceDataModel.avaliableFreeSpins >0){
         this.stopHeartBeat();
         this.btnEventObj.unAssignSpinBtnEvents();
         if(this.serviceDataModel.bIsAutoFreeSpin ===false){
             $("#total-win").val("$0.00");
         }
         
         if(this.autoFreeSpinTrm !== null){
             clearInterval(this.autoFreeSpinTrm);
         }
         this.autoFreeSpinTrm = setInterval(function () {
            
            if(self.serviceDataModel.bIsWinLineShowStoped ===true ){
                clearInterval(self.autoFreeSpinTrm);
                self.addFreeSpinWinPopup(self.serviceDataModel.avaliableFreeSpins,"",false);
            }
         },500);
    } else if(this.serviceDataModel.bIsAutoFreeSpin === true){
        this.serviceDataModel.bIsAutoFreeSpin = false;
        if(this.showTotalWinAmountTimer !== null){
           clearInterval(this.showTotalWinAmountTimer);
        }
        this.showTotalWinAmountTimer = setInterval(function () {
            
            if(self.serviceDataModel.bIsWinLineShowStoped === true && self.serviceDataModel.bIsReelStoped ===true 
                    && self.serviceDataModel.bonusGameVisible === false && self.serviceDataModel.bIsBonusWin === false ) {
                clearInterval(self.showTotalWinAmountTimer);
                var previousAutoFreeAmt = $("#total-win").val();
                
                var totalAmount = (parseFloat(self.serviceDataModel.bonusWinAmount) +parseFloat(self.serviceDataModel.winningAmount) + parseFloat(previousAutoFreeAmt.substring(1, previousAutoFreeAmt.length))).toFixed(2);
                self.serviceDataModel.bonusWinAmount = 0.00;
                $("#total-win").val("$"+totalAmount);
                
                if(totalAmount >0){
                    if(self.serviceDataModel.isFreeSpinConsumed){
                        self.freeSpinTotalWinPopup($.i18n.prop("msg.freeSpin.consumed_spin",totalAmount), totalAmount);
                        if(self.serviceDataModel.isSoundPlay === true){
                            self.serviceDataModel.PopupSound.stop().play();
                        }
                    } else{
                        self.freeSpinTotalWinPopup($.i18n.prop("msg.freeSpin.totalWin",totalAmount), totalAmount);
                        if(self.serviceDataModel.isSoundPlay === true){
                            self.serviceDataModel.PopupSound.stop().play();
                        }
                    }
                } else {
                    // here we check any bonus game is available or not
                    self.btnEventObj.unAssignAutoFreeSpin();
                    self.autoSpinPerform(0);
                    self.serviceDataModel.bIsAutoFreeSpin = false;
                }
                
           }
        },500);
     }
}

/*
 * This method is used for show the number of free spin win
 */
SpinService.prototype.showFreeSpinWinPopup = function(){
    var self = this;
    if(this.serviceDataModel.numFreeSpinsWin >0){
       if(this.addFreeSpinWinTimer !== null){
          clearInterval(this.addFreeSpinWinTimer);
       }
       this.addFreeSpinWinTimer = setInterval(function () {
           
            if(self.serviceDataModel.bIsReelStoped ===true && self.serviceDataModel.bIsWinLineShowStoped === true && self.serviceDataModel.isBonusScreenActive === false ) {
                clearInterval(self.addFreeSpinWinTimer);
                self.addFreeSpinWinPopup(self.serviceDataModel.numFreeSpinsWin, $.i18n.prop("msg.freeSpin.totalWin",self.serviceDataModel.numFreeSpinsWin),true);
            }
        },500);
     }
}

/*
 * This method check available free spin and run free spin
 */
SpinService.prototype.availableFreeSpin = function(){
    var self = this;
    var spinSource = $('#spinSource').val();
    var spinToken = $('#spinToken').val();
    $.ajax({
           async : true,
           cache: false,
           url: "availableFreeSpin?spinSource=" + spinSource+"&spinToken=" + spinToken,
           datatype: "json",
           success: function (response) {
              if(response.responseStr){
                  var availableFreeSpin = 0;
                  var  respStr = response.responseStr.split(";");
                  for(var i =0;i<respStr.length;i++ ) {
                  var  resStr = respStr[i].split(":");
                    switch(resStr[0]) {
                        case "FreeSpinsActive":
                            availableFreeSpin = resStr[1];
                            self.serviceDataModel.avaliableFreeSpins = availableFreeSpin;
                        default: break; 
                     }
               }
               
               if(availableFreeSpin >0){
                   self.autoStartFreeSpin(availableFreeSpin);
               } else{
                   $("#freespin").attr("value", self.serviceDataModel.avaliableFreeSpins);
                   self.hasAvaliableFreeSpins();
                   self.btnEventObj.assignBtnEvents();
               }
             }else{
                self.errorMessageObj.formatErrorMessage(-1);
             }
           },
           error: function (error) {
               self.errorMessageObj.formatErrorMessage(-1);
          }
     });
};


SpinService.prototype.checkSelfExclusionOrImposeLimit = function(exclusionOrImposeTimer) {
    var self = this;
    var winSelf = window;
    
    var spinSource = $('#spinSource').val();
    var spinToken = $('#spinToken').val();
    var spin = $('#spin').val();
    
    this.numPayLines = $('#payline-val-txt').val();
    this.coinVal = $('#coin-val-txt').val();
    this.gameType = $("#gameType").val();
    var requestCoinValue = "";
    
    if(this.coinVal.indexOf('$') === 0) {
        this.coinVal = this.coinVal.substring(1, this.coinVal.length);
        this.coinVal =  this.coinVal * 100;
        this.requestCoinValue = this.coinVal;
    }else{
        this.coinVal = this.coinVal.trim().substring(0,this.coinVal.length-1);
        this.requestCoinValue = "c"+this.coinVal; 
        this.coinVal = this.coinVal;
    }
    $.ajax({
        async : true,
        cache : false,
        timeout: 60000,
        url : "checkSelfExclusionOrImposeLimit?spinSource=" + spinSource+ "&spinToken=" + spinToken+"&numPayLines="+self.numPayLines+"&coinSelected="+self.requestCoinValue+"&gameType="+self.gameType+"&spinType="+spin,
        contentType : this.contentType, 
        success : function(response) {
            if (response.responseStr) {
                self.checkSelfExclusionOrImposeLimitGot(response.responseStr, exclusionOrImposeTimer);
            } else if (response.hasError) {
                var json = JSON.parse(JSON.stringify(response));
                self.serviceDataModel.isExclusionOrImposePerformSpin = false;
                self.serviceDataModel.isExclusionOrImposeStopSpin = true;
                if(json.selfExcluseMsg !== undefined || json.selfExcluseMsg !=='undefined'){
                    self.serviceDataModel.selfExcluseMsg = json.selfExcluseMsg;
                }
                
                if(json.blockNote !== undefined || json.blockNote !=='undefined'){
                    self.serviceDataModel.blockNote = json.blockNote;
                }
                
                if(json.ErrorCode !== undefined || json.ErrorCode !=='undefined'){
                    self.errorMessageObj.formatErrorMessage(json.ErrorCode);
                }else{
                    self.errorMessageObj.formatErrorMessage(45);
                }
                self.serviceDataModel.isHeartBeat_ON = false;
                self.stopHeartBeat();
            } else {
                self.serviceDataModel.isExclusionOrImposePerformSpin = false;
                self.serviceDataModel.isExclusionOrImposeStopSpin = true;
                self.errorMessageObj.formatErrorMessage(-1);
            }
        },
        // When json call fails
        error : function() {
            self.serviceDataModel.isExclusionOrImposePerformSpin = false;
            self.serviceDataModel.isExclusionOrImposeStopSpin = true;
            self.errorMessageObj.formatErrorMessage(-1);
        }
    });
};

SpinService.prototype.checkSelfExclusionOrImposeLimitGot = function (msg, exclusionOrImposeTimer) {
    var self = this;
    var response = msg.split(";");
    var stringCount = 0, titleStr;
    this.serviceDataModel.isImposeLimitApplied = false;
    this.serviceDataModel.isSystemLimitApplied = false;
    this.serviceDataModel.selfExcluseMsg = '';
    this.serviceDataModel.blockNote = null;
    
    for (stringCount; stringCount < response.length; stringCount++) {
        titleStr = response[stringCount].split(":");
        switch (titleStr[0]) {
            case "isAccountBlk":
                if(titleStr[1] !== null && titleStr[1] === "true"){
                    self.serviceDataModel.isAccountBlock = true;
                } 
                break;
            case "blockNote":
                if(titleStr[1] !== null && titleStr[1] !== "") {
                    self.serviceDataModel.hasBlockNote = true;
                    self.serviceDataModel.blockNote = titleStr[1];
                } 
                break;
            case "isLimitApplied":
                if(titleStr[1] !== null && titleStr[1] === "true") {
                    self.serviceDataModel.isImposeLimitApplied = true;
                } 
                break;
            case "selfExcluseMsg":
                if(titleStr[1] !== null && titleStr[1] !== "") {
                    self.serviceDataModel.selfExcluseMsg = titleStr[1];
                } 
                break; 
               //system limit information
            case "isSystemLimitApplied":
                if(titleStr[1] !== null && titleStr[1] === "true") {
                    this.serviceDataModel.isSystemLimitApplied = true;
                } 
                break;
                
            default:
                break;
          }
      }
    
    if(this.serviceDataModel.bIsAutoFreeSpin !== null && this.serviceDataModel.bIsAutoFreeSpin === false && this.serviceDataModel.hasBlockNote === true){
            this.selfExclusionOrImposeLimitMessage(this.serviceDataModel.blockNote);
    } else {
        this.serviceDataModel.isExclusionOrImposePerformSpin = false;
        this.serviceDataModel.isExclusionOrImposeStopSpin = true;
    }
    
    if(this.serviceDataModel.hasBlockNote === false){
            this.serviceDataModel.isExclusionOrImposePerformSpin = true;
    }
 };
 
 SpinService.prototype.selfExclusionOrImposeLimitMessage = function (message) { 
     var self = window;
     var thisSelf = this;
     
     setTimeout(function(){
        $(".informationpopup").resizer(1.3);
        $(".informationpopup").fitText(3.3);
     });
     
     this.errorPopUp = $("<div id='dummyHandler' class='progress-fix' style='background-color:rgba(0,0,0, 0.8); width:100%; height:100%; position:fixed; top:0; left:0; '><div class='informationpopup'> <div class='error-pop' ><p></p><div class='popupfotter'><button type='button' class='ok_error_button'></button>  </div></ </div></div></div>");
     this.serviceDataModel.isDummyHandlerActive = true;

     
     $(".main").append(this.errorPopUp);
     $(".error-pop p").append(message);
     $('.ok_error_button').click(function () {
         if((thisSelf.serviceDataModel.isSystemLimitApplied === true || thisSelf.serviceDataModel.isImposeLimitApplied === true) && thisSelf.serviceDataModel.blockNote !== ''){
             thisSelf.serviceDataModel.isExclusionOrImposePerformSpin = false;
             thisSelf.serviceDataModel.isExclusionOrImposeStopSpin = true;
		        if(thisSelf.serviceDataModel.isSoundPlay === true){
		        	thisSelf.serviceDataModel.ButtonClick.stop().play();
		        }
         } else {
             thisSelf.serviceDataModel.isExclusionOrImposePerformSpin = true;
         }
         thisSelf.serviceDataModel.isDummyHandlerActive = false;
        $("#dummyHandler").remove();
     });
};


/**
 * This method is used for run the auto spin
 */
SpinService.prototype.autoSpinPerform = function(freeSpinTotalWinAmt) {
    var self = this;
    //remove the auto spin interval if already active
    if (this.autoSpinInterval != null) {
        clearInterval(this.autoSpinInterval);
    }
    
    if(this.serviceDataModel.numFreeSpinsWin === 0){
        this.btnEventObj.unAssignAutoFreeSpin();
       }

    if(this.serviceDataModel.autoSpinCount > 0 && this.serviceDataModel.avaliableFreeSpins == 0 
            && this.serviceDataModel.bIsBonusWin === false && this.serviceDataModel.bonusGameVisible === false){
        
        this.serviceDataModel.isAutoSpin = true;
        this.btnEventObj.assignAutoSpinContainer();
        this.serviceDataModel.bIsWinLineShowStoped = true;
        this.stopHeartBeat();
        
        $("#autospin").attr("value", this.serviceDataModel.autoSpinCount);
        var totalAmount = (parseFloat(this.serviceDataModel.autoSpinTotalWinAmt) + parseFloat(freeSpinTotalWinAmt)).toFixed(2);
        $("#autospin_totalwin").val("$"+totalAmount);
        this.serviceDataModel.autoSpinTotalWinAmt = totalAmount;
        
        $('#autospin-payline').val(this.serviceDataModel.autoSpinPayLine);
        $('#autospin-coinvalue').val(this.serviceDataModel.autoSpinCoinValue);
        this.autoSpinInterval = setInterval(function() {
            
            if(self.serviceDataModel.isDummyHandlerActive === true || (self.serviceDataModel.bIsBonusWin === true || self.hasPendingBonusGame === true || self.serviceDataModel.bonusGameVisible===true)
                    && self.serviceDataModel.bIsWinLineShowStoped == true && self.serviceDataModel.avaliableFreeSpins == 0){
                self.serviceDataModel.isAutoSpin = false;
            }
            
            // perform the auto spin
            if (self.serviceDataModel.bIsWinLineShowStoped == true
                    && self.serviceDataModel.autoSpinCount > 0 && self.serviceDataModel.avaliableFreeSpins == 0 
                    && self.serviceDataModel.bIsBonusWin === false && self.serviceDataModel.bonusGameVisible === false
                    && self.serviceDataModel.isDummyHandlerActive ===false) {
                self.btnEventObj.assignAutoSpinContainer();
                self.spinObj.spinBtnHandler("autoSpin");
            }
            
            // stop the auto spin and show the win amount
            if(self.serviceDataModel.autoSpinCount === 0 && self.serviceDataModel.bIsReelStoped === true 
                    && self.serviceDataModel.bIsBonusWin === false && self.serviceDataModel.bonusGameVisible === false) {
            	clearInterval(self.autoSpinInterval);
                var previousAutoAmt = $("#autospin_totalwin").val();
                var totalAmount = (parseFloat(previousAutoAmt.substring(1, previousAutoAmt.length))).toFixed(2);
                
                if(totalAmount>0){
                    self.showAutoSpinTotalWinAmtPopup($.i18n.prop("msg.autoSpin.totalWin",totalAmount));
                } else{
                    self.checkPendingFreeSpin();
                }
                
                self.removeAutoSpinInterval();
                self.btnEventObj.unAssignAutoSpinContainer();
                self.startHeartBeat();
            }
            
        }, 3500);
    }
};

// remove the auto spin handler
SpinService.prototype.removeAutoSpinInterval = function(){
    if (this.autoSpinInterval != null) {
        clearInterval(this.autoSpinInterval);
    }
    this.btnEventObj.unAssignAutoSpinContainer();
    this.serviceDataModel.isAutoSpin = false;
    this.btnEventObj.assignBtnEvents();
}


/*
 * This method is used for display the total amount won in auto free spin
 */ 
SpinService.prototype.showAutoSpinTotalWinAmtPopup = function(message){
    var self = this;
    setTimeout(function(){
        $(".informationpopup").resizer(1.3);
        $(".informationpopup").fitText(3.3);
    });
    
    this.serviceDataModel.isAutoSpin=false;
    $("#dummyHandler").remove();
    this.serviceDataModel.isDummyHandlerActive = true;
    var autoSpinPopUp = $("<div id='dummyHandler' class='progress-fix' style='background-color:rgba(0,0,0, 0.8); width:100%; height:100%; position:fixed; top:0; left:0;'><div class='informationpopup'> <div class='error-pop freespinpopup' ><p></p><div class='popupfotter'><button type='button' class='ok_button'></button>  </div></ </div></div></div>");
        $(".main").append(autoSpinPopUp);
        $(".error-pop p").append(message);
        if(this.serviceDataModel.isSoundPlay === true){
            this.serviceDataModel.PopupSound.stop().play();
        }
        
        $('.ok_button').click(function () {
            self.serviceDataModel.isDummyHandlerActive = false;
            if(self.serviceDataModel.isSoundPlay === true){ 
            	self.serviceDataModel.ButtonClick.stop().play();
            }
            self.checkPendingFreeSpin();
            $("#dummyHandler").remove();
     });
};
function GameInfo(gameInfoData) {
    this.gameInfoData = gameInfoData ;
}

GameInfo.prototype.setTableData = function (infoArray) {
    "use strict";
    
    var i, amountCount, inputValue, j, symbolAssignCnt = 0,specialSymb=[],NormalSymbolArr=[];
    for (i = 0; i < infoArray.length; i += 1) {
       
        inputValue = infoArray[i].split(",");
        if(inputValue.length<6)
        {
            inputValue.push("0");// assign 0 for none value on combination of 2
        }
        
        if (inputValue[1] != "N") {
            if (inputValue[1] == "S") {
                specialSymb.push(inputValue);
           }
            if (inputValue[1] == "W") {
                   specialSymb.push(inputValue);

            }
        }
        else {
            NormalSymbolArr.push(inputValue);
           
        }
        for(var specialCount=0; specialCount<specialSymb.length;specialCount +=1 ) {
            if(specialSymb[specialCount][1]=="S") {
                this.infoInput = $("#info_6 input");
                this.infoImage = $("#info_6 img");
                this.infoImage.attr("src", this.gameInfoData.imageSrc + specialSymb[specialCount][0]);
                amountCount = 2;//input data position in infoArray
                for (j = 0; j < this.infoInput.length; j += 1) {
                this.infoInput[j].value = specialSymb[specialCount][amountCount]+" Free Spin";
                amountCount += 1;
            }
            }else {
                this.infoInput = $("#info_5 input");
                this.infoImage = $("#info_5 img");
                this.infoImage.attr("src", this.gameInfoData.imageSrc + specialSymb[specialCount][0]);
                amountCount = 2;
                for (j = 0; j < this.infoInput.length; j += 1) {
                this.infoInput[j].value = specialSymb[specialCount][amountCount];
                amountCount += 1;
                 }
            }
        }
         for(var normCount = 0; normCount<NormalSymbolArr.length;normCount +=1 ) {
             if(normCount<4) {
             this.infoInput = $("#info_"+(normCount+1)+" "+"input");
             this.infoImage = $("#info_"+(normCount+1)+" "+"img");
             this.infoImage.attr("src", this.gameInfoData.imageSrc + NormalSymbolArr[normCount][0]);
             amountCount = 2;
             var payDataLength = NormalSymbolArr[normCount].length - 2;
             console.log("Data Length",payDataLength,this.infoInput.length);
             
             for (j = 0; j < this.infoInput.length; j += 1) {
                this.infoInput[j].value = NormalSymbolArr[normCount][amountCount];
                amountCount += 1;
       }
          }
          else{
           this.infoInput = $("#info_"+(normCount+3)+" "+"input");
             this.infoImage = $("#info_"+(normCount+3)+" "+"img");
              this.infoImage.attr("src", this.gameInfoData.imageSrc + NormalSymbolArr[normCount][0]);
                amountCount = 2;
                for (j = 0; j < this.infoInput.length; j += 1) {
                this.infoInput[j].value = NormalSymbolArr[normCount][amountCount];
                 
                amountCount += 1;
            }
          }
       }
    }
};

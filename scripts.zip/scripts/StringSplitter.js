//This file used for define the method which is update the data screen data from server side vice versa.
function StringSplitter(splitDataModel,errorMessage)
{
  this.dataFound = false;
  this.splitDataModel = splitDataModel ;
  this.errorMessageObj = errorMessage;
  this.coinSelected = 0; 
  this.bonusGame = false;
  this.sessionTimer = null;
  this.jackPotPopupTimer = null;
  this.jackpotPopupShowTimer = null;
}
/*
 * This function calls at the time when the game load and split the response data string.
 */

StringSplitter.prototype.initialDisplayData = function (){
       var self = this;
       var  response, balanceData,allsymbols,initialSymbols,initialData,winningData,jackpotData;
       //String received 
       msg = this.splitDataModel.responseStr;
       response= msg.split(";");
       this.dataFound=true;
       this.splitDataModel.isImposeLimitApplied = false;
       this.splitDataModel.isImposeLimitApplied = false;
       this.splitDataModel.selfExcluseMsg = '';
       this.splitDataModel.blockNote = ''
       var stringCount = 0,innerStr ;
       for(stringCount; stringCount<response.length;stringCount++)
       {
       innerStr = response[stringCount].split(":");
       switch(innerStr[0]){
        case "AllImage":
            this.splitDataModel.imageArray  = innerStr[1].split(',');
         break;
         case "ReelSymbols":
            this.splitDataModel.reelSymbols = innerStr[1].split(',');
            break;
         case "ImageSrc":  
             this.splitDataModel.imageSrc =  innerStr[1];
             break;
         case "AnimSrc":  
             this.splitDataModel.animSrc =  innerStr[1];
             break;
         case "MaxPayLine":  
             this.splitDataModel.totalPaylines =  innerStr[1];
             break;
         case "CoinDenomination":  
             this.splitDataModel.coinvalArray =  innerStr[1].split(',');
             break;
         case "BalanceCreditAmount":
             this.splitDataModel.creditPoint = innerStr[1];
             break;
          case "Winnings":
             this.splitDataModel.winningAmount = innerStr[1];
             break;
          case "ProgressiveJackpot":
             this.splitDataModel.jackPotAmount =  innerStr[1];
             break;
         case "FreeSpinsActive": 
             this.splitDataModel.avaliableFreeSpins =  innerStr[1];
            break;
         case "JackPotPercentageVariation":  
             this.splitDataModel.jackpotPercentageArray = innerStr[1].split(',');
             break;
         case "PayTableResponse":  
             this.splitDataModel.payTableResponse = innerStr[1];
             break;
         case "InitialPayLines":  
             $('#payline-val-txt').val(innerStr[1]);
             break;
         case "SoundFilePath":
             this.splitDataModel.soundSrc = innerStr[1];
             break;
         case "availableFreeSpinList":
             if(innerStr[1] != null) {
                 this.splitDataModel.availableFreeSpinList = innerStr[1].split("~");
             }
             break;
         case "HeartBeat":
             this.splitDataModel.heartBeatDelayTime =  innerStr[1];
             break;
         case "isLimitApplied":
             if(innerStr[1] !== null && innerStr[1] === "true"){
                 this.splitDataModel.isImposeLimitApplied = true;
             } 
             break;
         case "isAccountBlk":
             if(innerStr[1] !== null && innerStr[1] === "true"){
                 this.splitDataModel.isAccountBlock = true;
             } 
             break;
         case "selfExcluseMsg":
             if(innerStr[1] !== null && innerStr[1] !== ""){
                 this.splitDataModel.selfExcluseMsg = innerStr[1];
             } 
             break;
         case "blockNote":
               if(innerStr[1] !== null && innerStr[1] !== "") {
                   this.splitDataModel.blockNote = innerStr[1];
               } 
               break;
        
           case "isSystemLimitApplied":
               if(innerStr[1] !== null && innerStr[1] === "true") {
                   this.splitDataModel.isSystemLimitApplied = true;
               } 
               break;
              
         default:
            break; 
            }
       }
       this.uploadGameSounds();
       this.initialAfterStopLoader();
 };
 
 /*
  * This function calls on every spin and split response data and store in variable.
  */

 StringSplitter.prototype.paySymbolGot = function()
 {
    var response;
    var self = this;
    response = self.splitDataModel.responseStr.trim().split(";");
    self.splitDataModel.bIsBonusWin = false;
    this.splitDataModel.isImposeLimitApplied = false;
    this.splitDataModel.isImposeLimitApplied = false;
    this.splitDataModel.selfExcluseMsg = '';
    this.splitDataModel.blockNote = ''
    var stringCount = 0,titleStr ;
    
    if(this.updateAutoSpinScrTimer !== null){
        clearInterval(this.updateAutoSpinScrTimer);
    }
       for(stringCount; stringCount<response.length;stringCount++)
       {
        titleStr = response[stringCount].split(":"); 
        
        switch(titleStr[0]) {
        case "ReelSymbols":
            this.splitDataModel.reelSymbols = titleStr[1].split(',');
         break;
         case "BalanceCreditAmount":
             this.splitDataModel.creditPoint = titleStr[1];
         break;
          case "Winnings":
             this.splitDataModel.winningAmount = titleStr[1];
         break;
          case "ProgressiveJackpot":
             this.splitDataModel.jackPotAmount =  titleStr[1];
         break;
         case "HighlightSymbols":
             this.splitDataModel.highLightSymbArr = [] ;
             this.splitDataModel.highLightSymbArr =  titleStr[1].split("-");
         break;
         case "HighlightPayLines":
             this.splitDataModel.activePaylineArr = [] ;
             this.splitDataModel.activePaylineArr =  titleStr[1].split(",");
         break;
         case "MessageBar":
             this.splitDataModel.winMessage = [];
             this.splitDataModel.winMessage =  titleStr[1].split(",");
         break;
         case "FreeSpinsActive":  
             this.splitDataModel.avaliableFreeSpins =  titleStr[1];
             /*if(this.splitDataModel.avaliableFreeSpins >0){
                this.updateAutoSpinScreen();
             }*/
             this.updateFreeSpinScreen();
             break;
         case "CoinDenomination":
             if(titleStr[1].indexOf('$') != -1){
                 $('#coin-val-txt').val(titleStr[1]) ;
                 self.coinSelected = titleStr[1].substring(1, titleStr[1].length);
                 self.coinSelected =  self.coinSelected * 100;
                 $('#freespin-coinvalue').val(titleStr[1]);
             }else {
                 $('#coin-val-txt').val(titleStr[1]+"\242");
                 $('#freespin-coinvalue').val(titleStr[1]+"\242");
                 self.coinSelected =  parseInt(titleStr[1]);
             }
             this.splitDataModel.coinValue = self.coinSelected;
             break;
         case "InitialPayLines":  
             $('#payline-val-txt').val(titleStr[1]);
             $('#freespin-payline').val(titleStr[1]);
             break;    
         case "totalBonusScores":  
             this.splitDataModel.totalBonusScores = titleStr[1].split(',');
             break;
         case "WinBonusScores":  
             this.splitDataModel.bIsBonusWin = true;
             this.splitDataModel.isAutoSpin = false;
             this.splitDataModel.winBonusScoresStr =  titleStr[1];
             break;
         case "bonusGameType":
             this.splitDataModel.bonusGameType =  titleStr[1];
             break;
         case "HeartBeat":
             this.splitDataModel.heartBeatDelayTime =  titleStr[1]; 
             break;
         case "jackPotWinAmount":
             if(titleStr[1] !== "" && titleStr[1] !== null && titleStr[1] > 0) {
                this.jackpotWinAmount = titleStr[1];
                if(this.jackPotPopupTimer !== null){
                   clearInterval(this.jackPotPopupTimer);
                }
                this.jackPotPopupTimer = setInterval(function () {
                    if(! $("#dummyHandler").is("html *") && self.splitDataModel.bIsWinLineShowStoped === true) {
                        clearInterval(self.jackPotPopupTimer);
                        self.showJackpotWinPopup(self.jackpotWinAmount);
                      }
                  },500);
               }
             break;
         case "numFreeSpinsWin":
             this.splitDataModel.numFreeSpinsWin =  titleStr[1];
             break;
         case "jackpotWinner":
            if(titleStr[1] !== null && titleStr[1] !==""){
                 this.winnerStr = titleStr[1];
                 if(this.jackpotWinnerTimer != null) {
                      clearInterval(this.jackpotWinnerTimer); 
                 }
                 this.jackpotWinnerTimer = setInterval(function(){
                    if(self.splitDataModel.bIsReelStoped === true ){
                         clearInterval(self.jackpotWinnerTimer);
                         if(self.winnerStr !== undefined || self.winnerStr !== 'undefined'){
                             self.showHideJackpotWinner(self.winnerStr);
                         }
                    }
                 },100);
             }
            break;
         case "isfreeSpinConsum":
             self.splitDataModel.isFreeSpinConsumed = titleStr[1];
             break;
         case "isLimitApplied":
             if(titleStr[1] !== null && titleStr[1] === "true"){
                 this.splitDataModel.isImposeLimitApplied = true;
             } 
             break;
         case "isAccountBlk":
             if(titleStr[1] !== null && titleStr[1] === "true"){
                 this.splitDataModel.isAccountBlock = true;
             } 
             break;
         case "selfExcluseMsg":
             if(titleStr[1] !== null && titleStr[1] !== ""){
                 this.splitDataModel.selfExcluseMsg = titleStr[1];
             } 
             break;
         case "blockNote":
            if(titleStr[1] !== null && titleStr[1] !== "") {
                this.splitDataModel.blockNote = titleStr[1];
            } 
            break;
          case "isSystemLimitApplied":
                 if(titleStr[1] !== null && titleStr[1] === "true") {
                   this.splitDataModel.isSystemLimitApplied = true;
              } 
              break;

          
          default:
            break; 
        }
       
       }
       this.updateLineBetAmount();
       this.dataFound = true;
       this.startGameBGSound();
 }
 // This method is used for show the jackpot winner information
 StringSplitter.prototype.showHideJackpotWinner= function(jackpotWinnerStr) {
     var msgStr = jackpotWinnerStr.trim().split(",");
     if(msgStr.length > 0) {
         var jackWonStr = msgStr[msgStr.length-1].split("_");
         if(jackWonStr.length >0){
             this.JackpotWinUsers(jackWonStr[0],("$"+parseFloat(jackWonStr[1]).toFixed(2)));
         }
         
         if(this.jackpotWinner != null) {
             clearInterval(this.jackpotWinner); 
         }
         this.jackpotWinner = setInterval(function(){
             $("#jackpotheader").remove();
             clearInterval(self.jackpotWinner);
        },20*1000);
     }
 }
 
 // load the content after remove the loader
 StringSplitter.prototype.initialAfterStopLoader= function(){
        var self = this;
        var initTimerObj = setInterval(function(){
             if(! $("#preloaderHandler").is("html *")){
                 if(self.splitDataModel.isSoundPlay === true){
                     self.splitDataModel.GAME_BG_SOUND.play();
                 }
                 clearInterval(initTimerObj);
                 self.splitDataModel.bIsContentLoaded = true;
             }
        },50);
        
    };
 
 // this method is used for get the paytable information from server .
 StringSplitter.prototype.responsePayTableData = function() {
     var response = this.splitDataModel.payTableResponse.split("~");
     
     var stringCount = 0,titleStr ;
     for(stringCount; stringCount<response.length;stringCount++)
     {
         titleStr = response[stringCount].split(","); 
         this.addPayTableData(titleStr);
     }
 }
 //This method is add the server paytable data in view
 StringSplitter.prototype.addPayTableData = function(titleStr)
 {
     var id = titleStr[0];
     var gameType = $("#gameType").val();
     
     if (gameType !== "undefined" && gameType !== undefined){
         gameType = gameType.trim();
     }
     if(this.splitDataModel.isSoundPlay === true){ 
         this.splitDataModel.ButtonClick.stop().play();
     }
     var myDiv;
     try {
     var htmlStr ="";
     myDiv = $("#symbol-"+id);
     myDiv.html(htmlStr);
       for(var i = 1; i < titleStr.length; i++){
           if(id=='T' && titleStr[i]!=0){
               htmlStr += '<label>'+ (i+1) +' X </label> <span>'+titleStr[i]+' COINS P/LINE</span> <div class="clear"></div>';
           }else if((gameType === 'Free Spin'|| gameType === 'Freespin and Bonus') && id=='S' && titleStr[i]!=0) {
               htmlStr += '<label>'+ (i+1) +' X </label> <span>'+titleStr[i]+' Free Spins</span> <div class="clear"></div>';
           }else if(titleStr[i]!=0){
               htmlStr += '<label>'+ (i+1) +' X</label> <input type="text" value='+titleStr[i]+' readonly="readonly"><div class="clear"></div>';
          }
          myDiv.html(htmlStr);
       }
     } catch (e) {
        console.log("Paytable error:: " + e.message);
    }
 };

 /**
  * This method is invoked at the time of spin in the game.
  */
 StringSplitter.prototype.spinResult = function()
 { 
     this.dataFound = false;
     var self = this;
     var requestCoinValue = "";
     var numPayLines = $('#payline-val-txt').val();
     self.coinSelected = $('#coin-val-txt').val();
     $("#jackpotheader").remove();
     
     if(this.jackPotPopupTimer !== null){
         clearInterval(this.jackPotPopupTimer);
     }
     
     if(this.jackpotPopupShowTimer !== null){
         clearInterval(this.jackpotPopupShowTimer);
     }
     
     if(self.coinSelected.indexOf('$') === 0) {
         self.coinSelected = self.coinSelected.substring(1, self.coinSelected.length);
         self.coinSelected =  self.coinSelected * 100;
         this.requestCoinValue = self.coinSelected;
     }else{
         self.coinSelected = self.coinSelected.trim().substring(0,self.coinSelected.length-1);
         this.requestCoinValue = "c"+self.coinSelected; 
         self.coinSelected = self.coinSelected;
     }
     this.splitDataModel.coinValue = self.coinSelected;
     this.splitDataModel.bIsReelStoped = false;
     this.splitDataModel.bIsBonusUpdated =false;
     this.splitDataModel.isFreeSpinConsumed = false;
     this.splitDataModel.isSystemLimitApplied = false;
     this.splitDataModel.isImposeLimitApplied = false;
     
     var spin = $('#spin').val();
     var spinSource = $("#spinSource").val();
     var spinToken = $("#spinToken").val();
     var betType = $("#betType").val();
     var gameURL = '';
     var gameType = $("#gameType").val();
     
     if (gameType !=="" && gameType !== "undefined" && gameType !== undefined){
         gameType = gameType.trim();
     }else{
         return ;
     }
     
     // Temp code for cudtom screen
     var reel1 = $("#reelScreenID1").val();
     var reel2 = $("#reelScreenID2").val();
     var reel3 = $("#reelScreenID3").val();
     var reel4 = $("#reelScreenID4").val();
     var reel5 = $("#reelScreenID5").val();
     
     $.ajax({
          async : true,
          cache: false,
          url: "gameResult.action?numPayLines="+numPayLines+"&coinSelected="+self.requestCoinValue+"&spinType="+spin+"&spinSource="+spinSource+"&spinToken="+spinToken+"&gameType="+gameType+"&reel1="+reel1+"&reel2="+reel2+"&reel3="+reel3+"&reel4="+reel4+"&reel5="+reel5+"&betType="+betType,
          type: "POST",
          datatype: "json",
        
          success: function (response) {

            if(response.responseStr){
                  self.splitDataModel.responseStr = response.responseStr;
                  if(response.spinToken){
                    $('#spinToken').val(response.spinToken);
                }
                  self.paySymbolGot();
            }
            //display the message if occure in response. 
            else if (response.hasError) {
                var json = JSON.parse(JSON.stringify(response));
                if(json.ErrorCode === undefined || json.ErrorCode ==='undefined'){
                    self.errorMessageObj.formatErrorMessage(json.insufficientBalance);
                } else if(json.isAccountBlk !== undefined && json.isAccountBlk !== null && (json.isAccountBlk === true || json.isAccountBlk === "true" )){
                    self.splitDataModel.isAccountBlock = true;
                    self.splitDataModel.selfExcluseMsg = json.selfExcluseMsg;
                    self.errorMessageObj.formatErrorMessage(json.ErrorCode);
                } else if((json.isLimitApplied !== undefined && json.isLimitApplied !== null && (json.isLimitApplied === true || json.isLimitApplied === "true" ) )
                        || (json.isSystemLimitApplied !== undefined && json.isSystemLimitApplied !== null && (json.isSystemLimitApplied === true || json.isSystemLimitApplied === "true"))  ){
                    
                    if(json.isSystemLimitApplied === true || json.isSystemLimitApplied === "true") {
                        self.splitDataModel.isSystemLimitApplied = true;
                    }
                    
                    if(json.isLimitApplied === true || json.isLimitApplied === "true") {
                        self.splitDataModel.isImposeLimitApplied = true;
                    }
                    
                    self.splitDataModel.blockNote = json.blockNote;
                      self.errorMessageObj.formatErrorMessage(json.ErrorCode);
                      
                } else {
                    self.errorMessageObj.formatErrorMessage(json.ErrorCode);
                }
            } else {
                self.errorMessageObj.formatErrorMessage(-1);
              }
            },
            error : function(error) {
                self.errorMessageObj.formatErrorMessage(-1);
            }
        });
 };
 
//this method is used for display the jackpot win amount popup.
 StringSplitter.prototype.showJackpotWinPopup = function(jackpotWinAmount){
     var self = this;
     this.jackWinAmount = jackpotWinAmount;
     if(this.jackpotPopupShowTimer!==null){
         clearInterval(this.jackpotPopupShowTimer);
     }
     this.jackpotPopupShowTimer = setInterval(function () {
         clearInterval(self.jackpotPopupShowTimer);
         self.addJackpotWinPopup($.i18n.prop("jackpot.win", parseFloat(self.jackWinAmount).toFixed(2)),$.i18n.prop("game.button.OK"));
     },100);

 }
 

 StringSplitter.prototype.addJackpotWinPopup = function(message, buttonTxt){
    var self = this;
    setTimeout(function(){
        $(".informationpopup").resizer(1.3);
        $(".informationpopup").fitText(3.3);
    });
    
    if(this.splitDataModel.isSoundPlay === true){
      this.splitDataModel.JackPotWin.stop().play();
    }
    var jackPotWinPopup = $("<div id='dummyHandler' class='progress-fix' style='background-color:rgba(0,0,0, 0.8); width:100%; height:100%; position:fixed; top:0; left:0; '><div class='informationpopup'> <div class='error-pop jackpotpopup' ><p></p><div class='popupfotter'><button type='button' class='ok_button'></button>  </div></ </div></div></div>");
        $(".main").append(jackPotWinPopup);
        $(".error-pop p").append(message);
        $('.ok_button').click(function () {
        $("#dummyHandler").remove();
        });
     };
 //This method is uesd oe start the sound
 StringSplitter.prototype.startGameBGSound = function() {
    var self = this;
    if(this.bgSoundObj !== null){
        clearInterval(this.bgSoundObj);
    }
    this.bgSoundObj = setInterval(function() {
         if(self.splitDataModel.isSoundPlay === true){
             self.splitDataModel.GAME_BG_SOUND.stop().play();
         }
    }, this.splitDataModel.bgSoundDelayTime*1000);
};

 //this method is uesd of get the latest spin history
 StringSplitter.prototype.spinHistoryload = function () {
     $('.loaderContainer').css('display','block');
     $('.auto-spin-control').removeClass('autospin-animate');
     $('.auto-spin-control input').removeAttr('checked');
     var self = this;
     if(this.splitDataModel.isSoundPlay === true){ 
         this.splitDataModel.ButtonClick.stop().play();
     }
     setTimeout(function(){self.spinHistory();},300);
 }
 
 StringSplitter.prototype.spinHistory = function () {
    // $('.loaderContainer').show();

        var self = this;
        var spinSource = $("#spinSource").val();
         var spinToken = $("#spinToken").val();
          $.ajax({
            async : false,
            cache: false,
            type: "POST",
            url: "spinHistory.action?spinSource="+spinSource+"&spinToken="+spinToken,
            contentType: this.contentType, // content type sent to server
            success: function (msg) {//On Successfull json call  
                 
                 if(msg.responseStr===null || msg.responseStr==="" || msg.listSpinDetails == null ){
                    $('.loaderContainer').css('display','none');
                 }
                 if (msg.listSpinDetails !== undefined && msg.listSpinDetails !== "undefined" && msg.listSpinDetails !== "" && msg.listSpinDetails !== null && msg.listSpinDetails.length>0) {
                     var table = document.getElementById("historyDetails");
                     table.innerHTML = "";
                     var row = table.insertRow(0);
                     var cell1 = row.insertCell(0);
                     var cell2 = row.insertCell(1);
                     var cell3 = row.insertCell(2);
                     var cell4 = row.insertCell(3);
                     var cell5 = row.insertCell(4);
                     var cell6 = row.insertCell(5);
                     var cell7 = row.insertCell(6);
                     var cell8 = row.insertCell(7);
                     var cell9 = row.insertCell(8);
                     var cell10 = row.insertCell(9);
                     var cell11 = row.insertCell(10);
                     var cell12 = row.insertCell(11);
                     cell1.innerHTML ="Date & Time";
                     cell2.innerHTML = "# of Payline";
                     cell3.innerHTML = "Coin($)";
                     cell4.innerHTML = "Spin Type";
                     cell5.innerHTML = "Description";
                     cell6.innerHTML = "Bet($)";
                     cell7.innerHTML = "Win($)";
                     cell8.innerHTML = "Result($)";
                     cell9.innerHTML = "Previous Cash Balance($)";
                     cell10.innerHTML = "Current Cash Balance($)";
                     cell11.innerHTML = "Previous BonusBucks Balance($)";
                     cell12.innerHTML = "Current BonusBucks Balance($)";
                     for(var i = 0 ; i < msg.listSpinDetails.length ; i++) {
                              var row = table.insertRow(i+1);
                             var cell1 = row.insertCell(0);
                             var cell2 = row.insertCell(1);
                             var cell3 = row.insertCell(2);
                             var cell4 = row.insertCell(3);
                             var cell5 = row.insertCell(4);
                             var cell6 = row.insertCell(5);
                             var cell7 = row.insertCell(6);
                             var cell8 = row.insertCell(7);
                             var cell9 = row.insertCell(8);
                             var cell10 = row.insertCell(9);
                             var cell11 = row.insertCell(10);
                             var cell12 = row.insertCell(11);
                             cell1.innerHTML = "Spin ID : <span>"+msg.listSpinDetails[i].transactionId+"</span><br>"+msg.listSpinDetails[i].playDate;
                             cell2.innerHTML = msg.listSpinDetails[i].numberOfPaylines;
                             cell3.innerHTML = msg.listSpinDetails[i].coinDenominations;
                             cell4.innerHTML = msg.listSpinDetails[i].spinType;
                             var description = self.imageFormatter(msg.listSpinDetails[i].reelMatrix);
                             var previousBalance =  msg.listSpinDetails[i].previousBalance;
                             var balance =  msg.listSpinDetails[i].finalBalance;
                             var prevBonusBuckbal =  msg.listSpinDetails[i].previousBonusBuckBal;
                             var finalBonusBuckbal =  msg.listSpinDetails[i].finalBonusBuckBal;
                             if(msg.listSpinDetails[i].bonuWinAmount != 0 && msg.listSpinDetails[i].bonusPlayed){
                                var bonusStr = "<br><h4><span>Bonus Win : ";
                                var multiplier2 = msg.listSpinDetails[i].bonusMultiplier2;
                                var multiplier3 = msg.listSpinDetails[i].bonusMultiplier3;
                                var count = 1;
                                bonusStr += msg.listSpinDetails[i].bonusMultiplier1+"* $"+msg.listSpinDetails[i].coinDenominations+" ("+count+" chance), ";
                                if(multiplier2 !==undefined && multiplier2 > 0) {
                                   count ++;
                                   bonusStr += multiplier2+"* $"+msg.listSpinDetails[i].coinDenominations+" ("+count+" chance), ";
                                }
                                
                                if(multiplier3 !== undefined && multiplier3 > 0){
                                    count ++;
                                    bonusStr += multiplier3+"* $"+msg.listSpinDetails[i].coinDenominations+" ("+count+" chance), ";
                                }
                                
                                bonusStr = bonusStr.substring(0,(bonusStr.length-2));
                                description += bonusStr +" = $"+parseFloat(msg.listSpinDetails[i].bonuWinAmount).toFixed(2)+"</span></h4>";
                                balance +=msg.listSpinDetails[i].bonuWinAmount;
                             }
                             cell5.innerHTML = description;
                             cell6.innerHTML = (msg.listSpinDetails[i].betAmount).toFixed(2);
                             cell7.innerHTML = (msg.listSpinDetails[i].winAmount).toFixed(2);
                             cell8.innerHTML = (msg.listSpinDetails[i].spinResult).toFixed(2);
                             cell9.innerHTML = (previousBalance).toFixed(2)
                             cell10.innerHTML = (balance).toFixed(2);
                             cell11.innerHTML = (prevBonusBuckbal).toFixed(2);
                             cell12.innerHTML = (finalBonusBuckbal).toFixed(2);
                    }
                 } else if(msg.hasError){
                     $('.loaderContainer').css('display','none');
                     var json =  JSON.parse(JSON.stringify(msg));
                     self.errorMessageObj.formatErrorMessage(json.ErrorCode);
                } else {
                    $('.loaderContainer').css('display','none');
                    var table = document.getElementById("historyDetails");
                    if(table !== undefined || table !== 'undefined'){
                        table.innerHTML = "<span style='color:#fff;'> "+ $.i18n.prop("error.game.noSpinHistory_22") +" </span>";
                    }
                 }
             },
             // When json call fails
             error: function () {
                $('.loaderContainer').css('display','none');
                self.errorMessageObj.formatErrorMessage(-1); }
              } );
         
     };
 // This method is uesd for display the image icon of spin history based of symbol.
 StringSplitter.prototype.imageFormatter = function(reel) {
        var reelImageString = "";
        try{
            var reelArr = reel.split(",");
            reelImageString = "<table class=\"spinImageResult\">" + "<tbody><tr>";
            if(reelArr!=null && reelArr.length>0){
                for(var i = 0; i<reelArr.length-1; i++){
                    imageName = reelArr[i];
                    if(i!=0 && i%5==0){
                        reelImageString = reelImageString + "</tr><tr>";
                        reelImageString = reelImageString + "<td><img src="+imageName+" style='height:30px;width:40px;'/></td>";
                    }else{
                        reelImageString = reelImageString + "<td><img src="+imageName+" style='height:30px;width:40px;'/></td>";
                    }
                }
            }    
            reelImageString = reelImageString + "</tr></tbody></table>";
            $('.loaderContainer').css('display','none');
            
        }catch(e){
            console.log(e);
        }    
        return reelImageString;
        
    }; 
    
    //This method is used of load the game sound
 StringSplitter.prototype.uploadGameSounds = function() {
     var self = this;
     this.splitDataModel.winSound = new Howl({
         urls: [this.splitDataModel.soundSrc+'Win.mp3', this.splitDataModel.soundSrc+'Win.wav']
     });
     
     this.splitDataModel.paylinesel = new Howl({
         urls: [this.splitDataModel.soundSrc+'ButtonClick.mp3', this.splitDataModel.soundSrc+'ButtonClick.wav']
     });
     /* New sounds*/
     
     this.splitDataModel.ButtonDisabled = new Howl({
         urls: [this.splitDataModel.soundSrc+'ButtonClick.mp3', this.splitDataModel.soundSrc+'ButtonClick.wav']
     });
     
     this.splitDataModel.PopupSound = new Howl({
         urls: [this.splitDataModel.soundSrc+'BonusCongratulationPopup.mp3', this.splitDataModel.soundSrc+'BonusCongratulationPopup.wav']
     });
     
     this.splitDataModel.FreeSpinPopup = new Howl({
         urls: [this.splitDataModel.soundSrc+'BonusCongratulationPopup.mp3', this.splitDataModel.soundSrc+'BonusCongratulationPopup.wav']
     });
     
     this.splitDataModel.GAME_BG_SOUND = new Howl({
         urls: [this.splitDataModel.soundSrc+'BackGSOUND.mp3', this.splitDataModel.soundSrc+'BackGSOUND.wav']
     });
     
     this.splitDataModel.reelMoveSound = new Howl({
          urls: [this.splitDataModel.soundSrc+'ReelSpin.mp3', this.splitDataModel.soundSrc+'ReelSpin.wav'],
          loop: false,
          onend: function() {self.splitDataModel.reelMoveSound.play()}
     });
     
     this.splitDataModel.ButtonClick = new Howl({
          urls: [this.splitDataModel.soundSrc+'ButtonClick.mp3', this.splitDataModel.soundSrc+'ButtonClick.wav']
     });
     

      this.splitDataModel.sndArr[0] =  this.splitDataModel.GAME_BG_SOUND;
      this.splitDataModel.sndArr[1] =  this.splitDataModel.reelMoveSound;
      this.splitDataModel.sndArr[2] =  this.splitDataModel.winSound;
      this.splitDataModel.sndArr[3] =  this.splitDataModel.paylinesel;
      this.splitDataModel.sndArr[4] = this.splitDataModel.ButtonDisabled;
      this.splitDataModel.sndArr[5] = this.splitDataModel.PopupSound;
      this.splitDataModel.sndArr[6] = this.splitDataModel.FreeSpinPopup;
      this.splitDataModel.sndArr[7] = this.splitDataModel.ButtonClick;
   
      this.startGameBGSound();
 };
 
 //This calls to update the line bet amount.
 
StringSplitter.prototype.updateLineBetAmount = function(){
    var numPayLines = $('#payline-val-txt').val();
     $('#linebet-text').val("$"+((parseInt(numPayLines)*(parseFloat(this.splitDataModel.coinValue)/100)).toFixed(2)));
};

/*
 * This function is for to manage the sound button in the games
 */

StringSplitter.prototype.sndHelpBtnHandler = function() {
    
     $('.auto-spin-control').removeClass('autospin-animate');
     $('.auto-spin-control input').removeAttr('checked');
     
     if(this.splitDataModel.isSoundPlay === true){ 
         this.splitDataModel.ButtonClick.stop().play();
     }
     $('#game-help-details').html('');
     var spinSource = $("#spinSource").val();
     var spinToken = $("#spinToken").val();
     $.ajax({
         async : false,
         cache: false,
         type: "POST",
         dataType: 'html',
         url: "help.action?spinSource="+spinSource+"&spinToken="+spinToken,
         contentType: this.contentType, // content type sent to server
         success: function (msg) {//On Successfull json call 
             if(msg !=="undefined" && msg !== "" && msg !== null){
                 $('#game-help-details').html(msg);
             }else if(msg.hasError){
                 var json =  JSON.parse(JSON.stringify(msg));
                 self.errorMessageObj.formatErrorMessage(json.ErrorCode);
             } else {
                self.errorMessageObj.formatErrorMessage(-1);
             }
         },
         error: function () {
             self.errorMessageObj.formatErrorMessage(-1);
         }
     });
}

// this method is used for update the auto free spin game screen
StringSplitter.prototype.updateFreeSpinScreen = function () {
     var self = this;
     if(this.updateAutoSpinScrTimer !== null){
         clearInterval(this.updateAutoSpinScrTimer);
     }
     this.updateAutoSpinScrTimer = setInterval(function(){
            if(self.splitDataModel.bIsReelStoped === true && self.splitDataModel.bIsAutoFreeSpin === true
                    && self.splitDataModel.bIsBonusWin === false && self.splitDataModel.bonusGameVisible === false){
               
               clearInterval(self.updateAutoSpinScrTimer);
               var previousAutoFreeAmt = $("#total-win").val();
               var tlWin = (parseFloat(self.splitDataModel.bonusWinAmount) + parseFloat(self.splitDataModel.winningAmount) + parseFloat(previousAutoFreeAmt.substring(1, previousAutoFreeAmt.length))).toFixed(2);
               $("#total-win").val("$"+(tlWin));
               self.splitDataModel.bonusWinAmount = 0.00;
            }
     },100);
};


//for jackpot header
StringSplitter.prototype.JackpotWinUsers = function(message,amount){
    var self = this;
    setTimeout(function(){
        $(".jackpot-header p").fitText(2);
        $(".jackpot-header span").fitText(1.3);
    });   
    var jackPotWinPopup = $("<div id='jackpotheader' class='progress-fix jackpot-header' style='background-color:rgba(0,0,0, 0); width:100%; height:13%; position:fixed; top:0; left:0; '><p></p><span></span></div>");
        $(".main").append(jackPotWinPopup);
        $(".jackpot-header p").append(message);
        $(".jackpot-header span").append(amount);
   };
//jackpot header end

   //This methos is uesd for add the issue reported by player
 StringSplitter.prototype.reportIssueBtnHandler = function(event){
     var self = this;
     $('#requiredField').hide();
     var sEmail = $('#txtEmail').val();
     event.preventDefault();
     if ($.trim(sEmail).length == 0) {
         this.errorMessageObj.formatErrorMessage(2);
         $('#description').val('');
         $('#requiredField').hide();
         return false;
     }
     var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
     if (filter.test(sEmail)) {
         var spinToken = $("#spinToken").val();
         var error = 0;
         var comment = $('#description').val();
         if (comment == '') {
             error = 1;
         }
         if (error) {
             $('#requiredField').show();
         } else {
             $.ajax({
                 url : "issueReportAdd?spinToken=" + spinToken,
                 data : $('#issueReportForm').serialize(),
                 type : "POST",
                 datatype : "json",
                 success : function(msg) {
                     if (msg.hasError) {
                         var json = JSON.parse(JSON.stringify(msg));
                         self.errorMessageObj.formatErrorMessage(json.ErrorCode);
                     } else if(msg.success ='True'){
                         self.errorMessageObj.formatErrorMessage(3);
                         $(".close-reveal-modal").trigger("click");
                         $('#requiredField').hide();
                         $('#description').val('');
                     }
                 },
                 error : function(error) {
                     $('#requiredField').hide();
                     $('#description').val('');
                     self.errorMessageObj.formatErrorMessage(-1);
                 }
             });
         }
     } else {
        this.errorMessageObj.formatErrorMessage(4);
        $('#description').val('');
        $('#requiredField').hide();
        return false;
     }
 };
// this methos is used for close the issue report popup
 StringSplitter.prototype.closeIssueReport = function(event) {
    event.preventDefault();
    $(".close-reveal-modal").trigger("click");
    $('#requiredField').hide();
    $('#description').val('');
};

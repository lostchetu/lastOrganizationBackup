function BonusMain(spinServiceObj, totalArrayValues, symbolValues,
        chanceAllowed, coinValue, dataModelObj, stringSplitObj) {
    var self = this;

    this.chanceAllowed = chanceAllowed;
    this.dataModelObj = dataModelObj;
    this.stringSplit = stringSplitObj;
    this.spinService = spinServiceObj;

    if (this.dataModelObj.bonusGameVisible === false) {
        this.dataModelObj.bonusGameVisible = true;

        this.symbolValue = symbolValues;
        this.coinValue = coinValue;
        if (chanceAllowed > 1) {
            this.valueArr = this.symbolValue;
        } else {
            this.valueArr = new Array(this.symbolValue);
        }

        $('.bonus-canvas-back').show();
        if ($('.bonus-canvas-container')) {
            $('.bonus-canvas-container').show();
            $(".transGamebg").show();
        }

        this.wonValues = "";
        this.bonusIndex = 0;
        this.spriteBackground = new Image();
        this.baseDragenEgg = new Image();
        this.baseDragenImage = new Image();
        this.clickImage = new Image();
        this.fireDragenImage = new Image();
        this.EggImage = new Image();
        this.spriteBackground.src = "assests/throne/Bonus/bonus-screen-image.jpg";
        this.baseDragenImage.src = "assests/throne/Bonus/base-dragon.png";
        this.baseDragenEgg.src = "assests/throne/Bonus/base-egg.png";
        this.fireDragenImage.src = "assests/throne/Bonus/dragon-fire.png";

        this.EggImagesArray = [
                "assests/throne/Bonus/golden-dragon.png",
                "assests/throne/Bonus/green-dragon.png",
                "assests/throne/Bonus/silver-dragon.png" ];
        this.EggImage.src = this.EggImagesArray[this.bonusIndex];

        this.isAssestLoaded = false;
        this.isFireAnimate = false;

        this.frameCountBg = 0;
        this.frameCountBaseDragen = 0;
        this.frameCountfireDragen = 0;
        this.frameCountEggDragen = 0;
        
        if (this.GameInterval != null) {
            clearInterval(this.GameInterval);
        }

        this.clearContainer();

        this.autocanvas = $("#myCanvas");
        this.ctx = $("#myCanvas")[0].getContext('2d');

        this.ctx.save();
        // Use the identity matrix while clearing the canvas
        this.ctx.setTransform(1, 0, 0, 1, 0, 0);
        this.ctx.clearRect(0, 0, this.autocanvas.width, this.autocanvas.height);
        // Restore the transform
        this.ctx.restore();

        this.totalValue = 0;
        $("#bonus-coin-val").attr("value", "$" + this.coinValue);
        $("#chance-text").attr("value", this.chanceAllowed);
        $("#bonus-point").attr("value", this.totalValue);

        this.clickToplay = $("#clickToPlay");
        this.valueContainer = $(".input-field");
        this.GameInterval = null;
        this.showBonusPopupTimer = null;
        this.textFade = null;
        
        if(this.dataModelObj.GAME_BG_SOUND != null ){
            this.dataModelObj.GAME_BG_SOUND.stop();
        }
        this.init();
        this.addClickEvent();
        this.bonusThroneGameSounds();

    }
}

BonusMain.prototype.init = function() {
    var self = this;
    
    if (this.GameInterval != null) {
        clearInterval(this.GameInterval);
    }
    this.GameInterval = setInterval(function() {
        self.Background();
        self.baseEgg();
        self.dragenAnimation();
        if (self.isFireAnimate === true) {
            self.eggDragenAnimation();
            self.fireDragen();
            
        } else {
            self.dragenAnimation();
            self.baseEgg();
            $("#win-value").css("display", "none");
        }
    }, 300);
}

BonusMain.prototype.clearContainer = function() {
    var self = this;
    if (this.GameInterval != null) {
        clearInterval(this.GameInterval);
    }
    
    if (this.textFade != null) {
        clearInterval(this.textFade);
    }
}

BonusMain.prototype.Background = function() {
    this.ctx.drawImage(this.spriteBackground, 0, 0, 1920, 1080); 
}

BonusMain.prototype.baseEgg = function() {
    this.ctx.drawImage(this.baseDragenEgg, 665, 420, 945, 655);
}
BonusMain.prototype.dragenAnimation = function() {
    this.ctx.drawImage(this.baseDragenImage, 0, 0, 675, 1080);
}

BonusMain.prototype.fireDragen = function() {
    var self = this;
    var numFrames = 9;
    var frameSize = 1293;
    if (this.frameCountfireDragen < numFrames) {
        this.ctx.clearRect(0, 0, 0, 1080);
        this.ctx.drawImage(this.fireDragenImage, frameSize
                * this.frameCountfireDragen, 0, frameSize, 1080, 0, 0,
                frameSize, 1080);
        this.frameCountfireDragen++;
        
        if(this.dataModelObj.isSoundPlay === true && this.frameCountfireDragen === 2 ){
            this.dataModelObj.DragonFire.stop().play();
        }
    
        if (this.frameCountfireDragen == numFrames) {
            this.frameCountfireDragen = 0;
            this.isFireAnimate = false;
            this.eggDragenAnimat = true;
        }
    }
}

BonusMain.prototype.eggDragenAnimation = function() {
    var numFrames = 9;
    var frameSize = 945;
    if (this.frameCountEggDragen < numFrames) {
        this.ctx.clearRect(0, 0, 0, 655);
        this.ctx.drawImage(this.EggImage, frameSize * this.frameCountEggDragen,
                0, frameSize, 655, 665, 420, frameSize, 655);
        this.frameCountEggDragen++;
        
        if(this.dataModelObj.isSoundPlay === true && this.frameCountEggDragen == 7){
            this.dataModelObj.DragonFire.stop();
            this.dataModelObj.bonusPointsWin.stop().play();
        }
        
        if (this.frameCountEggDragen == 5) {
            this.chanceAllowed--;
            if (parseInt((this.chanceAllowed)) > 1) {
                $("#chance-text").attr("value", this.chanceAllowed);
            } else {
                $("#chance-text").attr("value", this.chanceAllowed);
            }

            this.currentValue = this.valueArr[this.bonusIndex];
            ++this.bonusIndex;
          
            this.totalValue += parseInt(this.currentValue);
            $("#win-value").css("display", "block");
            $('#win-value').addClass('color' + this.bonusIndex );
            $("#win-value").empty().append("" + this.currentValue + "");

            if (this.chanceAllowed == 0) {
                this.soundArr = [];
                this.spinService.bonusRoundPlayed();
            }
        }

        if (this.frameCountEggDragen == 9) {
        	$("#bonus-point").attr("value", this.totalValue);
            if (this.chanceAllowed > 0) {
                this.addClickEvent();
            } else {
                this.showWinAmountPopup();
            }
        }

        if (this.frameCountEggDragen == numFrames) {
            this.frameCountEggDragen = 0;
            this.eggDragenAnimat = false;
        }
    }
}

BonusMain.prototype.showWinAmountPopup = function() {
    var self = this;
    this.showBonusPopupDelayTime = 1000;
    if (this.chanceAllowed == 0) {
        this.removeClickEvent();
        var finalWinAmount = parseFloat(this.totalValue * this.coinValue)
                .toFixed(2);
        if (this.showBonusPopupTimer != null) {
            clearInterval(this.showBonusPopupTimer);
        }
        this.dataModelObj.hasErrorInBonusUpadte = false;
        this.dataModelObj.bIsBonusUpdated = true;
        this.showBonusPopupTimer = setInterval(function() {
            if (self.dataModelObj.hasErrorInBonusUpadte === false) {
                if (self.dataModelObj.bIsBonusUpdated === true) {
                    clearInterval(self.showBonusPopupTimer);
                    self.clearContainer();
                    self.spinService.showBonusAmountWinPopup($.i18n.prop(
                            "bonus.win.roundAmount", finalWinAmount));
                    if(self.dataModelObj.isSoundPlay === true ){
                        self.dataModelObj.DragonFire.stop();
                        self.dataModelObj.BonusWinPopUp.stop().play();
                    }
                }
            } else if (self.dataModelObj.hasErrorInBonusUpadte === true
                    && self.dataModelObj.bIsBonusUpdated === true) {
                clearInterval(self.showBonusPopupTimer);
                self.clearContainer();
            }
        }, this.showBonusPopupDelayTime);

    }
}

BonusMain.prototype.addClickEvent = function() {
    this.clickToplay.bind("click", $.proxy(this.mouseClickHandler, this));
    this.clickToplay.attr("disabled", false);
    $('#win-value').attr("class","");
};
//for remove click events from button
BonusMain.prototype.removeClickEvent = function() {
    this.clickToplay.attr("disabled", true);
    this.clickToplay.unbind("click", $.proxy(this.mouseClickHandler, this));
};

BonusMain.prototype.mouseClickHandler = function(ev) {
    if (this.chanceAllowed > 0) {
        this.EggImage.src = this.EggImagesArray[this.bonusIndex];
        this.isFireAnimate = true;
        if(this.dataModelObj.isSoundPlay === true ){
            this.dataModelObj.clickToPlay.stop().play();
        }
        this.removeClickEvent();
    }
}

BonusMain.prototype.bonusThroneGameSounds = function() {

    if (this.dataModelObj.clickToPlay == null) {
        this.dataModelObj.clickToPlay = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'ButtonClick.mp3',
                    this.dataModelObj.soundSrc + 'ButtonClick.wav' ]
        });
    }

    if (this.dataModelObj.bonusPointsWin == null) {
        this.dataModelObj.bonusPointsWin = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusPointWinsound.mp3',
                    this.dataModelObj.soundSrc + 'BonusPointWinsound.wav' ]
        });
    }

    if (this.dataModelObj.DragonFire == null) {
        this.dataModelObj.DragonFire = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'DragonRoar.mp3',
                    this.dataModelObj.soundSrc + 'DragonRoar.wav' ]
        });
    }

    if (this.dataModelObj.BonusWinPopUp == null) {
        this.dataModelObj.BonusWinPopUp = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusCongratulationPopup.mp3',
                    this.dataModelObj.soundSrc + 'BonusCongratulationPopup.wav' ]
        });
    }
};

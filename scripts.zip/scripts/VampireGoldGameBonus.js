﻿/*This function loads all model object, string splitter object,chances and scores */
function BonusMain(spinServiceObj, totalScores, symbolValues, chanceAllowed,
        coinValue, dataModelObj, stringSplitObj) {

     var self = this;
     this.dataModelObj = dataModelObj;
     this.stringSplit = stringSplitObj;
     this.spinService = spinServiceObj;
     if (this.dataModelObj.bonusGameVisible === false) {
            this.dataModelObj.bonusGameVisible = true;
        this.chanceAllowed = chanceAllowed;
        this.totalScores = totalScores;
        this.symbolValue = symbolValues;
        this.coinValue = coinValue;
        this.valueArr = this.totalScores;
        this.wonValues = "";
        $('.bonus-canvas-back').show();
        if ($('.bonus-canvas-container')) {
            $('.bonus-canvas-container').show();
            $(".transGamebg").show();
        }
        this.bonusDataModel = new BonusDataModel();
        this.buttonInitObj = new BonusButtonInit(this);
        this.canvasWidth = $('#bonusCanvas').attr("width");
        this.canvasHeight = $('#bonusCanvas').attr("height");
        this.frameCount = 0;
        this.ctx = $('#bonusCanvas')[0].getContext('2d');
        this.imageArray = [];
        this.checkAttempt = 0;
        this.totalValue = 0;
        $("#bonus-coin-val").attr("value", this.coinValue);
        $("#chance-text").attr("value", this.chanceAllowed);
        this.remainingChances = this.chanceAllowed;
        
        $("#bonus-point").attr("value", this.totalValue);
        this.animTimer = 0;
        this.batCount1 = 0;
        this.batCount2 = 0;
        this.batCount3= 0;
        this.ctx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
        this.initialize();
        this.soundArr = [];
        this.Vamx = 125;
        this.Vamy = 95;
        
        this.batspriteImage = new Image();
        this.batspriteImage.src = this.bonusDataModel.imageSrc + "batsprite.png";
     
        if(this.dataModelObj.GAME_BG_SOUND != null ){
            this.dataModelObj.GAME_BG_SOUND.stop();
        }
        this.bonusGameVampireGoldSounds();
     
     }
}

BonusMain.prototype.initialize = function() {
    var self = this;
    
    var image = new Image()
    image.src = this.bonusDataModel.imageSrc + "vamDragsprite.png";

    image.onload = function() {
        for (var i = 0; i < 12; i++) {
            var imageObj = new Object();
            imageObj.img = image;
            imageObj.x = self.Vamx;
            imageObj.y = self.Vamy;
            
            var symbolIndex = Math.floor(Math.random()* (self.valueArr.length - 1));
            imageObj.value = self.valueArr[symbolIndex];
            imageObj.isClicked = false;
            self.valueArr.splice(symbolIndex, 1);
            self.ctx.drawImage(imageObj.img, self.bonusDataModel.animWidth
                    * self.frameCount, 0, self.bonusDataModel.animWidth,
                    self.bonusDataModel.animHeight, imageObj.x, imageObj.y,
                    self.bonusDataModel.animWidth,
                    self.bonusDataModel.animHeight);
            
            self.imageArray.push(imageObj);
            self.Vamx += 350;
            self.VamY += 247;
            if (i % 12 == 0) {
                self.Vamy += 0;
            }

            if (i == 3) {
                self.Vamx = 125;
                self.Vamy = 395
            }

            else if (self.Vamx > 1366) {
                self.Vamx = 328 - 205;
                self.Vamy = 685
            }

        }
        self.Vamx = 328;
        self.Vamy = 247;
        self.buttonInitObj.bindEvents();
    }
}


BonusMain.prototype.clearContainer = function() {
    "use strict";
    var self = this;
    
    if (this.animTimer != null) {
        clearInterval(this.animTimer);
    }
    
    if(this.batAnimationTimer1 != null){
        clearInterval(this.batAnimationTimer1);
    }
    
    if(this.batAnimationTimer2 != null){
        clearInterval(this.batAnimationTimer2);
    }
    
    if(this.batAnimationTimer3 != null){
        clearInterval(this.batAnimationTimer3);
    }
    
    if(this.batAnimUpdateTimer != null){
        clearInterval(this.batAnimUpdateTimer);
    }
    
    if(this.showBonusPopupTimer != null){
        clearInterval(this.showBonusPopupTimer);
    }
}

/*
 * This function check the hits of vampire and draw text of win amount.  
 */

BonusMain.prototype.checkObjectHit = function(posX, posY) {
    var self = this;
    for (var i = 0; i < this.imageArray.length; i++) {
        if (posX >= (this.imageArray[i].x)
                && posX <= (this.imageArray[i].x + this.bonusDataModel.animWidth)
                && posY >= (this.imageArray[i].y)
                && posY <= (this.imageArray[i].y + this.bonusDataModel.animHeight)
                && this.imageArray[i] !== undefined
                && this.imageArray[i].isClicked === false) {
            if (this.checkAttempt < this.chanceAllowed) {
                if(this.dataModelObj.isSoundPlay === true ){
                      self.dataModelObj.GAME_BG_SOUND.stop();
                    self.dataModelObj.clickToPlayGame.stop().play();
                }
                this.imageArray[i].isClicked = true;
                var winAmt = this.symbolValue[this.checkAttempt];
                this.imageArray[i].value = winAmt;
                this.totalValue += parseInt(winAmt);
                this.wonValues = this.wonValues.concat((winAmt) + ",");
                this.buttonInitObj.unBindEvents();
                this.checkAttempt++;
                this.startMineVamAnimation(this.imageArray[i]);
                this.remainingChances = parseInt(this.remainingChances)-1;
                break;
            } else {
                this.buttonInitObj.unBindEvents();
                this.checkAttempt = 0;
            }

        }
    }
}

/*
 * This function start start Mine VamAnimation
 */
BonusMain.prototype.startMineVamAnimation = function(animObj) {
    var self = this;
    this.frameCount = 0;
    
    if(this.animTimer != null){
        clearInterval(this.animTimer);
    }
    
    
    this.animTimer = setInterval(function() {
        self.animateVampire(animObj);
    }, 1000 / 10);
}
/*
 * This function calls when the blast in animateVampire. 
 */

BonusMain.prototype.animateVampire = function(AnimObj) {
    var self = this;
    this.numFrames = 21;
    this.tmpAnimObj = AnimObj;

    this.ctx.clearRect(AnimObj.x, AnimObj.y, this.bonusDataModel.animWidth,
            this.bonusDataModel.animHeight);
    this.ctx.drawImage(AnimObj.img, this.bonusDataModel.animWidth * this.frameCount, 
            0, this.bonusDataModel.animWidth,
            this.bonusDataModel.animHeight, AnimObj.x, AnimObj.y,
            this.bonusDataModel.animWidth, this.bonusDataModel.animHeight);

    this.frameCount++;
    
    if(this.dataModelObj.isSoundPlay === true && this.frameCount==10){
         self.dataModelObj.GAME_BG_SOUND.stop();
        self.dataModelObj.BonusExplosion.stop().play();
    }
    
    
    if (this.frameCount >= this.numFrames) {
        clearInterval(this.animTimer);
        var tmpCheckAtt = this.checkAttempt;
        

        if(tmpCheckAtt ===1){
            this.batAnimationTimer1 = setInterval(function() {
                self.batAnimation(AnimObj, tmpCheckAtt);
            }, 1000 / 20);
        }
        
        if(tmpCheckAtt ===2){
            this.batAnimationTimer2 = setInterval(function() {
                self.batAnimation(AnimObj, tmpCheckAtt);
            }, 1000 / 20);
        }
        
        if(tmpCheckAtt ===3){
            this.batAnimationTimer3 = setInterval(function() {
                self.batAnimation(AnimObj, tmpCheckAtt);
             }, 1000 / 20);
        }
        
        if(this.batAnimUpdateTimer != null){
            clearInterval(this.batAnimUpdateTimer);
        }
        
        this.batAnimUpdateTimer = setInterval(function() {
            
             if((self.batCount1 ===2 && tmpCheckAtt ===1)
                ||(self.batCount2 ===2 && tmpCheckAtt === 2) || (self.batCount3 ===2 && tmpCheckAtt === 3)) {
                    if(self.dataModelObj.isSoundPlay === true ){
                        self.dataModelObj.GAME_BG_SOUND.stop(); 
                          self.dataModelObj.bonusPointsWin.stop().play();
                    }
             }
             
            if((self.batCount1===7 && tmpCheckAtt ===1)||(self.batCount2===7 && tmpCheckAtt ===2)||(self.batCount3===7 && tmpCheckAtt ===3)) {
                if(self.dataModelObj.isSoundPlay === true ){
                    self.dataModelObj.GAME_BG_SOUND.stop();
                      self.dataModelObj.batAnimate.stop().play();
                }
            }
            
            if(self.batCount1==10 && tmpCheckAtt ===1) {
                self.buttonInitObj.bindEvents();
                $("#bonus-coin-val").attr("value", self.coinValue);
                $("#chance-text").attr("value", parseInt(self.remainingChances));
                $("#bonus-point").attr("value", self.totalValue);
                self.updateBonusPlayed();
                clearInterval(self.batAnimUpdateTimer);
            }
            
            if(self.batCount2==10 && tmpCheckAtt ===2) {
                self.buttonInitObj.bindEvents();
                $("#bonus-coin-val").attr("value", self.coinValue);
                $("#chance-text").attr("value", parseInt(self.remainingChances));
                $("#bonus-point").attr("value", self.totalValue);
                self.updateBonusPlayed();
                clearInterval(self.batAnimUpdateTimer);
            }
            
            if(self.batCount3==10 && tmpCheckAtt ===3) {
                self.buttonInitObj.bindEvents();
                $("#bonus-coin-val").attr("value", self.coinValue);
                $("#chance-text").attr("value", parseInt(self.remainingChances));
                $("#bonus-point").attr("value", self.totalValue);
                self.updateBonusPlayed();
                clearInterval(self.batAnimUpdateTimer);
            }
        }, 1000 / 15);
        
    }
}

/*
 * This function is for getting the mouse movement
 */

BonusMain.prototype.updateBonusPlayed = function(){
    var self = this;
    this.showBonusPopupDelayTime = 4000;
    if(this.showBonusPopupTimer != null){
        clearInterval(this.showBonusPopupTimer);
    }
    
    var self = this;
    if (this.checkAttempt >= this.chanceAllowed) {
        if (this.imageArray.length > 0) {
            this.showLoseValues();
        }
        if (this.chanceAllowed == this.checkAttempt) {
            this.spinService.bonusRoundPlayed();
            var finalWinAmount = parseFloat(this.totalValue * this.coinValue).toFixed(2);
            if (this.showBonusPopupTimer != null) {
                clearInterval(this.showBonusPopupTimer);
            }
            
            this.showBonusPopupTimer = setInterval(function() {
                if (self.dataModelObj.hasErrorInBonusUpadte == false
                        && self.dataModelObj.bIsBonusUpdated == true) {
                    clearInterval(self.showBonusPopupTimer);
                    self.clearContainer();
                    self.spinService.showBonusAmountWinPopup($.i18n.prop("bonus.win.roundAmount", finalWinAmount));
                    if(self.dataModelObj.isSoundPlay === true ){
                        self.dataModelObj.GAME_BG_SOUND.stop();
                        self.dataModelObj.BonusWinPopUp.stop().play();
                        
                    }
                } else if (self.dataModelObj.hasErrorInBonusUpadte === true
                        && self.dataModelObj.bIsBonusUpdated === true) {
                    clearInterval(self.showBonusPopupTimer);
                    self.clearContainer();
                }
            }, this.showBonusPopupDelayTime);
        }
    }
    
}

BonusMain.prototype.mouseMoveHandler = function(ev) {
    var pos = this.findPos(ev.target);
    var x = ev.pageX - pos.x;
    var y = ev.pageY - pos.y;
    var ratioX = (this.canvasWidth / $('#bonusCanvas').width());
    var ratioY = (this.canvasHeight / $('#bonusCanvas').height());
    this.changeCursor(x * ratioX, y * ratioY);
}

BonusMain.prototype.changeCursor = function(posX, posY) {
    $('#bonusCanvas').css('cursor', 'default');
    for (var i = 0; i < this.imageArray.length; i++) {

        if (posX >= (this.imageArray[i].x)
                && posX <= (this.imageArray[i].x
                        + this.bonusDataModel.animWidth)
                && posY >= (this.imageArray[i].y)
                && posY <= (this.imageArray[i].y
                        + this.bonusDataModel.animHeight)) {
            $('#bonusCanvas').css('cursor', 'pointer');
        }
    }
}

BonusMain.prototype.canvasClickHandler = function(ev) {
    var pos = this.findPos(ev.target);
    var x = ev.pageX - pos.x;
    var y = ev.pageY - pos.y;
    var ratioX = (1920 / $('#bonusCanvas').width());
    var ratioY = (1080 / $('#bonusCanvas').height());
    this.checkObjectHit(x * ratioX, y * ratioY);
}

/*
 * Logic to find the position of cursor
 */
BonusMain.prototype.findPos = function(obj) {
    var curleft = 0, curtop = 0;
    if (obj.offsetParent) {
        do {
            curleft += obj.offsetLeft;
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);
        return {
            x : curleft,
            y : curtop
        };
    }
    return undefined;
}


function BonusDataModel() {
    this.imageSrc = "assests/vampireGold/Bonus/";
    this.animHeight = 247;
    this.animWidth = 328;
    this.pyramidHight =100;
    this.sndArr = [ "BonusBackGround" ];

}

function BonusButtonInit(bonusMainObj) {
    this.canvasElem = $("#bonusCanvas");
    this.bonusMainObj = bonusMainObj;
}

BonusButtonInit.prototype.bindEvents = function() {
    this.canvasElem.bind('mousemove', $.proxy(
            this.bonusMainObj.mouseMoveHandler, this.bonusMainObj));
    this.canvasElem.bind('click', $.proxy(this.bonusMainObj.canvasClickHandler,
            this.bonusMainObj));
}

BonusButtonInit.prototype.unBindEvents = function() {
    this.canvasElem.unbind('mousemove', $.proxy(
            this.bonusMainObj.mouseMoveHandler, this.bonusMainObj));
    this.canvasElem.unbind('click', $.proxy(
            this.bonusMainObj.canvasClickHandler, this.bonusMainObj));
}

/*
 * This method is for the batAnimation
 */
BonusMain.prototype.batAnimation = function(AnimObj,tmpCheckAttempt) {
    var self = this;
    this.numFrames = 14;
    if(tmpCheckAttempt ===1){
        this.ctx.clearRect(AnimObj.x, AnimObj.y, this.bonusDataModel.animWidth,
                this.bonusDataModel.animHeight);
       
        this.ctx.drawImage(this.batspriteImage, this.bonusDataModel.animWidth
                * this.batCount1, 0, this.bonusDataModel.animWidth,
                this.bonusDataModel.animHeight, AnimObj.x, AnimObj.y,
                this.bonusDataModel.animWidth, this.bonusDataModel.animHeight);
        
 
        this.showWinValue(AnimObj);
        
        this.batCount1++;
        if (this.batCount1 >= this.numFrames) {
            this.batCount1 = 0;
        }
        
    }
    
    if(tmpCheckAttempt ===2){
        this.ctx.clearRect(AnimObj.x, AnimObj.y, this.bonusDataModel.animWidth,
                this.bonusDataModel.animHeight);
       
        this.ctx.drawImage(this.batspriteImage, this.bonusDataModel.animWidth
                * this.batCount2, 0, this.bonusDataModel.animWidth,
                this.bonusDataModel.animHeight, AnimObj.x, AnimObj.y,
                this.bonusDataModel.animWidth, this.bonusDataModel.animHeight);
        
        this.showWinValue(AnimObj);
        this.batCount2++;
        if (this.batCount2 >= this.numFrames) {
            this.batCount2 = 0;
        }
    }
    
    if(tmpCheckAttempt ===3){
        this.ctx.clearRect(AnimObj.x, AnimObj.y, this.bonusDataModel.animWidth,
                this.bonusDataModel.animHeight);
        
        this.ctx.drawImage(this.batspriteImage, this.bonusDataModel.animWidth
                * this.batCount3, 0, this.bonusDataModel.animWidth,
                this.bonusDataModel.animHeight, AnimObj.x, AnimObj.y,
                this.bonusDataModel.animWidth, this.bonusDataModel.animHeight);

        this.showWinValue(AnimObj);
        this.batCount3++;
        
        if (this.batCount3 >= this.numFrames) {
            this.batCount3 = 0;
        }
    }
}

BonusMain.prototype.showWinValue = function(AnimObj) {
    var self = this;
    this.ctx.fillStyle = "#da0000";
    this.ctx.font = "bold 50pt ufonts";
    this.ctx.textAlign = 'center';
    this.ctx.strokeStyle = "#fad4d4";
    this.ctx.lineWidth = 5; 
    this.ctx.strokeText(AnimObj.value, AnimObj.x + 160, AnimObj.y + (this.bonusDataModel.animHeight -70));
    this.ctx.fillText(AnimObj.value, AnimObj.x + 160, AnimObj.y + (this.bonusDataModel.animHeight -70));

}

BonusMain.prototype.showLoseValues = function () {
    for (var valueCount = 0; valueCount < this.imageArray.length; valueCount++) {
         if (this.imageArray[valueCount].isClicked === false) {
            this.ctx.fillStyle = "#00fcff";
            this.ctx.font = "bold 50pt ufonts";
            this.ctx.textAlign = 'center';
            this.ctx.strokeStyle = "#000";
            this.ctx.shadowOffsetX = 10;
            this.ctx.shadowBlur = 50;
            //this.ctx.shadowOffsetY = 5;
            this.ctx.lineWidth = 5;
            this.ctx.strokeText(this.imageArray[valueCount].value, this.imageArray[valueCount].x + 178, this.imageArray[valueCount].y + 180);
            this.ctx.fillText(this.imageArray[valueCount].value, this.imageArray[valueCount].x + 178, this.imageArray[valueCount].y + 180);
         }
  }
}

BonusMain.prototype.bonusGameVampireGoldSounds = function() {
    if (this.dataModelObj.batAnimate == null) {
        this.dataModelObj.batAnimate = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'Bats.mp3',
                    this.dataModelObj.soundSrc + 'Bats.wav' ]
        });
    }

    if (this.dataModelObj.clickToPlayGame == null) {
        this.dataModelObj.clickToPlayGame = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'VampireClick.mp3',
                    this.dataModelObj.soundSrc + 'VampireClick.wav' ]
        });
    }

    if (this.dataModelObj.bonusPointsWin == null) {
        this.dataModelObj.bonusPointsWin = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'BonusPointWinsound.mp3',
                    this.dataModelObj.soundSrc + 'BonusPointWinsound.wav' ]
        });
    }

    if (this.dataModelObj.BonusWinPopUp == null) {
        this.dataModelObj.BonusWinPopUp = new Howl(
                {
                    urls : [
                            this.dataModelObj.soundSrc
                                    + 'BonusCongratulationPopup.mp3',
                            this.dataModelObj.soundSrc
                                    + 'BonusCongratulationPopup.wav' ]
                });
    }

    if (this.dataModelObj.BonusExplosion == null) {
        this.dataModelObj.BonusExplosion = new Howl({
            urls : [ this.dataModelObj.soundSrc + 'Explosionblast.mp3',
                    this.dataModelObj.soundSrc + 'Explosionblast.wav' ]
        });
    }
};

// Literal way 
//const ravi = {
//  name:"ravi",
//  age:25
//}
//console.log(ravi);
//console.log(ravi.age);

// Person constructor

function Person(name, dob){
  this.name = name;
  //this.age = age;
  this.birthday = new Date(dob);
  this.calculateAge = function(){
    const diff = Date.now() - this.birthday.getTime();
    const ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1980);
  }
  //console.log(this)
}

//const p1 = new Person("ravi",25);
//const p2 = new Person("Amit", 28);
//console.log(p1.age);
//console.log(p2.age);
const am1 = new Person("ravi", 25-10-1980);
  this.name = name;
console.log(am1.calculateAge());

// Person Constructor 
function Person(firstName, lastName){
  this.firstName = firstName;
  this.lastName = lastName;
}

// Greetings
Person.prototype.greeting = function(){
  return 'Hello there ' + this.firstName + ' ' + this.lastName;
}

const person1 = new Person("Ravi", "Kumar");
//console.log(person1.greeting());
// Inherit the Person prototype methods
Customer.prototype = Object.create(Person.prototype);

//Make customer.prototype return Customer()
Customer.prototype.construtor = Customer;

// Customer construtor

function Customer(firstName, lastName, phone, membership){
  Person.call(this,firstName, lastName);
  this.phone = phone;
  this.membership = membership;
}

const customer1 = new Customer("Tom", "Smith", "995-831-7627", "Standard");
console.log(customer1);
console.log(customer1.greeting());
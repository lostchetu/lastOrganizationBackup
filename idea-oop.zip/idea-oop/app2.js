// Not advise to write this way in js
// String
const name1 = "Ravi";
const name2 = new String("Mohan");
//name2.foo = "anil";
//console.log(typeof name2);

// if(name2 === "Ravi"){
//   console.log("Yes")
// }else{
//   console.log("No")
// }

// Number
const num1 = 5;
const num2 = new Number(5);
// boolean
const bool1 = true;
//const bool2 = new boolean(true);
//Function 

const getSum1 = function(x,y){
  return x+y;
}
const getSum2 = new Function('x','y', 'return 1+1');

// Object 
const john1 = {name :"John"};
const john2 = new Object({name:"Raj"});
//console.log(john1);

// Array 
const arry1 = [1,2,3,45];
const arry2 = new Array(1,2,3,4,5);

//console.log(arry2);

// Regular Expression 
const rel1 = /\w+/;
const rel2 = new RegExp('\w+');
const rel3 = new RegExp('\\w+');
console.log(rel3);

